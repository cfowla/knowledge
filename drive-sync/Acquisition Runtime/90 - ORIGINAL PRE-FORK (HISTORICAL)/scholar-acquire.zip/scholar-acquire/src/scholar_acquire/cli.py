from __future__ import annotations

import json
from pathlib import Path
from typing import Annotated

import typer

from .cache import DiskCache
from .config import Settings
from .models import AcquisitionPolicy
from .orchestrator import AcquisitionOrchestrator

app = typer.Typer(no_args_is_help=True, help="Acquire lawful scholarly full text from PMID/DOI identifiers.")
cache_app = typer.Typer(no_args_is_help=True)
app.add_typer(cache_app, name="cache")


@app.command()
def fetch(
    identifier: Annotated[str, typer.Argument(help="PMID, PMCID, DOI, or doi.org URL")],
    out: Annotated[Path, typer.Option("--out", "-o", help="Output directory")] = Path("scholar-fetch-out"),
    email: Annotated[str | None, typer.Option("--email", help="Contact email for NCBI/Unpaywall; overrides env")] = None,
    openalex_key: Annotated[str | None, typer.Option("--openalex-key", help="OpenAlex API key; overrides env")] = None,
    structured: Annotated[bool, typer.Option("--structured/--no-structured")] = True,
    pdf: Annotated[bool, typer.Option("--pdf/--no-pdf")] = True,
    allow_submitted: Annotated[bool, typer.Option("--allow-submitted", help="Allow pre-peer-review repository copies")] = False,
    json_output: Annotated[bool, typer.Option("--json", help="Print result JSON to stdout")] = False,
) -> None:
    settings = Settings()
    if email:
        settings.contact_email = email
    if openalex_key:
        settings.openalex_api_key = openalex_key
    policy = AcquisitionPolicy(want_structured=structured, want_pdf=pdf, allow_submitted=allow_submitted)
    orchestrator = AcquisitionOrchestrator(settings=settings, policy=policy)
    try:
        result = orchestrator.fetch(identifier, out)
    finally:
        orchestrator.close()
    if json_output:
        typer.echo(json.dumps(result.model_dump(mode="json"), indent=2))
    else:
        typer.echo(f"manifest: {result.manifest_path}")
        typer.echo(f"artifacts: {len(result.artifacts)}")
        for artifact in result.artifacts:
            typer.echo(f"- {artifact.format.value}: {artifact.local_path} [{artifact.sha256[:12]}]")
    if not result.artifacts:
        raise typer.Exit(code=2)


@cache_app.command("stats")
def cache_stats() -> None:
    settings = Settings()
    stats = DiskCache(settings.cache_dir).stats()
    typer.echo(json.dumps(stats, indent=2))


if __name__ == "__main__":
    app()
