class ScholarAcquireError(Exception):
    """Base exception for the package."""


class IdentifierError(ScholarAcquireError):
    pass


class ConfigurationError(ScholarAcquireError):
    pass


class NetworkError(ScholarAcquireError):
    pass


class RateLimitError(NetworkError):
    pass


class ProviderError(ScholarAcquireError):
    pass


class NotFoundError(ProviderError):
    pass


class AccessDeniedError(ProviderError):
    pass


class ContentValidationError(ProviderError):
    pass
