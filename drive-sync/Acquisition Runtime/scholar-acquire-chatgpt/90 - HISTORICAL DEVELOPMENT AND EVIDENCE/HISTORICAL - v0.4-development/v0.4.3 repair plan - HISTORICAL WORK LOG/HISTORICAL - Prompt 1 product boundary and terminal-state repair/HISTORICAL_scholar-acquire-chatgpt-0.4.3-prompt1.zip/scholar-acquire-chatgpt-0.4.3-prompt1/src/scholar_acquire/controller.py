from __future__ import annotations

import hashlib
import json
import re
import time
import unicodedata
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Protocol

from pydantic import BaseModel, Field

from .errors import RuntimeProtocolError
from .capabilities import AcquisitionRoute, CapabilityStatus, RouteCapabilityRegistry
from .identity import ArticleIdentity
from .models import (
    ArticleIdentifier,
    ArtifactFormat,
    IdentifierKind,
    ResolvedIds,
    RuntimeFailureCode,
    RuntimeState,
    SourceVersion,
)
from .vertical_slice import (
    AcquisitionExecution,
    ChatGptVerticalSliceRuntime,
)


class AcquisitionConfig(BaseModel):
    want_structured: bool = True
    want_pdf: bool = True
    allow_submitted: bool = False
    route_capabilities: RouteCapabilityRegistry = Field(default_factory=RouteCapabilityRegistry)


class TransportRegistry(BaseModel):
    """Prompt 1 placeholder. Prompt 2 adds the transport request/response contract."""

    registered: list[str] = Field(default_factory=list)


class HostRequestKind(str, Enum):
    RESOLVE_IDENTITY = "resolve_identity"
    OBSERVE_ROUTE = "observe_route"


class HostRequest(BaseModel):
    request_id: str
    kind: HostRequestKind
    identifier: ArticleIdentifier
    route: AcquisitionRoute | None = None
    resolved_ids: ResolvedIds = Field(default_factory=ResolvedIds)
    article_identity: ArticleIdentity | None = None

    @classmethod
    def build(
        cls,
        *,
        kind: HostRequestKind,
        identifier: ArticleIdentifier,
        route: AcquisitionRoute | None = None,
        resolved_ids: ResolvedIds | None = None,
        article_identity: ArticleIdentity | None = None,
    ) -> "HostRequest":
        material = "|".join(
            [kind.value, identifier.kind.value, identifier.value, route.value if route else ""]
        ).encode("utf-8")
        return cls(
            request_id=hashlib.sha256(material).hexdigest()[:24],
            kind=kind,
            identifier=identifier,
            route=route,
            resolved_ids=resolved_ids or ResolvedIds(),
            article_identity=article_identity,
        )


class IdentityObservation(BaseModel):
    request_id: str
    pmid: str
    title: str
    evidence_source: str
    evidence_method: str
    pmcid: str | None = None
    doi: str | None = None
    journal: str | None = None
    year: int | None = None
    evidence_sha256: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ArtifactObservation(BaseModel):
    path: Path
    format: ArtifactFormat
    source_url: str
    discovery_provenance: dict[str, Any]
    lawful_access_basis: str
    open_access: bool
    version: SourceVersion = SourceVersion.UNKNOWN
    license: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class RouteObservationKind(str, Enum):
    MATERIALIZED_ARTIFACT = "materialized_artifact"
    DEFINITIVE_NO_RESULT = "definitive_no_result"
    TRANSPORT_ERROR = "transport_error"
    TIMEOUT = "timeout"
    CAPTCHA = "captcha"
    RESPONSE_NOT_MATERIALIZABLE = "response_not_materializable"
    UNKNOWN = "unknown"
    SEARCH_ABSENCE = "search_absence"
    SKIPPED = "skipped"


class RouteObservation(BaseModel):
    request_id: str
    route: AcquisitionRoute
    kind: RouteObservationKind
    action: str
    artifacts: list[ArtifactObservation] = Field(default_factory=list)
    evidence_source: str | None = None
    http_status: int | None = None
    message: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class HostAdapter(Protocol):
    def observe(self, request: HostRequest) -> IdentityObservation | RouteObservation:
        ...


_BLOCKING_KINDS = {
    RouteObservationKind.TRANSPORT_ERROR,
    RouteObservationKind.TIMEOUT,
    RouteObservationKind.CAPTCHA,
    RouteObservationKind.RESPONSE_NOT_MATERIALIZABLE,
    RouteObservationKind.UNKNOWN,
    RouteObservationKind.SEARCH_ABSENCE,
    RouteObservationKind.SKIPPED,
}


def normalize_title(value: str) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()
    return re.sub(r"\s+", " ", value)


def _record_host_event(runtime: ChatGptVerticalSliceRuntime, request: HostRequest, observation: BaseModel) -> None:
    payload = observation.model_dump(mode="json")
    runtime._event(
        "host_observation_received",
        provider=request.route.value if request.route else None,
        data={"request": request.model_dump(mode="json"), "observation": payload},
    )
    runtime._save()


def _resolve_identity(
    runtime: ChatGptVerticalSliceRuntime,
    identifier: ArticleIdentifier,
    host: HostAdapter,
) -> ArticleIdentity:
    request = HostRequest.build(kind=HostRequestKind.RESOLVE_IDENTITY, identifier=identifier)
    runtime._event("host_observation_requested", data=request.model_dump(mode="json"))
    runtime._save()
    observation = host.observe(request)
    if not isinstance(observation, IdentityObservation):
        raise RuntimeProtocolError("Host returned a non-identity observation for identity resolution")
    _record_host_event(runtime, request, observation)
    if observation.request_id != request.request_id:
        raise RuntimeProtocolError("Identity observation request_id mismatch")
    if not observation.evidence_source.strip() or not observation.evidence_method.strip():
        raise RuntimeProtocolError("Resolved identity requires an evidence source and method")
    if identifier.kind != IdentifierKind.PMID:
        raise RuntimeProtocolError("v0.4.3 Prompt 1 production controller currently requires PMID input")
    if observation.pmid != identifier.value:
        raise RuntimeProtocolError(
            f"Resolved PMID {observation.pmid} conflicts with requested PMID {identifier.value}"
        )
    if not observation.title.strip():
        raise RuntimeProtocolError("Resolved identity requires a title")

    identity = ArticleIdentity(
        pmid=identifier.value,
        pmcid=observation.pmcid,
        doi=observation.doi,
        title=observation.title.strip(),
        journal=observation.journal,
        year=observation.year,
    )
    v04 = runtime.session.seed.metadata["v0_4"]
    v04["article_identity"] = identity.model_dump(mode="json")
    v04["normalized_title"] = normalize_title(identity.title)
    v04["identity_evidence"] = observation.model_dump(mode="json")
    runtime.add_resolved_ids(
        pmid=identity.pmid,
        doi=identity.doi,
        pmcid=identity.pmcid,
    )
    runtime._event(
        "identity_resolved_by_python",
        data={
            "resolved_ids": runtime.session.seed.ids.model_dump(mode="json"),
            "normalized_title": v04["normalized_title"],
            "journal": identity.journal,
            "year": identity.year,
            "evidence_source": observation.evidence_source,
        },
    )
    runtime._save()
    return identity


def _observe_route(
    runtime: ChatGptVerticalSliceRuntime,
    identifier: ArticleIdentifier,
    identity: ArticleIdentity,
    route: AcquisitionRoute,
    host: HostAdapter,
) -> RouteObservation:
    request = HostRequest.build(
        kind=HostRequestKind.OBSERVE_ROUTE,
        identifier=identifier,
        route=route,
        resolved_ids=runtime.session.seed.ids,
        article_identity=identity,
    )
    runtime._event(
        "host_observation_requested",
        provider=route.value,
        data=request.model_dump(mode="json"),
    )
    runtime._save()
    observation = host.observe(request)
    if not isinstance(observation, RouteObservation):
        raise RuntimeProtocolError(f"Host returned a non-route observation for {route.value}")
    _record_host_event(runtime, request, observation)
    if observation.request_id != request.request_id:
        raise RuntimeProtocolError(f"Route observation request_id mismatch for {route.value}")
    if observation.route != route:
        raise RuntimeProtocolError(
            f"Route observation mismatch. requested={route.value} observed={observation.route.value}"
        )
    return observation


def _admit_route_observation(
    runtime: ChatGptVerticalSliceRuntime,
    observation: RouteObservation,
) -> bool:
    route = observation.route
    if observation.kind == RouteObservationKind.MATERIALIZED_ARTIFACT:
        if not observation.artifacts:
            raise RuntimeProtocolError("materialized_artifact observation contains no artifacts")
        admitted = 0
        for artifact in observation.artifacts:
            runtime.import_route_artifact(
                artifact.path,
                route=route,
                artifact_format=artifact.format,
                source_url=artifact.source_url,
                discovery_provenance={
                    **artifact.discovery_provenance,
                    "host_observation_request_id": observation.request_id,
                    "host_evidence_source": observation.evidence_source,
                },
                lawful_access_basis=artifact.lawful_access_basis,
                open_access=artifact.open_access,
                version=artifact.version,
                license=artifact.license,
                metadata=artifact.metadata,
            )
            admitted += 1
        runtime.record_route_attempt(
            route,
            action=observation.action,
            outcome="success",
            url=observation.artifacts[0].source_url,
            http_status=observation.http_status,
            message=observation.message,
            metadata={
                "observation_kind": observation.kind.value,
                "admitted_artifacts": admitted,
                "definitive_negative": False,
            },
        )
        return True

    if observation.kind == RouteObservationKind.DEFINITIVE_NO_RESULT:
        if not observation.evidence_source:
            raise RuntimeProtocolError(
                f"Definitive negative evidence for {route.value} requires evidence_source"
            )
        runtime.record_route_attempt(
            route,
            action=observation.action,
            outcome="miss",
            http_status=observation.http_status,
            message=observation.message,
            metadata={
                **observation.metadata,
                "observation_kind": observation.kind.value,
                "definitive_negative": True,
                "evidence_source": observation.evidence_source,
            },
        )
        return False

    outcome = "skipped" if observation.kind == RouteObservationKind.SKIPPED else "error"
    runtime.record_route_attempt(
        route,
        action=observation.action,
        outcome=outcome,
        http_status=observation.http_status,
        message=observation.message,
        metadata={
            **observation.metadata,
            "observation_kind": observation.kind.value,
            "definitive_negative": False,
            "evidence_source": observation.evidence_source,
        },
    )
    return False


def can_assign_exhausted(runtime: ChatGptVerticalSliceRuntime) -> tuple[bool, list[str]]:
    enabled = runtime.route_capabilities.enabled()
    if not enabled:
        return False, ["no enabled routes"]
    attempts = runtime._attempts()
    reasons: list[str] = []
    for route in enabled:
        route_attempts = [a for a in attempts if a.provider == route]
        if not route_attempts:
            reasons.append(f"{route}: unexecuted")
            continue
        if not any(
            a.outcome == "miss" and a.metadata.get("definitive_negative") is True
            for a in route_attempts
        ):
            kinds = [str(a.metadata.get("observation_kind") or a.outcome) for a in route_attempts]
            reasons.append(f"{route}: no definitive negative evidence ({','.join(kinds)})")
    return not reasons, reasons


def _write_non_success_manifest(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    elapsed_ms: int,
) -> Path:
    manifest_path = runtime.session.session_dir / "acquisition_manifest.json"
    terminal = (
        runtime.session.terminal_outcome.model_dump(mode="json")
        if runtime.session.terminal_outcome
        else None
    )
    document = {
        "schema_version": "3",
        "contract_version": runtime.contract_version,
        "product": "acquire_one",
        "identifier": runtime.session.identifier.model_dump(mode="json"),
        "resolved_ids": runtime.session.seed.ids.model_dump(mode="json"),
        "article_identity": runtime.session.seed.metadata.get("v0_4", {}).get("article_identity"),
        "normalized_title": runtime.session.seed.metadata.get("v0_4", {}).get("normalized_title"),
        "identity_evidence": runtime.session.seed.metadata.get("v0_4", {}).get("identity_evidence"),
        "state": runtime.session.state.value,
        "route_capabilities": runtime.session.seed.metadata.get("v0_4", {}).get("route_capabilities"),
        "provider_attempts": [x.model_dump(mode="json") for x in runtime._attempts()],
        "artifacts": [x.model_dump(mode="json") for x in runtime.session.seed.artifacts],
        "terminal_outcome": terminal,
        "run_receipt": str(runtime.receipt_path),
        "event_journal": str(runtime.events_path),
        "terminal_outcome_path": str(runtime.session.session_dir / runtime.terminal_filename),
        "runtime_elapsed_ms": elapsed_ms,
    }
    manifest_path.write_text(
        json.dumps(document, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    runtime._event(
        "acquisition_manifest_written",
        data={"manifest_path": str(manifest_path), "state": runtime.session.state.value},
    )
    runtime._save()
    return manifest_path


def acquire_one(
    identifier: str | ArticleIdentifier,
    config: AcquisitionConfig,
    root: Path,
    host: HostAdapter,
    transports: TransportRegistry | None = None,
) -> AcquisitionExecution:
    """Production v0.4.3 acquisition entry point.

    Caller input is limited to identifier, configuration, root, host adapter, and
    transport registry. Terminal state, resolved identity, route outcomes, and
    artifact paths cannot be supplied through this API.
    """

    started = time.perf_counter()
    ident = identifier if isinstance(identifier, ArticleIdentifier) else ArticleIdentifier.parse(identifier)
    if ident.kind != IdentifierKind.PMID:
        raise RuntimeProtocolError("v0.4.3 Prompt 1 production controller currently requires PMID input")
    runtime = ChatGptVerticalSliceRuntime.create(
        ident,
        root,
        route_capabilities=config.route_capabilities,
    )
    runtime.session.seed.metadata["v0_4"]["product"] = "acquire_one"
    runtime.session.seed.metadata["v0_4"]["route_capabilities"] = config.route_capabilities.model_dump(mode="json")
    runtime.session.seed.metadata["v0_4"]["transport_registry"] = (transports or TransportRegistry()).model_dump(mode="json")
    runtime._event(
        "production_acquire_one_started",
        data={
            "identifier": ident.model_dump(mode="json"),
            "route_capabilities": config.route_capabilities.model_dump(mode="json"),
        },
    )
    runtime._save()

    try:
        identity = _resolve_identity(runtime, ident, host)
        for route in config.route_capabilities.enabled_routes():
            observation = _observe_route(runtime, ident, identity, route, host)
            if _admit_route_observation(runtime, observation):
                step = runtime.step()
                if step.state == RuntimeState.SUCCESS:
                    break
        else:
            step = None

        if runtime.session.state == RuntimeState.READY:
            exhaustive, reasons = can_assign_exhausted(runtime)
            if exhaustive:
                runtime.mark_exhausted("Every enabled route returned definitive negative evidence")
            else:
                runtime.mark_blocked(
                    "Acquisition coverage is incomplete or uncertain: " + "; ".join(reasons),
                    reason_code=RuntimeFailureCode.EXTERNAL_FETCH_BLOCKED,
                )
        step = runtime.step()
    except RuntimeProtocolError as exc:
        text = str(exc)
        code = RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR
        if text.startswith("IDENTITY_MISMATCH"):
            code = RuntimeFailureCode.IDENTITY_MISMATCH
        elif text.startswith("IDENTITY_UNVERIFIED"):
            code = RuntimeFailureCode.IDENTITY_UNVERIFIED
        runtime.mark_failed(text, reason_code=code)
        step = runtime.step()
    except Exception as exc:
        runtime.mark_blocked(
            f"Host observation failed: {type(exc).__name__}: {exc}",
            reason_code=RuntimeFailureCode.TOOL_FAILURE,
        )
        step = runtime.step()

    elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
    manifest_path = step.result.manifest_path if step.result else None
    if manifest_path is None:
        manifest_path = _write_non_success_manifest(runtime, elapsed_ms=elapsed_ms)

    return AcquisitionExecution(
        pmid=ident.value,
        state=step.state,
        elapsed_ms=elapsed_ms,
        session_path=runtime.session_path,
        run_receipt=runtime.receipt_path,
        event_journal=runtime.events_path,
        manifest_path=manifest_path,
        result=step.result,
        terminal_outcome=step.terminal_outcome,
        metrics={"runtime_elapsed_ms": elapsed_ms},
    )
