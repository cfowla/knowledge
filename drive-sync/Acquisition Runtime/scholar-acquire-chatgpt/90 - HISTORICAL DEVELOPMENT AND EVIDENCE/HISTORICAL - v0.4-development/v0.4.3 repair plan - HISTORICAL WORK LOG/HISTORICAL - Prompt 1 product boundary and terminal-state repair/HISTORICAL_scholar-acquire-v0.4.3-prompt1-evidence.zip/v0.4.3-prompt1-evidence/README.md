# v0.4.3 Prompt 1 evidence package

This package preserves the Prompt 1 repair evidence for scholar-acquire-chatgpt v0.4.3.

- `reports/` contains the repair report, migration notes, and build provenance.
- `evidence/` contains tests, build-integrity verification, input hashes, and the exact source diff from v0.4.2.
- `real_check/` contains the production-path run for PMID 24782981, including receipt, append-only journal, identity report, terminal outcome, manifest, handoff, and admitted PDF.
- `source_evidence/` contains the preserved v0.4.2 manifest and lawful OA PDF used for the required real check.

The real-check PDF and the preserved source PDF must both hash to:

`54465e3c056b86551d8c5d865b0685d01a5f4fa2c11bc705a479768b3efc63cb`
