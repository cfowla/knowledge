from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path
from typing import Any

from scholar_acquire import (
    AcquisitionConfig,
    AcquisitionRoute,
    CapabilityStatus,
    ChatGptNativeMaterializedTransport,
    DeferredRemoteTransport,
    HostRequest,
    HostRequestKind,
    IdentityObservation,
    RouteCapabilityRegistry,
    RouteObservation,
    RouteObservationKind,
    TransportLocationObservation,
    TransportRegistry,
    TransportResponse,
    acquire_one,
    resume_acquire_one,
)
from scholar_acquire.models import ArtifactFormat, SourceVersion

PMID = "24782981"
PMCID = "PMC3995050"
DOI = "10.3389/fonc.2014.00064"
TITLE = "Targeting PI3K/Akt/mTOR Signaling in Cancer"
PDF_URL = "https://www.frontiersin.org/journals/oncology/articles/10.3389/fonc.2014.00064/pdf"
JATS_URL = f"https://www.ebi.ac.uk/europepmc/webservices/rest/{PMCID}/fullTextXML"


class ProofHost:
    def __init__(self, route: AcquisitionRoute):
        self.route = route

    def observe(self, request: HostRequest):
        if request.kind == HostRequestKind.RESOLVE_IDENTITY:
            return IdentityObservation(
                request_id=request.request_id,
                pmid=PMID,
                pmcid=PMCID,
                doi=DOI,
                title=TITLE,
                journal="Frontiers in Oncology",
                year=2014,
                evidence_source="https://pubmed.ncbi.nlm.nih.gov/24782981/",
                evidence_method="ChatGPT web scholarly lookup; PMID/PMCID/DOI/title matched",
                metadata={"prompt": 2, "proof_only": True},
            )
        if request.kind != HostRequestKind.OBSERVE_ROUTE or request.route != self.route:
            raise RuntimeError(f"unexpected host request: {request.kind} {request.route}")
        if self.route == AcquisitionRoute.PUBLISHER_OA:
            location = TransportLocationObservation(
                url=PDF_URL,
                format=ArtifactFormat.PDF,
                expected_media_type="application/pdf",
                discovery_provenance={
                    "method": "Frontiers article page Download PDF link",
                    "article_url": "https://www.frontiersin.org/journals/oncology/articles/10.3389/fonc.2014.00064/full",
                },
                lawful_access_basis="Publisher-hosted open-access article; Creative Commons Attribution license",
                open_access=True,
                version=SourceVersion.PUBLISHED,
                license="CC BY",
            )
        elif self.route == AcquisitionRoute.PMC:
            location = TransportLocationObservation(
                url=JATS_URL,
                format=ArtifactFormat.JATS_XML,
                expected_media_type="application/xml",
                discovery_provenance={
                    "method": "Europe PMC documented fullTextXML endpoint for PMC OA full text",
                    "pmcid": PMCID,
                },
                lawful_access_basis="Europe PMC/PMC open-access full-text XML service",
                open_access=True,
                version=SourceVersion.PUBLISHED,
                license="CC BY",
            )
        else:
            raise RuntimeError(f"unexpected proof route: {self.route}")
        return RouteObservation(
            request_id=request.request_id,
            route=self.route,
            kind=RouteObservationKind.LOCATION_DISCOVERED,
            action="prompt2_live_transport_proof",
            locations=[location],
            evidence_source=location.discovery_provenance.get("article_url") or "https://europepmc.org/RestfulWebService",
            metadata={"prompt": 2, "proof_only": True},
        )


def caps(route: AcquisitionRoute) -> RouteCapabilityRegistry:
    values: dict[str, CapabilityStatus] = {
        "pmc": CapabilityStatus.DISABLED,
        "publisher_oa": CapabilityStatus.DISABLED,
        "unpaywall": CapabilityStatus.DISABLED,
        "repository": CapabilityStatus.DISABLED,
    }
    values[route.value] = CapabilityStatus.EXPERIMENTAL
    return RouteCapabilityRegistry(**values)


def _single_request(session_path: Path) -> Path:
    session = json.loads(session_path.read_text(encoding="utf-8"))
    session_dir = session_path.parent
    request_paths = sorted((session_dir / "transport" / "requests").glob("*.json"))
    if len(request_paths) != 1:
        raise RuntimeError(f"expected exactly one transport request, got {len(request_paths)}")
    return request_paths[0]


def prepare(root: Path, native_pdf: Path, out: Path) -> dict[str, Any]:
    out.mkdir(parents=True, exist_ok=True)
    native_root = root / "native_pdf"
    remote_root = root / "remote_jats"
    config_pdf = AcquisitionConfig(
        want_structured=False,
        want_pdf=True,
        route_capabilities=caps(AcquisitionRoute.PUBLISHER_OA),
    )
    native_transport = ChatGptNativeMaterializedTransport(
        {PDF_URL: native_pdf},
        headers={"content-type": "application/pdf"},
    )
    native_execution = acquire_one(
        PMID,
        config_pdf,
        native_root,
        ProofHost(AcquisitionRoute.PUBLISHER_OA),
        TransportRegistry([native_transport]),
    )
    if native_execution.state.value != "success":
        raise RuntimeError(f"native integrated proof did not succeed: {native_execution.state}")
    pdf_request = _single_request(native_execution.session_path)
    pdf_response_paths = list((native_execution.session_path.parent / "transport" / "responses").glob("*.json"))
    if len(pdf_response_paths) != 1:
        raise RuntimeError("native proof did not preserve exactly one response")

    config_jats = AcquisitionConfig(
        want_structured=True,
        want_pdf=False,
        route_capabilities=caps(AcquisitionRoute.PMC),
    )
    remote_execution = acquire_one(
        PMID,
        config_jats,
        remote_root,
        ProofHost(AcquisitionRoute.PMC),
        TransportRegistry([
            ChatGptNativeMaterializedTransport({}),
            DeferredRemoteTransport(),
        ]),
    )
    if remote_execution.state.value != "needs_fetch":
        raise RuntimeError(f"remote proof did not suspend: {remote_execution.state}")
    jats_request = _single_request(remote_execution.session_path)

    shutil.copy2(pdf_request, out / "ordinary_pdf_request.json")
    shutil.copy2(jats_request, out / "pmc_jats_request.json")
    shutil.copy2(pdf_response_paths[0], out / "ordinary_pdf_native_response.json")
    summary = {
        "pmid": PMID,
        "native_pdf": {
            "state": native_execution.state.value,
            "session_path": str(native_execution.session_path),
            "manifest_path": str(native_execution.manifest_path),
            "request": str(out / "ordinary_pdf_request.json"),
            "native_response": str(out / "ordinary_pdf_native_response.json"),
            "artifact_sha256": native_execution.result.artifacts[0].sha256 if native_execution.result else None,
        },
        "remote_jats": {
            "state": remote_execution.state.value,
            "session_path": str(remote_execution.session_path),
            "request": str(out / "pmc_jats_request.json"),
        },
    }
    (out / "prepare_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    return summary


def finish(root: Path, proof_dir: Path) -> dict[str, Any]:
    prep = json.loads((proof_dir / "prepare_summary.json").read_text(encoding="utf-8"))
    native_response = TransportResponse.model_validate_json((proof_dir / "ordinary_pdf_native_response.json").read_text())
    remote_pdf_response = TransportResponse.model_validate_json((proof_dir / "ordinary_pdf_remote_response.json").read_text())
    if native_response.transport_checksum != remote_pdf_response.transport_checksum:
        raise RuntimeError("native/remote PDF transport checksums differ")
    if native_response.byte_count != remote_pdf_response.byte_count:
        raise RuntimeError("native/remote PDF byte counts differ")

    remote_jats_response_path = proof_dir / "pmc_jats_remote_response.json"
    remote_jats_response = TransportResponse.model_validate_json(remote_jats_response_path.read_text())
    execution = resume_acquire_one(
        Path(prep["remote_jats"]["session_path"]),
        ProofHost(AcquisitionRoute.PMC),
        response=remote_jats_response,
    )
    if execution.state.value != "success":
        raise RuntimeError(f"integrated JATS resume did not succeed: {execution.state}")
    artifact = execution.result.artifacts[0]
    payload = artifact.local_path.read_bytes()
    result = {
        "pmid": PMID,
        "ordinary_parity": {
            "native_checksum": native_response.transport_checksum,
            "remote_checksum": remote_pdf_response.transport_checksum,
            "native_byte_count": native_response.byte_count,
            "remote_byte_count": remote_pdf_response.byte_count,
            "equal": native_response.transport_checksum == remote_pdf_response.transport_checksum and native_response.byte_count == remote_pdf_response.byte_count,
        },
        "pmc_jats": {
            "state": execution.state.value,
            "session_path": str(execution.session_path),
            "manifest_path": str(execution.manifest_path),
            "transport_checksum": remote_jats_response.transport_checksum,
            "transport_byte_count": remote_jats_response.byte_count,
            "python_artifact_sha256": artifact.sha256,
            "python_artifact_byte_count": artifact.size_bytes,
            "artifact_path": str(artifact.local_path),
            "artifact_recomputed_sha256": hashlib.sha256(payload).hexdigest(),
            "transport_evidence": [str(p) for p in execution.transport_evidence],
        },
    }
    (proof_dir / "final_summary.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--root", type=Path, required=True)
    p.add_argument("--native-pdf", type=Path, required=True)
    p.add_argument("--out", type=Path, required=True)
    f = sub.add_parser("finish")
    f.add_argument("--root", type=Path, required=True)
    f.add_argument("--proof-dir", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        print(json.dumps(prepare(args.root, args.native_pdf, args.out), indent=2))
    else:
        print(json.dumps(finish(args.root, args.proof_dir), indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
