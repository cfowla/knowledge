import inspect
from pathlib import Path

import pytest

from scholar_acquire import (
    AcquisitionConfig,
    AcquisitionReplaySpec,
    CapabilityStatus,
    HostRequestKind,
    IdentityObservation,
    RouteCapabilityRegistry,
    RouteObservation,
    RouteObservationKind,
    acquire_one,
    replay_acquisition,
)
from scholar_acquire.models import RuntimeState
from scholar_acquire import AcquisitionRoute


class ScenarioHost:
    def __init__(self, kind: RouteObservationKind):
        self.kind = kind

    def observe(self, request):
        if request.kind == HostRequestKind.RESOLVE_IDENTITY:
            return IdentityObservation(
                request_id=request.request_id,
                pmid=request.identifier.value,
                title="Prompt one contract test article",
                journal="Test Journal",
                year=2026,
                evidence_source=f"https://pubmed.ncbi.nlm.nih.gov/{request.identifier.value}/",
                evidence_method="test host metadata observation",
            )
        return RouteObservation(
            request_id=request.request_id,
            route=request.route,
            kind=self.kind,
            action="test_route_observation",
            evidence_source=(
                "https://example.org/definitive-provider-record"
                if self.kind == RouteObservationKind.DEFINITIVE_NO_RESULT
                else None
            ),
            message=self.kind.value,
        )


def one_route_config() -> AcquisitionConfig:
    return AcquisitionConfig(
        route_capabilities=RouteCapabilityRegistry(
            pmc=CapabilityStatus.EXPERIMENTAL,
            publisher_oa=CapabilityStatus.DISABLED,
            unpaywall=CapabilityStatus.DISABLED,
            repository=CapabilityStatus.DISABLED,
        )
    )


def test_production_api_starts_from_identifier_and_configuration():
    params = list(inspect.signature(acquire_one).parameters)
    assert params == ["identifier", "config", "root", "host", "transports"]
    assert "terminal_state" not in AcquisitionConfig.model_fields
    assert "identity" not in AcquisitionConfig.model_fields
    assert "artifacts" not in AcquisitionConfig.model_fields
    assert "attempts" not in AcquisitionConfig.model_fields


def test_replay_is_explicitly_separate():
    assert AcquisitionReplaySpec is not None
    assert replay_acquisition is not acquire_one
    assert "terminal_state" in AcquisitionReplaySpec.model_fields
    assert "artifacts" in AcquisitionReplaySpec.model_fields


def test_initial_capability_registry_claims_no_supported_routes():
    registry = RouteCapabilityRegistry()
    assert registry.pmc == CapabilityStatus.EXPERIMENTAL
    assert registry.publisher_oa == CapabilityStatus.EXPERIMENTAL
    assert registry.unpaywall == CapabilityStatus.EXPERIMENTAL
    assert registry.repository == CapabilityStatus.EXPERIMENTAL
    assert CapabilityStatus.SUPPORTED not in {
        registry.pmc,
        registry.publisher_oa,
        registry.unpaywall,
        registry.repository,
    }


@pytest.mark.parametrize(
    "kind",
    [
        RouteObservationKind.TRANSPORT_ERROR,
        RouteObservationKind.TIMEOUT,
        RouteObservationKind.CAPTCHA,
        RouteObservationKind.RESPONSE_NOT_MATERIALIZABLE,
        RouteObservationKind.UNKNOWN,
        RouteObservationKind.SEARCH_ABSENCE,
        RouteObservationKind.SKIPPED,
    ],
)
def test_uncertain_or_transport_conditions_cannot_force_exhausted(tmp_path: Path, kind):
    execution = acquire_one(
        identifier="12345678",
        config=one_route_config(),
        root=tmp_path / kind.value,
        host=ScenarioHost(kind),
    )
    assert execution.state == RuntimeState.BLOCKED
    assert execution.terminal_outcome is not None
    assert execution.terminal_outcome.provider_exhaustion_confirmed is False
    assert execution.manifest_path and execution.manifest_path.is_file()
    assert execution.run_receipt.is_file()
    assert execution.event_journal.is_file()


def test_exhausted_requires_definitive_negative_evidence_for_every_enabled_route(tmp_path: Path):
    execution = acquire_one(
        identifier="12345678",
        config=one_route_config(),
        root=tmp_path / "definitive",
        host=ScenarioHost(RouteObservationKind.DEFINITIVE_NO_RESULT),
    )
    assert execution.state == RuntimeState.EXHAUSTED
    assert execution.terminal_outcome is not None
    assert execution.terminal_outcome.provider_exhaustion_confirmed is True
    attempts = execution.terminal_outcome.provider_attempts
    assert len(attempts) == 1
    assert attempts[0].metadata["definitive_negative"] is True


def test_unexecuted_enabled_route_prohibits_exhausted(tmp_path: Path):
    config = AcquisitionConfig(
        route_capabilities=RouteCapabilityRegistry(
            pmc=CapabilityStatus.DISABLED,
            publisher_oa=CapabilityStatus.DISABLED,
            unpaywall=CapabilityStatus.DISABLED,
            repository=CapabilityStatus.DISABLED,
        )
    )
    execution = acquire_one(
        identifier="12345678",
        config=config,
        root=tmp_path / "none-enabled",
        host=ScenarioHost(RouteObservationKind.DEFINITIVE_NO_RESULT),
    )
    assert execution.state == RuntimeState.BLOCKED
    assert execution.terminal_outcome.provider_exhaustion_confirmed is False
