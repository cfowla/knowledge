from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from .models import AcquisitionResult, ArtifactFormat, AtomSeaHandoff
from .utils import extract_jats_article, validate_pdf


def build_atom_sea_handoff(result: AcquisitionResult, manifest_path: Path | None = None) -> AtomSeaHandoff:
    structured = next((a for a in result.artifacts if a.format == ArtifactFormat.JATS_XML), None)
    if structured is None:
        structured = next((a for a in result.artifacts if a.structured), None)
    pdf = next((a for a in result.artifacts if a.format == ArtifactFormat.PDF), None)
    return AtomSeaHandoff(
        identifier=result.identifier,
        resolved_ids=result.resolved_ids,
        preferred_structured_path=structured.local_path if structured else None,
        preferred_pdf_path=pdf.local_path if pdf else None,
        structured_sha256=structured.sha256 if structured else None,
        pdf_sha256=pdf.sha256 if pdf else None,
        manifest_path=manifest_path,
    )


def prove_atom_sea_handoff(result: AcquisitionResult) -> Path:
    """Consume the acquisition handoff exactly as ATOM/SEA would and emit proof.

    This is deliberately provider-blind. It validates only the handoff contract:
    reusable local payload paths, expected formats, SHA-256 integrity, and the
    acquisition manifest. No discovery/provider behavior leaks downstream.
    """
    if result.handoff is None:
        raise ValueError("Acquisition result has no ATOM/SEA handoff")
    h = result.handoff
    checks: dict[str, bool] = {}
    payloads: list[dict] = []

    if h.preferred_structured_path is not None:
        body = h.preferred_structured_path.read_bytes()
        extract_jats_article(body)
        digest = hashlib.sha256(body).hexdigest()
        checks["structured_path_exists"] = h.preferred_structured_path.is_file()
        checks["structured_hash_matches"] = digest == h.structured_sha256
        payloads.append({"role": "preferred_structured", "path": str(h.preferred_structured_path), "sha256": digest, "format": "jats_xml"})

    if h.preferred_pdf_path is not None:
        body = h.preferred_pdf_path.read_bytes()
        validate_pdf(body)
        digest = hashlib.sha256(body).hexdigest()
        checks["pdf_path_exists"] = h.preferred_pdf_path.is_file()
        checks["pdf_hash_matches"] = digest == h.pdf_sha256
        payloads.append({"role": "preferred_pdf", "path": str(h.preferred_pdf_path), "sha256": digest, "format": "pdf"})

    checks["has_reusable_payload"] = bool(payloads)
    checks["manifest_exists"] = bool(h.manifest_path and h.manifest_path.is_file())
    accepted = all(checks.values())
    out_dir = (h.manifest_path.parent if h.manifest_path else result.artifacts[0].local_path.parent)
    receipt = out_dir / "ATOM_SEA_HANDOFF.json"
    document = {
        "schema_version": "1",
        "consumer_interface": "ATOM/SEA",
        "identifier": result.identifier.model_dump(mode="json"),
        "resolved_ids": result.resolved_ids.model_dump(mode="json"),
        "accepted": accepted,
        "preferred_input": str(h.preferred_structured_path or h.preferred_pdf_path),
        "secondary_input": str(h.preferred_pdf_path) if h.preferred_structured_path and h.preferred_pdf_path else None,
        "payloads": payloads,
        "manifest_path": str(h.manifest_path) if h.manifest_path else None,
        "checks": checks,
        "verified_at": datetime.now(timezone.utc).isoformat(),
    }
    receipt.write_text(json.dumps(document, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not accepted:
        raise ValueError(f"ATOM/SEA handoff validation failed: {checks}")
    return receipt
