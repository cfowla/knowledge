import base64
from datetime import datetime, timezone
from pathlib import Path

from scholar_acquire import (
    AcquisitionConfig,
    AcquisitionRoute,
    CapabilityStatus,
    DeferredRemoteTransport,
    HostRequestKind,
    IdentityObservation,
    RouteCapabilityRegistry,
    RouteObservation,
    RouteObservationKind,
    TransportKind,
    TransportLocationObservation,
    TransportRegistry,
    TransportRequest,
    TransportResponse,
    TransportResponseState,
    acquire_one,
)
from scholar_acquire.models import ArtifactFormat, RuntimeState, SourceVersion

PDF = b"%PDF-1.4\n1 0 obj<</Type/Catalog>>endobj\n%%EOF\n"


class LocationHost:
    def observe(self, request):
        if request.kind == HostRequestKind.RESOLVE_IDENTITY:
            return IdentityObservation(
                request_id=request.request_id,
                pmid=request.identifier.value,
                title="Transport contract article",
                evidence_source=f"https://pubmed.ncbi.nlm.nih.gov/{request.identifier.value}/",
                evidence_method="test metadata",
            )
        return RouteObservation(
            request_id=request.request_id,
            route=request.route,
            kind=RouteObservationKind.LOCATION_DISCOVERED,
            action="transport_test",
            evidence_source="https://example.org/open-access-record",
            locations=[TransportLocationObservation(
                url="https://example.org/article.pdf",
                format=ArtifactFormat.PDF,
                expected_media_type="application/pdf",
                discovery_provenance={"method":"test"},
                lawful_access_basis="public OA test fixture",
                open_access=True,
                version=SourceVersion.PUBLISHED,
            )],
        )


def config():
    return AcquisitionConfig(
        want_structured=False,
        want_pdf=True,
        route_capabilities=RouteCapabilityRegistry(
            pmc=CapabilityStatus.EXPERIMENTAL,
            publisher_oa=CapabilityStatus.DISABLED,
            unpaywall=CapabilityStatus.DISABLED,
            repository=CapabilityStatus.DISABLED,
        ),
    )


def test_transport_contract_has_only_transport_facts():
    request = TransportRequest.build(
        url="https://example.org/article.pdf",
        source_route=AcquisitionRoute.PMC,
        expected_media_type="application/pdf",
    )
    assert not hasattr(request, "terminal_state")
    assert not hasattr(request, "open_access")
    assert not hasattr(request, "resolved_ids")
    assert request.method in {"GET", "HEAD"}


def test_registry_prefers_native_before_remote():
    calls=[]
    class Native:
        name='native-test'; kind=TransportKind.NATIVE
        def execute(self, request): calls.append(self.name); raise RuntimeError('native cannot materialize')
    class Remote:
        name='remote-test'; kind=TransportKind.REMOTE
        def execute(self, request): calls.append(self.name); return None
    r=TransportRegistry([Remote(), Native()])
    req=TransportRequest.build(url='https://example.org/x',source_route=AcquisitionRoute.PMC)
    dispatch=r.dispatch(req)
    assert calls==['native-test','remote-test']
    assert dispatch.deferred_transport=='remote-test'


def test_acquire_one_suspends_for_deferred_remote_transport(tmp_path: Path):
    run=acquire_one('12345678',config(),tmp_path,LocationHost(),TransportRegistry([DeferredRemoteTransport()]))
    assert run.state==RuntimeState.NEEDS_FETCH
    assert run.pending_transport_request is not None
    assert Path(run.pending_transport_request['url']).name == 'article.pdf'
    events=run.event_journal.read_text()
    assert 'transport_suspended' in events
    assert 'terminal_exhausted' not in events


def test_transport_error_cannot_be_exhausted(tmp_path: Path):
    class ErrorTransport:
        name='native-error'; kind=TransportKind.NATIVE
        def execute(self, request): raise TimeoutError('timeout')
    run=acquire_one('12345678',config(),tmp_path,LocationHost(),TransportRegistry([ErrorTransport()]))
    assert run.state==RuntimeState.BLOCKED
    assert run.terminal_outcome.provider_exhaustion_confirmed is False


def test_response_correlation_and_checksum_are_fail_closed():
    req=TransportRequest.build(url='https://example.org/x',source_route=AcquisitionRoute.PMC)
    now=datetime.now(timezone.utc)
    response=TransportResponse(
        request_id=req.request_id,
        correlation_id=req.correlation_id,
        transport_name='remote',
        transport_kind=TransportKind.REMOTE,
        transport_state=TransportResponseState.RESPONSE,
        requested_url=req.url,
        final_url=req.url,
        status_code=200,
        headers={'content-type':'application/pdf'},
        body_base64=base64.b64encode(PDF).decode(),
        byte_count=len(PDF),
        transport_checksum='0'*64,
        started_at=now,
        finished_at=now,
        elapsed_ms=0,
    )
    try:
        response.validate_correlation(req)
    except Exception as exc:
        assert 'checksum mismatch' in str(exc)
    else:
        raise AssertionError('checksum mismatch was accepted')


def test_chatgpt_native_materialized_transport_uses_shared_response_contract(tmp_path: Path) -> None:
    from scholar_acquire.transport_contract import ChatGptNativeMaterializedTransport

    body = b"%PDF-1.4\nexample\n%%EOF\n"
    path = tmp_path / "article.pdf"
    path.write_bytes(body)
    request = TransportRequest.build(
        url="https://example.org/article.pdf",
        source_route=AcquisitionRoute.PUBLISHER_OA,
        expected_media_type="application/pdf",
    )
    transport = ChatGptNativeMaterializedTransport(
        {request.request_id: path}, headers={"content-type": "application/pdf"}
    )
    response = transport.execute(request)
    assert response is not None
    assert response.transport_kind == TransportKind.NATIVE
    assert response.validate_correlation(request) == body


def test_native_no_bytes_falls_through_to_remote_defer():
    from scholar_acquire.transport_contract import ChatGptNativeMaterializedTransport

    request = TransportRequest.build(
        url="https://example.org/article.xml",
        source_route=AcquisitionRoute.PMC,
        expected_media_type="application/xml",
    )
    registry = TransportRegistry([
        ChatGptNativeMaterializedTransport({}),
        DeferredRemoteTransport(),
    ])
    dispatch = registry.dispatch(request)
    assert [x["outcome"] for x in dispatch.attempts] == ["not_materialized", "deferred"]
    assert dispatch.deferred_transport == "github_actions_remote"
