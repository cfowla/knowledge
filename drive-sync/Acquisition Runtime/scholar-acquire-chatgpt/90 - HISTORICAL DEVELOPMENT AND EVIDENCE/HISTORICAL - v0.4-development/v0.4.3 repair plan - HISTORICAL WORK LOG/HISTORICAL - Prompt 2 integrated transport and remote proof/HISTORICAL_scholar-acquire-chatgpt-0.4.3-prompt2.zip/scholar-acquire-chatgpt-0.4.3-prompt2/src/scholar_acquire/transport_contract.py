from __future__ import annotations

import base64
import hashlib
import json
import secrets
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Literal, Mapping, Protocol

from pydantic import BaseModel, Field, model_validator

from .capabilities import AcquisitionRoute
from .errors import RuntimeProtocolError


class TransportKind(str, Enum):
    NATIVE = "native"
    REMOTE = "remote"


class TransportResponseState(str, Enum):
    RESPONSE = "response"
    ERROR = "error"


class TransportRequest(BaseModel):
    """Transport-only request emitted after Python has authorized a location."""

    schema_version: str = "2"
    request_id: str
    correlation_id: str
    url: str
    method: Literal["GET", "HEAD"] = "GET"
    headers: dict[str, str] = Field(default_factory=dict)
    timeout_seconds: int = 60
    expected_media_type: str | None = None
    source_route: AcquisitionRoute
    provenance_context: dict[str, Any] = Field(default_factory=dict)
    max_bytes: int | None = 128 * 1024 * 1024
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def build(
        cls,
        *,
        url: str,
        source_route: AcquisitionRoute,
        method: Literal["GET", "HEAD"] = "GET",
        headers: Mapping[str, str] | None = None,
        timeout_seconds: int = 60,
        expected_media_type: str | None = None,
        provenance_context: Mapping[str, Any] | None = None,
        max_bytes: int | None = 128 * 1024 * 1024,
        correlation_id: str | None = None,
    ) -> "TransportRequest":
        canonical_headers = {str(k).lower(): str(v) for k, v in sorted((headers or {}).items())}
        material = json.dumps(
            {
                "method": method,
                "url": url,
                "headers": canonical_headers,
                "timeout_seconds": timeout_seconds,
                "expected_media_type": expected_media_type,
                "source_route": source_route.value,
                "max_bytes": max_bytes,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return cls(
            request_id=hashlib.sha256(material).hexdigest()[:24],
            correlation_id=correlation_id or secrets.token_hex(12),
            url=url,
            method=method,
            headers=dict(headers or {}),
            timeout_seconds=timeout_seconds,
            expected_media_type=expected_media_type,
            source_route=source_route,
            provenance_context=dict(provenance_context or {}),
            max_bytes=max_bytes,
        )


class TransportResponse(BaseModel):
    """Low-level transport response. It carries no scholarly decisions."""

    schema_version: str = "2"
    request_id: str
    correlation_id: str
    transport_name: str
    transport_kind: TransportKind
    transport_state: TransportResponseState
    requested_url: str
    final_url: str | None = None
    status_code: int | None = None
    headers: dict[str, str] = Field(default_factory=dict)
    body_base64: str | None = None
    materialized_path: Path | None = None
    byte_count: int | None = None
    transport_checksum: str | None = None
    started_at: datetime
    finished_at: datetime
    elapsed_ms: int
    error_type: str | None = None
    error_message: str | None = None

    @model_validator(mode="after")
    def _shape(self) -> "TransportResponse":
        if self.transport_state == TransportResponseState.RESPONSE:
            if self.status_code is None:
                raise ValueError("response transport state requires status_code")
            if self.body_base64 is None and self.materialized_path is None:
                raise ValueError("response transport state requires body_base64 or materialized_path")
            if self.byte_count is None or self.transport_checksum is None:
                raise ValueError("response transport state requires byte_count and transport_checksum")
        return self

    def payload_bytes(self) -> bytes:
        if self.transport_state != TransportResponseState.RESPONSE:
            raise RuntimeProtocolError("Transport error responses do not contain admissible payload bytes")
        if self.body_base64 is not None:
            try:
                return base64.b64decode(self.body_base64, validate=True)
            except Exception as exc:
                raise RuntimeProtocolError("Transport body_base64 is invalid") from exc
        if self.materialized_path is None or not self.materialized_path.is_file():
            raise RuntimeProtocolError("Transport materialized_path is missing")
        return self.materialized_path.read_bytes()

    def validate_correlation(self, request: TransportRequest) -> bytes:
        if self.request_id != request.request_id:
            raise RuntimeProtocolError(
                f"transport request_id mismatch: expected {request.request_id}, got {self.request_id}"
            )
        if self.correlation_id != request.correlation_id:
            raise RuntimeProtocolError("transport correlation_id mismatch")
        if self.requested_url != request.url:
            raise RuntimeProtocolError("transport requested_url does not match authorized request")
        if self.transport_state != TransportResponseState.RESPONSE:
            raise RuntimeProtocolError(
                f"transport failed: {self.error_type or 'error'}: {self.error_message or 'unknown transport error'}"
            )
        body = self.payload_bytes()
        if request.max_bytes is not None and len(body) > request.max_bytes:
            raise RuntimeProtocolError(
                f"transport payload exceeds authorized max_bytes ({len(body)} > {request.max_bytes})"
            )
        if self.byte_count != len(body):
            raise RuntimeProtocolError(
                f"transport byte_count mismatch: declared {self.byte_count}, actual {len(body)}"
            )
        digest = hashlib.sha256(body).hexdigest()
        if digest != self.transport_checksum:
            raise RuntimeProtocolError(
                f"transport checksum mismatch: declared {self.transport_checksum}, actual {digest}"
            )
        return body


class TransportExecutor(Protocol):
    name: str
    kind: TransportKind

    def execute(self, request: TransportRequest) -> TransportResponse | None:
        """Return a response, or None when execution is intentionally deferred."""
        ...


class TransportDispatch(BaseModel):
    request: TransportRequest
    response: TransportResponse | None = None
    deferred_transport: str | None = None
    attempts: list[dict[str, Any]] = Field(default_factory=list)


class TransportRegistry:
    """Python-owned execution preference: native first, remote second."""

    def __init__(self, executors: list[TransportExecutor] | None = None):
        self._executors: list[TransportExecutor] = list(executors or [])

    def register(self, executor: TransportExecutor) -> "TransportRegistry":
        self._executors.append(executor)
        return self

    @property
    def executors(self) -> tuple[TransportExecutor, ...]:
        return tuple(self._executors)

    def describe(self) -> list[dict[str, str]]:
        return [{"name": x.name, "kind": x.kind.value} for x in self._executors]

    def dispatch(self, request: TransportRequest) -> TransportDispatch:
        ordered = sorted(
            enumerate(self._executors),
            key=lambda item: (0 if item[1].kind == TransportKind.NATIVE else 1, item[0]),
        )
        attempts: list[dict[str, Any]] = []
        for _, executor in ordered:
            try:
                response = executor.execute(request)
            except Exception as exc:
                attempts.append(
                    {
                        "transport": executor.name,
                        "kind": executor.kind.value,
                        "outcome": "error",
                        "error_type": type(exc).__name__,
                        "error_message": str(exc),
                    }
                )
                continue
            if response is None:
                if executor.kind == TransportKind.REMOTE:
                    attempts.append(
                        {
                            "transport": executor.name,
                            "kind": executor.kind.value,
                            "outcome": "deferred",
                        }
                    )
                    return TransportDispatch(
                        request=request,
                        deferred_transport=executor.name,
                        attempts=attempts,
                    )
                attempts.append(
                    {
                        "transport": executor.name,
                        "kind": executor.kind.value,
                        "outcome": "not_materialized",
                    }
                )
                continue
            if response.transport_name != executor.name or response.transport_kind != executor.kind:
                attempts.append(
                    {
                        "transport": executor.name,
                        "kind": executor.kind.value,
                        "outcome": "protocol_error",
                        "message": "executor identity does not match response identity",
                    }
                )
                continue
            if response.transport_state == TransportResponseState.ERROR:
                attempts.append(
                    {
                        "transport": executor.name,
                        "kind": executor.kind.value,
                        "outcome": "error_response",
                        "error_type": response.error_type,
                        "error_message": response.error_message,
                    }
                )
                continue
            attempts.append(
                {
                    "transport": executor.name,
                    "kind": executor.kind.value,
                    "outcome": "response",
                    "status_code": response.status_code,
                    "byte_count": response.byte_count,
                    "transport_checksum": response.transport_checksum,
                }
            )
            return TransportDispatch(request=request, response=response, attempts=attempts)
        return TransportDispatch(request=request, attempts=attempts)


class ChatGptNativeMaterializedTransport:
    """Adapts exact bytes materialized by a ChatGPT host tool to the shared contract.

    This executor performs no network discovery or scholarly reasoning. The host has
    already materialized an authorized request to a local file; this adapter only
    records the low-level transport facts and exact byte checksum.
    """

    name = "chatgpt_native_materialized"
    kind = TransportKind.NATIVE

    def __init__(
        self,
        materialized: Mapping[str, Path],
        *,
        status_code: int = 200,
        headers: Mapping[str, str] | None = None,
        final_urls: Mapping[str, str] | None = None,
    ):
        self._materialized = {str(k): Path(v) for k, v in materialized.items()}
        self._status_code = int(status_code)
        self._headers = {str(k): str(v) for k, v in (headers or {}).items()}
        self._final_urls = {str(k): str(v) for k, v in (final_urls or {}).items()}

    def execute(self, request: TransportRequest) -> TransportResponse | None:
        path = self._materialized.get(request.request_id) or self._materialized.get(request.url)
        if path is None:
            return None
        started = datetime.now(timezone.utc)
        body = path.read_bytes()
        finished = datetime.now(timezone.utc)
        return TransportResponse(
            request_id=request.request_id,
            correlation_id=request.correlation_id,
            transport_name=self.name,
            transport_kind=self.kind,
            transport_state=TransportResponseState.RESPONSE,
            requested_url=request.url,
            final_url=self._final_urls.get(request.request_id, self._final_urls.get(request.url, request.url)),
            status_code=self._status_code,
            headers=dict(self._headers),
            materialized_path=path,
            byte_count=len(body),
            transport_checksum=hashlib.sha256(body).hexdigest(),
            started_at=started,
            finished_at=finished,
            elapsed_ms=max(0, round((finished - started).total_seconds() * 1000)),
        )


class DeferredRemoteTransport:
    """Transport-only remote slot. The host executes the serialized request externally."""

    def __init__(self, name: str = "github_actions_remote"):
        self.name = name
        self.kind = TransportKind.REMOTE

    def execute(self, request: TransportRequest) -> None:
        return None


class ResponseFileTransport:
    """Replay a real transport response produced by an external worker."""

    def __init__(self, path: Path, *, name: str = "github_actions_remote"):
        self.path = Path(path)
        self.name = name
        self.kind = TransportKind.REMOTE

    def execute(self, request: TransportRequest) -> TransportResponse:
        response = TransportResponse.model_validate_json(self.path.read_text(encoding="utf-8"))
        return response
