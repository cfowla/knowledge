from __future__ import annotations

from enum import Enum

from pydantic import BaseModel


class AcquisitionRoute(str, Enum):
    PMC = "pmc"
    PUBLISHER_OA = "publisher_oa"
    UNPAYWALL = "unpaywall"
    REPOSITORY = "repository"


ROUTE_ORDER = [
    AcquisitionRoute.PMC,
    AcquisitionRoute.PUBLISHER_OA,
    AcquisitionRoute.UNPAYWALL,
    AcquisitionRoute.REPOSITORY,
]


class CapabilityStatus(str, Enum):
    SUPPORTED = "supported"
    EXPERIMENTAL = "experimental"
    DISABLED = "disabled"


class RouteCapabilityRegistry(BaseModel):
    """Explicit acquisition capability state for each route."""

    pmc: CapabilityStatus = CapabilityStatus.EXPERIMENTAL
    publisher_oa: CapabilityStatus = CapabilityStatus.EXPERIMENTAL
    unpaywall: CapabilityStatus = CapabilityStatus.EXPERIMENTAL
    repository: CapabilityStatus = CapabilityStatus.EXPERIMENTAL

    def status(self, route: AcquisitionRoute) -> CapabilityStatus:
        return CapabilityStatus(getattr(self, route.value))

    def enabled_routes(self) -> list[AcquisitionRoute]:
        return [route for route in ROUTE_ORDER if self.status(route) != CapabilityStatus.DISABLED]

    def enabled(self) -> list[str]:
        return [route.value for route in self.enabled_routes()]
