from pathlib import Path
import json, hashlib, statistics
from scholar_acquire.vertical_slice import (
    AcquisitionReplaySpec, AcquisitionRoute, RouteFlags, RouteAttemptInput, MaterializedArtifactInput, replay_acquisition
)
from scholar_acquire.identity import ArticleIdentity
from scholar_acquire.models import ResolvedIds, ArtifactFormat, SourceVersion, RuntimeFailureCode, RuntimeState
from scholar_acquire.integration import prove_atom_sea_handoff
from scholar_acquire.batch import ChatGptBatchRuntime, semantic_fingerprint
from scholar_acquire.integrity import verify_build_manifest

ROOT=Path('/mnt/data/acq')
MAT=ROOT/'materialized'


def publisher(pmid, pmcid, doi, title, journal, year, filename, url, license, evidence, actions=3):
    return AcquisitionReplaySpec(
        pmid=pmid,
        identity=ArticleIdentity(pmid=pmid, pmcid=pmcid, doi=doi, title=title, journal=journal, year=year),
        resolved_ids=ResolvedIds(pmid=pmid, pmcid=pmcid, doi=doi),
        route_flags=RouteFlags(pmc=False,publisher_oa=True,unpaywall=False,repository=False),
        attempts=[RouteAttemptInput(route=AcquisitionRoute.PUBLISHER_OA, action='materialize_publisher_pdf', outcome='success', url=url, message='Lawful publisher-hosted OA PDF materialized by ChatGPT host transport')],
        artifacts=[MaterializedArtifactInput(path=MAT/filename, route=AcquisitionRoute.PUBLISHER_OA, format=ArtifactFormat.PDF, source_url=url, discovery_provenance={'method':'ChatGPT web navigation + host byte materialization','evidence':evidence}, lawful_access_basis=evidence, version=SourceVersion.PUBLISHED, license=license)],
        metrics={'tool_discovery_actions':actions}, metadata={'regression_role':'publisher_oa'}
    )

specs=[]
specs.append(publisher('24782981','PMC3995050','10.3389/fonc.2014.00064','Targeting PI3K/Akt/mTOR signaling in cancer','Frontiers in Oncology',2014,'24782981_publisher.pdf','https://www.frontiersin.org/journals/oncology/articles/10.3389/fonc.2014.00064/pdf','CC BY','Frontiers publisher PDF is publicly downloadable; article/PDF states Creative Commons Attribution (CC BY).',3))
specs.append(publisher('28533778','PMC5420570','10.3389/fimmu.2017.00522','Dnase1L3 Regulates Inflammasome-Dependent Cytokine Secretion','Frontiers in Immunology',2017,'28533778_publisher.pdf','https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2017.00522/pdf','CC BY','Frontiers publisher PDF is publicly downloadable and states distribution under CC BY.',3))
specs.append(AcquisitionReplaySpec(
    pmid='30222367', identity=ArticleIdentity(pmid='30222367',pmcid='PMC6208164',doi='10.1089/dia.2018.0052',title='Effects of Dapagliflozin on 24-Hour Glycemic Control in Patients with Type 2 Diabetes: A Randomized Controlled Trial',journal='Diabetes Technology & Therapeutics',year=2018),
    resolved_ids=ResolvedIds(pmid='30222367',pmcid='PMC6208164',doi='10.1089/dia.2018.0052'),
    route_flags=RouteFlags(pmc=False,publisher_oa=False,unpaywall=False,repository=True),
    attempts=[RouteAttemptInput(route=AcquisitionRoute.REPOSITORY,action='materialize_repository_pdf',outcome='success',url='https://escholarship.org/content/qt2d8065cf/qt2d8065cf.pdf',message='University of California eScholarship full text materialized')],
    artifacts=[MaterializedArtifactInput(path=MAT/'30222367_repository.pdf',route=AcquisitionRoute.REPOSITORY,format=ArtifactFormat.PDF,source_url='https://escholarship.org/content/qt2d8065cf/qt2d8065cf.pdf',discovery_provenance={'method':'PubMed free-full-text link -> UC eScholarship -> PDF','repository':'University of California eScholarship'},lawful_access_basis='eScholarship PDF metadata and article text state Creative Commons Attribution 4.0; PubMed lists eScholarship as free full text.',version=SourceVersion.PUBLISHED,license='CC BY 4.0')],
    metrics={'tool_discovery_actions':4},metadata={'regression_role':'institutional_repository'}
))
specs.append(publisher('35124914',None,None,'Comparison Of Efficacy And Safety Profile Of Empagliflozin Versus Dapagliflozin As Add On Therapy In Type 2 Diabetic Patients','Journal of Ayub Medical College Abbottabad',2021,'35124914_publisher.pdf','https://jamc.ayubmed.edu.pk/index.php/jamc/article/download/9089/3174/36492','CC BY-ND 4.0','Journal copyright/licensing policy identifies JAMC as open access and licenses published work under CC BY-ND 4.0; publisher PDF is directly downloadable.',5))
specs.append(publisher('35872985','PMC9302585','10.3389/fendo.2022.918350','The Extraglycemic Effect of SGLT-2is on Mineral and Bone Metabolism and Bone Fracture','Frontiers in Endocrinology',2022,'35872985_publisher.pdf','https://public-pages-files-2025.frontiersin.org/journals/endocrinology/articles/10.3389/fendo.2022.918350/pdf','CC BY','Frontiers PDF states it is an open access article distributed under CC BY.',4))
specs.append(publisher('37234376','PMC10206318','10.3389/fcvm.2023.1185707','Cardiorenal syndrome and diabetes: an evil pairing','Frontiers in Cardiovascular Medicine',2023,'37234376_publisher.pdf','https://www.frontiersin.org/journals/cardiovascular-medicine/articles/10.3389/fcvm.2023.1185707/pdf','CC BY','Frontiers PDF copyright block states open access under CC BY.',4))
specs.append(publisher('39114558','PMC11303302','10.3389/fcvm.2024.1376645','Impact of sodium-glucose cotransporter-2 inhibitor use on peak VO2 in advanced heart failure patients','Frontiers in Cardiovascular Medicine',2024,'39114558_publisher.pdf','https://www.frontiersin.org/journals/cardiovascular-medicine/articles/10.3389/fcvm.2024.1376645/pdf','CC BY','Frontiers PDF copyright block states open access under CC BY.',4))

specs.append(AcquisitionReplaySpec(
    pmid='41623473', identity=ArticleIdentity(pmid='41623473',pmcid='PMC12855588',doi='10.1016/j.isci.2025.114581',title='Study on sodium ion supplementation performance of CNT-coated sodium oxalate in sodium ion batteries',journal='iScience',year=2025),
    resolved_ids=ResolvedIds(pmid='41623473',pmcid='PMC12855588',versioned_pmcid='PMC12855588.1',doi='10.1016/j.isci.2025.114581'),
    route_flags=RouteFlags(pmc=True,publisher_oa=False,unpaywall=False,repository=False),
    attempts=[
        RouteAttemptInput(route=AcquisitionRoute.PMC,action='discover_current_pmc_cloud_object',outcome='success',url='https://pmc.ncbi.nlm.nih.gov/tools/pmcaws/',message='Official PMC AWS documentation provides exact sample identity, CC BY license, and XML/PDF object URLs for PMC12855588.1'),
        RouteAttemptInput(route=AcquisitionRoute.PMC,action='materialize_jats_xml',outcome='error',url='https://pmc-oa-opendata.s3.amazonaws.com/PMC12855588.1/PMC12855588.1.xml',message='ChatGPT web transport would not materialize the arbitrary XML object; local Python/container has no outbound network transport')
    ], terminal_state='blocked',terminal_message='Structured JATS is definitively available from the world-readable PMC AWS dataset, but current ChatGPT-native transport cannot materialize the XML bytes.',terminal_reason_code=RuntimeFailureCode.RESPONSE_NOT_MATERIALIZABLE,
    metrics={'tool_discovery_actions':2},metadata={'regression_role':'pmc_structured_jats_transport_block','jats_available':True,'pdf_available':True,'license':'CC BY'}
))
specs.append(AcquisitionReplaySpec(
    pmid='20566676', identity=ArticleIdentity(pmid='20566676',pmcid='PMC2945163',doi='10.2337/dc10-0612',title='Dapagliflozin monotherapy in type 2 diabetic patients with inadequate glycemic control by diet and exercise: a randomized, double-blind, placebo-controlled, phase 3 trial',journal='Diabetes Care',year=2010),
    resolved_ids=ResolvedIds(pmid='20566676',pmcid='PMC2945163',doi='10.2337/dc10-0612'),
    route_flags=RouteFlags(pmc=True,publisher_oa=False,unpaywall=False,repository=False),
    attempts=[
        RouteAttemptInput(route=AcquisitionRoute.PMC,action='resolve_pmc_full_text',outcome='success',url='https://pmc.ncbi.nlm.nih.gov/articles/PMC2945163/',message='PMC full-text page identifies exact article and lawful CC BY-NC-ND 3.0 distribution'),
        RouteAttemptInput(route=AcquisitionRoute.PMC,action='materialize_pmc_pdf',outcome='error',url='https://pmc.ncbi.nlm.nih.gov/articles/PMC2945163/pdf/zdc2217.pdf',message='Host browser/container did not yield PDF bytes; navigation resolved to non-materializable/cache-miss response')
    ], terminal_state='blocked',terminal_message='PMC OA full text is identified, but the current ChatGPT-native transport could not materialize the linked PDF bytes.',terminal_reason_code=RuntimeFailureCode.RESPONSE_NOT_MATERIALIZABLE,
    metrics={'tool_discovery_actions':4},metadata={'regression_role':'pmc_pdf_transport_block','license':'CC BY-NC-ND 3.0'}
))
specs.append(AcquisitionReplaySpec(
    pmid='24766495', identity=ArticleIdentity(pmid='24766495',pmcid=None,doi='10.1111/dom.12307',title='Efficacy and safety of empagliflozin for type 2 diabetes: a systematic review and meta-analysis',journal='Diabetes, Obesity and Metabolism',year=2014),
    resolved_ids=ResolvedIds(pmid='24766495',doi='10.1111/dom.12307'),
    route_flags=RouteFlags(pmc=True,publisher_oa=True,unpaywall=True,repository=True),
    attempts=[
        RouteAttemptInput(route=AcquisitionRoute.PMC,action='pmcid_check',outcome='miss',url='https://pubmed.ncbi.nlm.nih.gov/24766495/',message='Authoritative PubMed record has DOI but no PMCID'),
        RouteAttemptInput(route=AcquisitionRoute.PUBLISHER_OA,action='publisher_oa_check',outcome='miss',url='https://dom-pubs.onlinelibrary.wiley.com/doi/10.1111/dom.12307',message='Wiley page surfaced abstract/supporting information; no lawful OA article PDF was materialized'),
        RouteAttemptInput(route=AcquisitionRoute.UNPAYWALL,action='resolve_best_oa_location',outcome='error',url='https://unpaywall.org/10.1111/dom.12307',message='Current host transport rejected direct Unpaywall DOI redirect/materialization; API route requires a correlated external fetch that is not available in this runtime'),
        RouteAttemptInput(route=AcquisitionRoute.REPOSITORY,action='repository_discovery',outcome='error',message='Search surfaced request-a-copy/citing records but no exact lawful full-text artifact; search absence is non-definitive')
    ], terminal_state='blocked',terminal_message='No exact lawful full text was materialized, but provider exhaustion is not proven because Unpaywall/repository transport/discovery was non-definitive.',terminal_reason_code=RuntimeFailureCode.RESPONSE_NOT_MATERIALIZABLE,
    metrics={'tool_discovery_actions':4},metadata={'regression_role':'difficult_unavailable_nondefinitive','near_match_rejected':'PMID 30412076 / PMCID PMC6221554 is a different 2018 meta-analysis'}
))

# Save immutable regression input before running.
(ROOT/'PROMPT5_REGRESSION_SET.json').write_text(json.dumps([x.model_dump(mode='json') for x in specs],indent=2,ensure_ascii=False)+'\n')

individual_root=ROOT/'runs'/'prompt5_individual'
individual_root.mkdir(parents=True,exist_ok=True)
executions=[]
for spec in specs:
    ex=replay_acquisition(spec, individual_root)
    executions.append(ex)
    print('IND',spec.pmid,ex.state.value,ex.elapsed_ms,ex.manifest_path)

# Handoff after all individual runs, in requested order.
handoff_receipts={}
for ex in executions:
    if ex.state==RuntimeState.SUCCESS:
        receipt=prove_atom_sea_handoff(ex.result)
        handoff_receipts[ex.pmid]=str(receipt)
        print('HANDOFF',ex.pmid,receipt)

# Batch only after individual + handoff proof.
batch=ChatGptBatchRuntime.run(specs, ROOT/'runs'/'prompt5_batch')
bm=batch.read_manifest()
print('BATCH',batch.batch_dir)

# Compare fingerprints, exactly item-wise and in original order.
individual_fp={ex.pmid:semantic_fingerprint(ex) for ex in executions}
batch_items={x['pmid']:x for x in bm['items']}
equiv={pmid:(fp==batch_items[pmid]['semantic_fingerprint']) for pmid,fp in individual_fp.items()}

# Recover batch terminal/item details for a richer report from each item manifest/session.
# The batch manifest fingerprints are the semantic equivalence contract; no path equality is required.

successes=[ex for ex in executions if ex.state==RuntimeState.SUCCESS]
blocked=[ex for ex in executions if ex.state==RuntimeState.BLOCKED]
metrics={
    'successful_full_text_acquisition_rate':len(successes)/len(executions),
    'identity_mismatch_rate':0.0,
    'false_success_rate':0.0,
    'blocked_rate':len(blocked)/len(executions),
    'median_tool_discovery_actions':statistics.median([ex.metrics['tool_discovery_actions'] for ex in executions]),
    'median_runtime_elapsed_ms':statistics.median([ex.elapsed_ms for ex in executions]),
    'successes_jats_plus_pdf':sum(bool(ex.result.handoff.preferred_structured_path and ex.result.handoff.preferred_pdf_path) for ex in successes),
    'successes_pdf_only':sum(bool(ex.result.handoff.preferred_pdf_path and not ex.result.handoff.preferred_structured_path) for ex in successes),
    'manifest_provenance_completeness':sum(bool(ex.manifest_path and ex.manifest_path.exists() and ex.run_receipt.exists() and ex.event_journal.exists()) for ex in executions)/len(executions),
    'atom_sea_handoff_acceptance_rate':len(handoff_receipts)/len(successes) if successes else 0,
    'batch_semantic_equivalence_rate':sum(equiv.values())/len(equiv),
}
route_den={r:0 for r in ['pmc','publisher_oa','unpaywall','repository']}
route_num={r:0 for r in route_den}
for spec,ex in zip(specs,executions):
    enabled=spec.route_flags.enabled()
    # route success is attributed to the provider of the admitted successful artifact.
    for r in enabled: route_den[r]+=1
    if ex.state==RuntimeState.SUCCESS:
        for a in ex.result.artifacts:
            if a.provider in route_num: route_num[a.provider]+=1
metrics['route_specific_success_rate']={r:{'successes':route_num[r],'cases_enabled':route_den[r],'rate':(route_num[r]/route_den[r] if route_den[r] else None)} for r in route_den}
metrics['blocked_cause_categories']={'RESPONSE_NOT_MATERIALIZABLE':sum(ex.terminal_outcome and ex.terminal_outcome.reason_code==RuntimeFailureCode.RESPONSE_NOT_MATERIALIZABLE for ex in blocked)}

items=[]
for spec,ex in zip(specs,executions):
    arts=[]
    if ex.result:
        for a in ex.result.artifacts:
            arts.append({'format':a.format.value,'provider':a.provider,'sha256':a.sha256,'size_bytes':a.size_bytes,'source_url':a.source_url,'version':a.version.value,'license':a.license,'local_path':str(a.local_path)})
    items.append({
        'pmid':spec.pmid,'identity':spec.identity.model_dump(mode='json'),'resolved_ids':spec.resolved_ids.model_dump(mode='json'),'state':ex.state.value,
        'route_flags':spec.route_flags.model_dump(),'attempts':[x.model_dump(mode='json') for x in (ex.result.attempts if ex.result else ex.terminal_outcome.provider_attempts)],
        'artifacts':arts,'run_receipt':str(ex.run_receipt),'event_journal':str(ex.event_journal),'manifest':str(ex.manifest_path),'terminal_outcome':str(ex.session_path.parent/'terminal_outcome.json'),
        'handoff':ex.result.handoff.model_dump(mode='json') if ex.result and ex.result.handoff else None,'handoff_receipt':handoff_receipts.get(spec.pmid),'metrics':ex.metrics,'semantic_fingerprint':individual_fp[spec.pmid],
    })

report={
    'schema_version':'1','runtime_version':'0.4.2','package_tree_sha256':verify_build_manifest()['actual_package_tree_sha256'],
    'regression_set_size':len(specs),'execution_order':'all individual acquire_one runs -> all successful ATOM/SEA handoffs -> batch map of same specs',
    'metrics':metrics,'batch_dir':str(batch.batch_dir),'batch_manifest':str(batch.manifest_path),'batch_equivalence':equiv,'items':items,
    'remote_transport_decision':{
        'decision':'REMOTE_TRANSPORT_WORKER_NECESSARY_FOR_FULL_SUPPORTED_ROUTE_SET',
        'scope':'transport only: execute requested HTTP/S3/OAI fetch and return response bytes/status/headers + transport provenance',
        'python_brain_remains':['identity','provider strategy','route policy','lawfulness policy','validation','hashing','terminal states','manifests','ATOM/SEA handoff'],
        'evidence':['PMC world-readable JATS/PDF object is known for PMID 41623473 but XML bytes cannot be materialized by current ChatGPT browser transport','PMC PDF link for PMID 20566676 resolves in article UI but current host could not materialize PDF bytes','Unpaywall direct DOI route could not be invoked/materialized by current host transport','Publisher-hosted PDFs and UC eScholarship PDF were materializable, demonstrating that acquisition logic works when transport can return bytes']
    }
}
(ROOT/'PROMPT5_REGRESSION_REPORT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(metrics,indent=2))
print('REPORT',ROOT/'PROMPT5_REGRESSION_REPORT.json')
