from __future__ import annotations

import json
from pathlib import Path

from scholar_acquire import (
    AcquisitionConfig,
    ArtifactObservation,
    CapabilityStatus,
    HostRequestKind,
    IdentityObservation,
    RouteCapabilityRegistry,
    RouteObservation,
    RouteObservationKind,
    acquire_one,
)
from scholar_acquire.models import ArtifactFormat, SourceVersion
from scholar_acquire import AcquisitionRoute

SOURCE_EVIDENCE = Path("/mnt/data/prompt5evidence/individual/24782981")
SOURCE_MANIFEST = SOURCE_EVIDENCE / "manifest.json"
SOURCE_PDF = SOURCE_EVIDENCE / "article.pdf"
OUT_ROOT = Path("/mnt/data/v043_prompt1_real_check")


class HistoricalEvidenceHost:
    def __init__(self):
        self.manifest = json.loads(SOURCE_MANIFEST.read_text(encoding="utf-8"))
        self.identity = self.manifest["metadata"]["v0_4"]["article_identity"]
        self.artifact = self.manifest["artifacts"][0]
        self.binding = self.artifact["metadata"]["v0_4"]

    def observe(self, request):
        if request.kind == HostRequestKind.RESOLVE_IDENTITY:
            return IdentityObservation(
                request_id=request.request_id,
                pmid=self.identity["pmid"],
                pmcid=self.identity.get("pmcid"),
                doi=self.identity.get("doi"),
                title=self.identity["title"],
                journal=self.identity.get("journal"),
                year=self.identity.get("year"),
                evidence_source=str(SOURCE_MANIFEST),
                evidence_method="v0.4.2 preserved acquisition manifest supplied through host observation contract",
                evidence_sha256=self.artifact["sha256"],
                metadata={"historical_contract_version": "0.4.2"},
            )
        if request.route != AcquisitionRoute.PUBLISHER_OA:
            raise AssertionError(f"Unexpected route request: {request.route}")
        return RouteObservation(
            request_id=request.request_id,
            route=request.route,
            kind=RouteObservationKind.MATERIALIZED_ARTIFACT,
            action="admit_previously_acquired_lawful_oa_pdf",
            evidence_source=str(SOURCE_MANIFEST),
            message="Host supplied preserved bytes and provenance; Python decides admission and terminal state",
            artifacts=[
                ArtifactObservation(
                    path=SOURCE_PDF,
                    format=ArtifactFormat.PDF,
                    source_url=self.artifact["source_url"],
                    discovery_provenance={
                        **self.binding["discovery_provenance"],
                        "preserved_manifest": str(SOURCE_MANIFEST),
                        "historical_artifact_sha256": self.artifact["sha256"],
                    },
                    lawful_access_basis=self.binding["lawful_access_basis"],
                    open_access=True,
                    version=SourceVersion.PUBLISHED,
                    license=self.artifact.get("license"),
                    metadata={"historical_v0_4_2_artifact": True},
                )
            ],
        )


def main():
    config = AcquisitionConfig(
        route_capabilities=RouteCapabilityRegistry(
            pmc=CapabilityStatus.DISABLED,
            publisher_oa=CapabilityStatus.EXPERIMENTAL,
            unpaywall=CapabilityStatus.DISABLED,
            repository=CapabilityStatus.DISABLED,
        )
    )
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    execution = acquire_one(
        identifier="24782981",
        config=config,
        root=OUT_ROOT,
        host=HistoricalEvidenceHost(),
    )
    result = execution.result
    report = {
        "prompt": 1,
        "runtime_version": "0.4.3",
        "requested_pmid": execution.pmid,
        "state": execution.state.value,
        "caller_supplied_terminal_state": False,
        "route_capability": "experimental",
        "source_evidence_manifest": str(SOURCE_MANIFEST),
        "source_pdf": str(SOURCE_PDF),
        "source_pdf_historical_sha256": json.loads(SOURCE_MANIFEST.read_text())["artifacts"][0]["sha256"],
        "resolved_ids": result.resolved_ids.model_dump(mode="json") if result else None,
        "artifacts": [a.model_dump(mode="json") for a in result.artifacts] if result else [],
        "run_receipt": str(execution.run_receipt),
        "event_journal": str(execution.event_journal),
        "manifest": str(execution.manifest_path),
        "terminal_outcome": execution.terminal_outcome.model_dump(mode="json") if execution.terminal_outcome else None,
        "elapsed_ms": execution.elapsed_ms,
    }
    report_path = execution.session_path.parent / "PROMPT1_REAL_CHECK.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(report_path)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
