# scholar-acquire-chatgpt v0.4.3 Prompt 1 repair

This build repairs the acquisition product boundary and terminal-state contract from the preserved v0.4.2 source.

Production `acquire_one()` now starts from a PMID plus `AcquisitionConfig`, a host adapter, and an optional transport registry. Prepared evidence moved to `AcquisitionReplaySpec` and `replay_acquisition()`.

Prompt 1 does not add provider breadth. Every route begins as `experimental` unless configuration disables it. No route is promoted to `supported` by this build.

Run the Prompt 1 contract tests with:

```bash
PYTHONPATH=src pytest -q tests/test_prompt1_contract.py
```

The real-check driver is `run_prompt1_real_check.py`. It expects the preserved v0.4.2 Prompt 5 evidence for PMID 24782981 under `/mnt/data/prompt5evidence/individual/24782981/` and passes that evidence through the new host observation contract.

See `docs/V0.4.3_PROMPT1_REPAIR_REPORT.md` and `docs/V0.4.3_PROMPT1_API_MIGRATION.md` for the gate results and migration details.

The old Prompt 5 report and scripts remain in this development copy for historical evidence. They are not the v0.4.3 production acceptance test.
