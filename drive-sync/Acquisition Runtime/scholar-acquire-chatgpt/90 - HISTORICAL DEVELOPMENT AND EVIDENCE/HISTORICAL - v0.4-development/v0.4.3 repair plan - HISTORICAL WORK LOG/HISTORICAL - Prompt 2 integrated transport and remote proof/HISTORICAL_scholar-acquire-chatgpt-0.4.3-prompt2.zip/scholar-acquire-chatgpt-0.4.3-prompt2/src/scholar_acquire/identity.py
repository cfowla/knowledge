from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any
import xml.etree.ElementTree as ET

from pydantic import BaseModel, Field
from pypdf import PdfReader

from .models import ArtifactFormat

DOI_RE = re.compile(r"10\.\d{4,9}/[-._;()/:A-Z0-9]+", re.I)
PMCID_RE = re.compile(r"\bPMC\d+\b", re.I)
PMID_RE = re.compile(r"\bPMID\s*[:#]?\s*(\d{6,9})\b", re.I)


def _norm(s: str | None) -> str | None:
    if not s:
        return None
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = re.sub(r"[^a-z0-9]+", " ", s.lower()).strip()
    return re.sub(r"\s+", " ", s)


def _norm_doi(s: str | None) -> str | None:
    if not s:
        return None
    s = s.strip().lower()
    s = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", s)
    return s.rstrip(".,;)")


class ArticleIdentity(BaseModel):
    pmid: str
    pmcid: str | None = None
    doi: str | None = None
    title: str
    journal: str | None = None
    year: int | None = None


class IdentityDecision(BaseModel):
    decision: str
    matched_fields: list[str] = Field(default_factory=list)
    conflicts: list[str] = Field(default_factory=list)
    evidence: dict[str, Any] = Field(default_factory=dict)
    title_similarity: float | None = None

    @property
    def accepted(self) -> bool:
        return self.decision == "match"


def _pdf_evidence(path: Path) -> dict[str, Any]:
    reader = PdfReader(str(path))
    text = "\n".join((p.extract_text() or "") for p in reader.pages[:2])
    md = reader.metadata or {}
    title = str(md.get("/Title") or "").strip() or None
    dois = sorted({_norm_doi(x) for x in DOI_RE.findall(text) if _norm_doi(x)})
    pmcids = sorted({x.upper() for x in PMCID_RE.findall(text)})
    pmids = sorted(set(PMID_RE.findall(text)))
    return {"page_count": len(reader.pages), "text": text, "metadata_title": title, "dois": dois, "pmcids": pmcids, "pmids": pmids}


def _jats_evidence(path: Path) -> dict[str, Any]:
    root = ET.fromstring(path.read_bytes())
    article = root if root.tag.rsplit("}", 1)[-1] == "article" else next((e for e in root.iter() if e.tag.rsplit("}", 1)[-1] == "article"), None)
    if article is None:
        raise ValueError("JATS article element not found")
    ids: dict[str, str] = {}
    title = None
    for elem in article.iter():
        local = elem.tag.rsplit("}", 1)[-1]
        if local == "article-id":
            kind = (elem.attrib.get("pub-id-type") or "").lower()
            val = "".join(elem.itertext()).strip()
            if kind and val:
                ids[kind] = val
        elif local == "article-title" and title is None:
            title = " ".join("".join(elem.itertext()).split())
    return {"ids": ids, "title": title}


def verify_identity(path: Path, fmt: ArtifactFormat, expected: ArticleIdentity) -> IdentityDecision:
    exp_doi = _norm_doi(expected.doi)
    exp_pmcid = expected.pmcid.upper() if expected.pmcid else None
    exp_title = _norm(expected.title) or ""
    matched: list[str] = []
    conflicts: list[str] = []

    if fmt == ArtifactFormat.PDF:
        ev = _pdf_evidence(path)
        if exp_doi and ev["dois"]:
            if exp_doi in ev["dois"]:
                matched.append("doi")
            else:
                conflicts.append(f"doi expected={exp_doi} observed={','.join(ev['dois'])}")
        if exp_pmcid and ev["pmcids"]:
            if exp_pmcid in ev["pmcids"]:
                matched.append("pmcid")
            else:
                conflicts.append(f"pmcid expected={exp_pmcid} observed={','.join(ev['pmcids'])}")
        if ev["pmids"]:
            if expected.pmid in ev["pmids"]:
                matched.append("pmid")
            else:
                conflicts.append(f"pmid expected={expected.pmid} observed={','.join(ev['pmids'])}")
        samples = [x for x in (_norm(ev["metadata_title"]), _norm(ev["text"][:4000])) if x]
        title_sim = 0.0
        for sample in samples:
            if exp_title and exp_title in sample:
                title_sim = 1.0
                break
            window = sample[:max(len(exp_title) * 3, 120)]
            title_sim = max(title_sim, SequenceMatcher(None, exp_title, window).ratio())
            if exp_title:
                exp_tokens = set(exp_title.split())
                obs_tokens = set(window.split())
                if exp_tokens:
                    title_sim = max(title_sim, len(exp_tokens & obs_tokens) / len(exp_tokens))
        if title_sim >= 0.84:
            matched.append("title")
        elif not any(k in matched for k in ("doi", "pmcid", "pmid")):
            conflicts.append(f"title similarity={title_sim:.3f}")
        evidence = {k: v for k, v in ev.items() if k != "text"}
        evidence["text_prefix"] = ev["text"][:1200]
    elif fmt == ArtifactFormat.JATS_XML:
        ev = _jats_evidence(path)
        ids = ev["ids"]
        observed_doi = _norm_doi(ids.get("doi"))
        observed_pmid = ids.get("pmid")
        observed_pmcid = (ids.get("pmc") or ids.get("pmcid") or "").upper() or None
        for key, expected_val, observed_val in (("doi", exp_doi, observed_doi), ("pmid", expected.pmid, observed_pmid), ("pmcid", exp_pmcid, observed_pmcid)):
            if expected_val and observed_val:
                if expected_val == observed_val:
                    matched.append(key)
                else:
                    conflicts.append(f"{key} expected={expected_val} observed={observed_val}")
        observed_title = _norm(ev.get("title")) or ""
        title_sim = SequenceMatcher(None, exp_title, observed_title).ratio() if observed_title else 0.0
        if title_sim >= 0.92:
            matched.append("title")
        evidence = ev
    else:
        raise ValueError(f"Unsupported identity format: {fmt}")

    if conflicts:
        decision = "mismatch"
    elif any(k in matched for k in ("doi", "pmid", "pmcid")) or ("title" in matched and not expected.doi):
        decision = "match"
    else:
        decision = "unverified"
    return IdentityDecision(decision=decision, matched_fields=matched, conflicts=conflicts, evidence=evidence, title_similarity=title_sim)
