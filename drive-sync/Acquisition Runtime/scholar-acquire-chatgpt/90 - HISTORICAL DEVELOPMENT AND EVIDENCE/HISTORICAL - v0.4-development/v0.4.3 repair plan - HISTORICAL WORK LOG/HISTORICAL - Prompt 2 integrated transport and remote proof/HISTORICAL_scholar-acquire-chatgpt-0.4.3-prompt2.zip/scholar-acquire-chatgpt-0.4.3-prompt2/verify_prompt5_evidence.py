#!/usr/bin/env python3
"""Verify the portable Prompt-5 evidence ZIP against its embedded regression report."""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("evidence_zip", type=Path)
    args = parser.parse_args()

    with zipfile.ZipFile(args.evidence_zip) as zf:
        names = set(zf.namelist())
        report = json.loads(zf.read("PROMPT5_REGRESSION_REPORT.json"))
        assert report["regression_set_size"] == 10
        assert len(report["items"]) == 10
        assert report["metrics"]["identity_mismatch_rate"] == 0.0
        assert report["metrics"]["false_success_rate"] == 0.0
        assert report["metrics"]["batch_semantic_equivalence_rate"] == 1.0
        assert all(report["batch_equivalence"].values())
        assert "batch/batch_manifest.json" in names
        assert "batch/BATCH_RUN_RECEIPT.json" in names
        assert "batch/batch_events.jsonl" in names

        successes = 0
        for item in report["items"]:
            pmid = item["pmid"]
            prefix = f"individual/{pmid}/"
            required = {
                prefix + "RUN_RECEIPT.json",
                prefix + "runtime_events.jsonl",
                prefix + "terminal_outcome.json",
            }
            manifest_name = prefix + ("manifest.json" if item["state"] == "success" else "acquisition_manifest.json")
            required.add(manifest_name)
            missing = sorted(required - names)
            assert not missing, f"{pmid}: missing evidence {missing}"

            if item["state"] == "success":
                successes += 1
                pdf_name = prefix + "article.pdf"
                handoff_name = prefix + "ATOM_SEA_HANDOFF.json"
                assert pdf_name in names, f"{pmid}: article.pdf missing"
                assert handoff_name in names, f"{pmid}: ATOM_SEA_HANDOFF.json missing"
                pdf_bytes = zf.read(pdf_name)
                actual = hashlib.sha256(pdf_bytes).hexdigest()
                artifacts = [a for a in item["artifacts"] if a["format"] == "pdf"]
                assert artifacts, f"{pmid}: no PDF artifact in report"
                assert actual == artifacts[0]["sha256"], f"{pmid}: PDF hash mismatch"
                handoff = json.loads(zf.read(handoff_name))
                assert handoff["accepted"] is True, f"{pmid}: handoff not accepted"

        assert successes == 7

    print(json.dumps({
        "verified": True,
        "evidence_zip": str(args.evidence_zip),
        "item_count": 10,
        "success_count": 7,
        "identity_mismatch_rate": 0.0,
        "false_success_rate": 0.0,
        "batch_equivalence": "10/10",
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
