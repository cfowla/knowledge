import json
from pathlib import Path

from scholar_acquire.integrity import verify_build_manifest

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / "PROMPT5_REGRESSION_REPORT.json"


def report():
    return json.loads(REPORT.read_text(encoding="utf-8"))


def test_runtime_build_integrity():
    assert verify_build_manifest()["integrity_verified"] is True


def test_embedded_report_has_all_ten_items_and_required_fields():
    r = report()
    assert r["runtime_version"] == "0.4.2"
    assert r["regression_set_size"] == 10
    assert len(r["items"]) == 10
    for item in r["items"]:
        assert item["pmid"]
        assert item["resolved_ids"]["pmid"] == item["pmid"]
        assert item["state"] in {"success", "blocked", "exhausted", "failed"}
        assert item["attempts"]
        assert item["run_receipt"]
        assert item["event_journal"]
        assert item["manifest"]
        assert item["terminal_outcome"]


def test_reported_success_payloads_and_handoff_contracts():
    r = report()
    successes = [x for x in r["items"] if x["state"] == "success"]
    assert len(successes) == 7
    for item in successes:
        assert item["artifacts"]
        assert item["handoff"] is not None
        assert item["handoff_receipt"]
        for artifact in item["artifacts"]:
            assert len(artifact["sha256"]) == 64
            assert artifact["size_bytes"] > 0
            assert artifact["source_url"]


def test_no_false_success_and_no_identity_mismatch():
    metrics = report()["metrics"]
    assert metrics["false_success_rate"] == 0.0
    assert metrics["identity_mismatch_rate"] == 0.0


def test_batch_is_semantically_equivalent():
    r = report()
    assert len(r["batch_equivalence"]) == 10
    assert all(r["batch_equivalence"].values())
    assert r["metrics"]["batch_semantic_equivalence_rate"] == 1.0
