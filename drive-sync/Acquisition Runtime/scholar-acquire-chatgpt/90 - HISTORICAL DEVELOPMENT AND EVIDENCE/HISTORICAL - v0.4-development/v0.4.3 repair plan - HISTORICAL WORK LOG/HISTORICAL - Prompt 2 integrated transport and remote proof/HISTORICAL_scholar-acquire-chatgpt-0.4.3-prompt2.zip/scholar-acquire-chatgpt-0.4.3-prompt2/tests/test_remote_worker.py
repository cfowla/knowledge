import hashlib
import socketserver
import threading
from http.server import BaseHTTPRequestHandler
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from remote_worker.transport_worker import execute
from scholar_acquire import TransportRequest, TransportResponse, AcquisitionRoute

BODY=b'<?xml version="1.0"?><article><front/></article>'
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(206)
        self.send_header('Content-Type','application/xml')
        self.send_header('X-Test','transport-only')
        self.end_headers(); self.wfile.write(BODY)
    def log_message(self,*args): pass

def test_worker_returns_exact_shared_transport_contract():
    with socketserver.TCPServer(('127.0.0.1',0),Handler) as srv:
        t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
        port=srv.server_address[1]
        request=TransportRequest.build(url=f'http://127.0.0.1:{port}/x', source_route=AcquisitionRoute.PMC, expected_media_type='application/xml')
        out=execute(request.model_dump(mode='json'))
        srv.shutdown()
    response=TransportResponse.model_validate(out)
    body=response.validate_correlation(request)
    assert response.transport_state.value=='response'
    assert response.status_code==206
    assert response.headers['Content-Type']=='application/xml'
    assert response.transport_checksum==hashlib.sha256(BODY).hexdigest()
    assert body==BODY
