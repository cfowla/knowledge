from datetime import date
from pathlib import Path

from reportlab.pdfgen import canvas

from scholar_acquire import (
    AcquisitionConfig,
    AcquisitionRoute,
    CapabilityProofRegistry,
    CapabilityStatus,
    ChatGptNativeMaterializedTransport,
    HostRequestKind,
    IdentityObservation,
    RouteCapabilityRegistry,
    RouteObservation,
    RouteObservationKind,
    RouteProofRecord,
    TransportLocationObservation,
    TransportRegistry,
    UnpaywallLocation,
    UnpaywallLookupObservation,
    acquire_one,
)
from scholar_acquire.models import ArtifactFormat, RuntimeState, SourceVersion


PMID = "12345678"
PMCID = "PMC1234567"
DOI = "10.1234/example.1"
TITLE = "Prompt Three Dual Payload Article"
JATS_URL = "https://pmc.example.org/article.xml"
PDF_URL = "https://pmc.example.org/article.pdf"


def _pdf(path: Path, title: str = TITLE, doi: str = DOI) -> Path:
    c = canvas.Canvas(str(path))
    c.setTitle(title)
    c.drawString(72, 750, title)
    c.drawString(72, 730, f"DOI: {doi}")
    c.drawString(72, 710, f"PMID: {PMID}")
    c.save()
    return path


def _jats(path: Path) -> Path:
    path.write_text(
        f'''<?xml version="1.0" encoding="UTF-8"?>
<article><front><article-meta>
<article-id pub-id-type="pmid">{PMID}</article-id>
<article-id pub-id-type="pmc">{PMCID}</article-id>
<article-id pub-id-type="doi">{DOI}</article-id>
<title-group><article-title>{TITLE}</article-title></title-group>
</article-meta></front><body><p>Full text.</p></body></article>''',
        encoding="utf-8",
    )
    return path


def _caps(route: AcquisitionRoute) -> RouteCapabilityRegistry:
    values = {r.value: CapabilityStatus.DISABLED for r in AcquisitionRoute}
    values[route.value] = CapabilityStatus.EXPERIMENTAL
    return RouteCapabilityRegistry(**values)


class DualPmcHost:
    def observe(self, request):
        if request.kind == HostRequestKind.RESOLVE_IDENTITY:
            return IdentityObservation(
                request_id=request.request_id,
                pmid=PMID,
                pmcid=PMCID,
                doi=DOI,
                title=TITLE,
                evidence_source=f"https://pubmed.ncbi.nlm.nih.gov/{PMID}/",
                evidence_method="test",
            )
        return RouteObservation(
            request_id=request.request_id,
            route=AcquisitionRoute.PMC,
            kind=RouteObservationKind.LOCATION_DISCOVERED,
            action="pmc_dual_payload",
            evidence_source="https://pmc.ncbi.nlm.nih.gov/tools/",
            locations=[
                TransportLocationObservation(
                    url=JATS_URL,
                    format=ArtifactFormat.JATS_XML,
                    expected_media_type="application/xml",
                    discovery_provenance={"method": "PMC dataset"},
                    lawful_access_basis="PMC OA distribution",
                    open_access=True,
                    version=SourceVersion.PUBLISHED,
                    license="CC BY",
                ),
                TransportLocationObservation(
                    url=PDF_URL,
                    format=ArtifactFormat.PDF,
                    expected_media_type="application/pdf",
                    discovery_provenance={"method": "PMC dataset"},
                    lawful_access_basis="PMC OA distribution",
                    open_access=True,
                    version=SourceVersion.PUBLISHED,
                    license="CC BY",
                ),
            ],
        )


def test_pmc_dual_payload_waits_for_both_and_prefers_jats(tmp_path: Path):
    jats = _jats(tmp_path / "article.xml")
    pdf = _pdf(tmp_path / "article.pdf")
    config = AcquisitionConfig(
        want_structured=True,
        want_pdf=True,
        route_capabilities=_caps(AcquisitionRoute.PMC),
    )
    run = acquire_one(
        PMID,
        config,
        tmp_path / "run",
        DualPmcHost(),
        TransportRegistry([
            ChatGptNativeMaterializedTransport(
                {JATS_URL: jats, PDF_URL: pdf},
                headers={"content-type": "application/xml"},
            )
        ]),
    )
    # The shared native adapter has one header map, so the PDF's declared media
    # type would be wrong. Re-run with no content-type to exercise byte validation.
    if run.state != RuntimeState.SUCCESS:
        run = acquire_one(
            PMID,
            config,
            tmp_path / "run2",
            DualPmcHost(),
            TransportRegistry([ChatGptNativeMaterializedTransport({JATS_URL: jats, PDF_URL: pdf})]),
        )
    assert run.state == RuntimeState.SUCCESS
    assert run.result is not None
    formats = {a.format for a in run.result.artifacts}
    assert formats == {ArtifactFormat.JATS_XML, ArtifactFormat.PDF}
    meta = run.result.metadata["v0_4"]
    assert meta["preferred_payload"] == "article.xml"
    assert meta["secondary_payload"] == "article.pdf"
    assert (run.result.manifest_path.parent / "article.xml").is_file()
    assert (run.result.manifest_path.parent / "article.pdf").is_file()


def test_requested_dual_payload_does_not_false_success_on_pdf_only(tmp_path: Path):
    pdf = _pdf(tmp_path / "article.pdf")

    class PdfOnlyHost(DualPmcHost):
        def observe(self, request):
            obs = super().observe(request)
            if isinstance(obs, RouteObservation):
                obs.locations = [obs.locations[1]]
            return obs

    run = acquire_one(
        PMID,
        AcquisitionConfig(
            want_structured=True,
            want_pdf=True,
            route_capabilities=_caps(AcquisitionRoute.PMC),
        ),
        tmp_path / "run",
        PdfOnlyHost(),
        TransportRegistry([ChatGptNativeMaterializedTransport({PDF_URL: pdf})]),
    )
    assert run.state == RuntimeState.BLOCKED
    assert run.result is None
    assert run.terminal_outcome is not None
    assert run.terminal_outcome.provider_exhaustion_confirmed is False


def test_unpaywall_location_is_selected_by_python(tmp_path: Path):
    accepted_url = "https://repo.example.org/accepted.pdf"
    published_url = "https://publisher.example.org/published.pdf"
    submitted_url = "https://repo.example.org/submitted.pdf"
    pdf = _pdf(tmp_path / "published.pdf")

    class UnpaywallHost:
        def observe(self, request):
            if request.kind == HostRequestKind.RESOLVE_IDENTITY:
                return IdentityObservation(
                    request_id=request.request_id,
                    pmid=PMID,
                    doi=DOI,
                    title=TITLE,
                    evidence_source=f"https://pubmed.ncbi.nlm.nih.gov/{PMID}/",
                    evidence_method="test",
                )
            return UnpaywallLookupObservation(
                request_id=request.request_id,
                doi=DOI,
                title=TITLE,
                evidence_source=f"https://api.unpaywall.org/v2/{DOI}?email=redacted",
                is_oa=True,
                oa_status="gold",
                locations=[
                    UnpaywallLocation(
                        url_for_pdf=accepted_url,
                        host_type="repository",
                        version="acceptedVersion",
                        license="cc-by-nc",
                    ),
                    UnpaywallLocation(
                        url_for_pdf=submitted_url,
                        host_type="repository",
                        version="submittedVersion",
                        license="cc-by",
                        is_best=True,
                    ),
                    UnpaywallLocation(
                        url_for_pdf=published_url,
                        host_type="publisher",
                        version="publishedVersion",
                        license="cc-by",
                    ),
                ],
            )

    run = acquire_one(
        PMID,
        AcquisitionConfig(
            want_structured=False,
            want_pdf=True,
            allow_submitted=False,
            route_capabilities=_caps(AcquisitionRoute.UNPAYWALL),
        ),
        tmp_path / "run",
        UnpaywallHost(),
        TransportRegistry([ChatGptNativeMaterializedTransport({published_url: pdf})]),
    )
    assert run.state == RuntimeState.SUCCESS
    assert run.result is not None
    assert run.result.artifacts[0].source_url == published_url
    events = run.event_journal.read_text(encoding="utf-8")
    assert "unpaywall_location_selected_by_python" in events
    assert submitted_url in events


def test_unpaywall_authoritative_no_oa_can_exhaust_single_route(tmp_path: Path):
    class NoOaHost:
        def observe(self, request):
            if request.kind == HostRequestKind.RESOLVE_IDENTITY:
                return IdentityObservation(
                    request_id=request.request_id,
                    pmid=PMID,
                    doi=DOI,
                    title=TITLE,
                    evidence_source=f"https://pubmed.ncbi.nlm.nih.gov/{PMID}/",
                    evidence_method="test",
                )
            return UnpaywallLookupObservation(
                request_id=request.request_id,
                doi=DOI,
                title=TITLE,
                evidence_source=f"https://api.unpaywall.org/v2/{DOI}?email=redacted",
                is_oa=False,
                oa_status="closed",
                locations=[],
            )

    run = acquire_one(
        PMID,
        AcquisitionConfig(
            want_structured=False,
            want_pdf=True,
            route_capabilities=_caps(AcquisitionRoute.UNPAYWALL),
        ),
        tmp_path / "run",
        NoOaHost(),
    )
    assert run.state == RuntimeState.EXHAUSTED
    assert run.terminal_outcome.provider_exhaustion_confirmed is True


def test_capability_registry_requires_real_proof_fields(tmp_path: Path):
    registry = CapabilityProofRegistry()
    proof = RouteProofRecord(
        route=AcquisitionRoute.PMC,
        proof_pmid=PMID,
        resolved_ids={"pmid": PMID, "pmcid": PMCID, "doi": DOI},
        run_id="run-1",
        manifest_path="runs/run-1/manifest.json",
        artifact_sha256=["a" * 64, "b" * 64],
        runtime_version="0.4.3",
        proof_date=date(2026, 8, 21),
        negative_case_pmid="87654321",
        negative_case_state="blocked",
    )
    registry.promote(proof)
    path = registry.write(tmp_path / "CAPABILITY_REGISTRY.json")
    assert path.is_file()
    assert registry.routes["pmc"] == CapabilityStatus.SUPPORTED
    assert "publisher_oa" not in registry.proofs


def test_generic_octet_stream_is_not_rejected_before_scholarly_validation(tmp_path: Path):
    jats = _jats(tmp_path / "article.xml")
    config = AcquisitionConfig(
        want_structured=True,
        want_pdf=False,
        route_capabilities=_caps(AcquisitionRoute.PMC),
    )

    class JatsOnlyHost(DualPmcHost):
        def observe(self, request):
            obs = super().observe(request)
            if isinstance(obs, RouteObservation):
                obs.locations = [obs.locations[0]]
            return obs

    run = acquire_one(
        PMID,
        config,
        tmp_path / "run",
        JatsOnlyHost(),
        TransportRegistry([
            ChatGptNativeMaterializedTransport(
                {JATS_URL: jats}, headers={"content-type": "binary/octet-stream"}
            )
        ]),
    )
    assert run.state == RuntimeState.SUCCESS
    assert "transport_generic_media_type_deferred_to_content_validation" in run.event_journal.read_text()
