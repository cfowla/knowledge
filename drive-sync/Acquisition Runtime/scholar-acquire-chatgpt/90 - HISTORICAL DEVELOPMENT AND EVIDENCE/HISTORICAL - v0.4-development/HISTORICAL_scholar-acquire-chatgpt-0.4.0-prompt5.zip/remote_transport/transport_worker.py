#!/usr/bin/env python3
"""Dumb network transport worker for scholar-acquire v0.4.

This process deliberately contains no acquisition policy, identity resolution,
provider selection, license interpretation, content validation, hashing policy,
terminal-state logic, manifest logic, or ATOM/SEA logic.  It performs one GET
and writes the response bytes plus transport metadata for the Python acquisition
brain to ingest and judge.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

USER_AGENT = "scholar-acquire-transport/0.4 (+lawful scholarly full-text transport)"


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def fetch_once(*, url: str, request_id: str, out_dir: Path, timeout: float = 60.0) -> dict:
    parsed = urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError("transport URL must be absolute http(s)")
    if parsed.username or parsed.password:
        raise ValueError("credentials in transport URL are not allowed")

    out_dir.mkdir(parents=True, exist_ok=True)
    body_path = out_dir / "response.body"
    meta_path = out_dir / "transport_response.json"
    started = _now()
    req = Request(url, method="GET", headers={"User-Agent": USER_AGENT, "Accept": "*/*"})

    status = None
    final_url = url
    headers: dict[str, str] = {}
    body = b""
    network_error = None
    try:
        with urlopen(req, timeout=timeout) as resp:  # nosec B310: URL is the sole purpose of this isolated worker
            status = int(resp.status)
            final_url = resp.geturl()
            headers = {str(k): str(v) for k, v in resp.headers.items()}
            body = resp.read()
    except HTTPError as exc:
        status = int(exc.code)
        final_url = exc.geturl()
        headers = {str(k): str(v) for k, v in exc.headers.items()}
        body = exc.read()
    except URLError as exc:
        network_error = f"{type(exc.reason).__name__}: {exc.reason}"

    if body:
        body_path.write_bytes(body)
    elif body_path.exists():
        body_path.unlink()

    envelope = {
        "schema_version": "1",
        "worker_contract": "transport-only-v1",
        "request_id": request_id,
        "method": "GET",
        "requested_url": url,
        "final_url": final_url,
        "status": status,
        "headers": headers,
        "body_path": body_path.name if body else None,
        "body_size_bytes": len(body),
        "started_at": started,
        "completed_at": _now(),
        "network_error": network_error,
        "worker_policy": {
            "provider_selection": False,
            "identity_resolution": False,
            "license_decision": False,
            "content_validation": False,
            "acquisition_hashing": False,
            "terminal_state_decision": False,
            "manifest_generation": False,
            "atom_sea_handoff": False,
        },
    }
    meta_path.write_text(json.dumps(envelope, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return envelope


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Execute exactly one transport GET and emit bytes/status/headers/provenance")
    p.add_argument("--url", required=True)
    p.add_argument("--request-id", required=True)
    p.add_argument("--out-dir", type=Path, required=True)
    p.add_argument("--timeout", type=float, default=60.0)
    args = p.parse_args(argv)
    try:
        result = fetch_once(url=args.url, request_id=args.request_id, out_dir=args.out_dir, timeout=args.timeout)
    except Exception as exc:
        print(f"transport worker error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 2
    print(json.dumps({"request_id": result["request_id"], "status": result["status"], "body_size_bytes": result["body_size_bytes"], "network_error": result["network_error"]}))
    return 0 if result["network_error"] is None else 3


if __name__ == "__main__":
    raise SystemExit(main())
