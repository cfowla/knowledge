# v0.4 remote transport shim

This directory is intentionally not an acquisition engine. The Python runtime remains the acquisition brain.

The GitHub Actions workflow accepts only an opaque request ID and an exact URL already chosen by the Python runtime. The worker performs one unauthenticated HTTP GET and returns:

- raw response bytes (`response.body`), when a body exists;
- HTTP status;
- final URL after ordinary redirects;
- response headers;
- timestamps and request ID;
- a transport error string when no HTTP response could be obtained.

It does **not** resolve PMID/PMCID/DOI identity, choose providers, infer OA status, interpret licenses, validate PDF/JATS, compute acquisition SHA-256, select terminal state, write acquisition manifests, or build ATOM/SEA handoffs. Those remain Python responsibilities.

The worker does not accept credentials or authenticated request headers and does not bypass access controls. HTTP error bodies are returned as evidence; they are not interpreted as full text.
