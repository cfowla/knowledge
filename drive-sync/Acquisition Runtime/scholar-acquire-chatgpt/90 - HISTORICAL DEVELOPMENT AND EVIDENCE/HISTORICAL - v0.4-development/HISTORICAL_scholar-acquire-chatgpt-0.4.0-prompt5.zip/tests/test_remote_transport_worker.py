from __future__ import annotations

import importlib.util
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

WORKER = Path(__file__).resolve().parents[1] / "remote_transport" / "transport_worker.py"
spec = importlib.util.spec_from_file_location("transport_worker", WORKER)
mod = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(mod)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        body = b'<?xml version="1.0"?><article><front/><body><p>real bytes</p></body></article>'
        self.send_response(200)
        self.send_header("Content-Type", "application/xml")
        self.send_header("X-Test-Provenance", "transport-only")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *args):
        pass


def test_worker_returns_raw_xml_bytes_status_headers_without_acquisition_logic(tmp_path):
    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        url = f"http://127.0.0.1:{server.server_port}/article.xml"
        out = tmp_path / "out"
        env = mod.fetch_once(url=url, request_id="req-test", out_dir=out, timeout=5)
    finally:
        server.shutdown(); server.server_close(); thread.join(timeout=2)
    assert env["status"] == 200
    assert env["headers"]["Content-Type"] == "application/xml"
    assert env["worker_policy"]["content_validation"] is False
    assert env["worker_policy"]["acquisition_hashing"] is False
    assert (out / "response.body").read_bytes().startswith(b"<?xml")
    saved = json.loads((out / "transport_response.json").read_text())
    assert saved["request_id"] == "req-test"
    assert saved["body_size_bytes"] == (out / "response.body").stat().st_size
