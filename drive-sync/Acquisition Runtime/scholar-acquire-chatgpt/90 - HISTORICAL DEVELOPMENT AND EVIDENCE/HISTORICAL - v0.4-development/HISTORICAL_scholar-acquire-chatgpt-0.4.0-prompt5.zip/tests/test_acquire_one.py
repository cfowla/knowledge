import json
from pathlib import Path

import pytest

from scholar_acquire.acquire_one import AcquireOneRuntime, semantic_result_signature
from scholar_acquire.errors import RuntimeProtocolError
from scholar_acquire.models import ArtifactFormat, RuntimeState, SourceVersion
from scholar_acquire.regression import AcquireOneBatchRuntime, replay_case


def pdf_bytes():
    return b"%PDF-1.4\n" + b"x" * 1600 + b"\n%%EOF\n"


def jats_bytes(pmid="12345678"):
    return f'''<?xml version="1.0"?><article><front><article-meta><article-id pub-id-type="pmid">{pmid}</article-id><title-group><article-title>Fixture</article-title></title-group></article-meta></front><body><sec><title>Body</title><p>{'text ' * 500}</p></sec></body></article>'''.encode()


def artifact_kwargs(pmid="12345678"):
    return dict(
        discovery_provenance={"method": "fixture host tool"},
        acquisition_context={"lawful": True, "lawful_access_basis": "public OA fixture"},
        identity_evidence={"pmid": pmid},
        version=SourceVersion.PUBLISHED,
        license="CC BY 4.0",
    )


def test_acquire_one_success_prefers_jats_then_pdf(tmp_path: Path):
    r = AcquireOneRuntime.create("12345678", tmp_path / "r")
    r.add_resolved_ids(pmid="12345678", doi="10.1234/x", pmcid="PMC1234567", title="Fixture", evidence={"source": "fixture"})
    r.record_route_attempt("pmc", action="lookup", outcome="success", url="https://example.org/pmc")
    xml = tmp_path / "x.xml"; xml.write_bytes(jats_bytes())
    pdf = tmp_path / "x.pdf"; pdf.write_bytes(pdf_bytes())
    a1 = r.import_route_artifact("pmc", xml, source_url="https://example.org/article.xml", artifact_format=ArtifactFormat.JATS_XML, **artifact_kwargs())
    a2 = r.import_route_artifact("pmc", pdf, source_url="https://example.org/article.pdf", artifact_format=ArtifactFormat.PDF, **artifact_kwargs())
    step = r.step()
    assert step.state == RuntimeState.SUCCESS
    assert step.result.handoff.preferred_structured_path.name == "article.xml"
    assert step.result.handoff.preferred_pdf_path.name == "article.pdf"
    assert step.result.handoff.structured_sha256 == a1.sha256
    assert step.result.handoff.pdf_sha256 == a2.sha256
    assert step.result.manifest_path.exists()
    assert r.receipt_path.exists() and r.events_path.exists()


def test_identity_mismatch_fails_closed(tmp_path: Path):
    r = AcquireOneRuntime.create("12345678", tmp_path)
    with pytest.raises(RuntimeProtocolError, match="conflicts"):
        r.add_resolved_ids(pmid="87654321")


def test_no_false_success_without_success_attempt(tmp_path: Path):
    r = AcquireOneRuntime.create("12345678", tmp_path / "r")
    pdf = tmp_path / "x.pdf"; pdf.write_bytes(pdf_bytes())
    r.import_route_artifact("pmc", pdf, source_url="https://example.org/article.pdf", artifact_format=ArtifactFormat.PDF, **artifact_kwargs())
    step = r.step()
    assert step.state == RuntimeState.FAILED


def test_blocked_not_exhausted(tmp_path: Path):
    r = AcquireOneRuntime.create("12345678", tmp_path)
    r.mark_blocked(route="pmc", message="reCAPTCHA", cause_category="interactive_challenge", url="https://pmc.ncbi.nlm.nih.gov/")
    assert r.session.state == RuntimeState.BLOCKED
    assert r.session.terminal_outcome.provider_exhaustion_confirmed is False


def test_exhausted_requires_every_enabled_route(tmp_path: Path):
    r = AcquireOneRuntime.create("12345678", tmp_path)
    r.record_route_attempt("pmc", action="lookup", outcome="miss")
    with pytest.raises(RuntimeProtocolError, match="unattempted"):
        r.mark_exhausted()
    for route in ("publisher_oa", "unpaywall", "repository"):
        r.record_route_attempt(route, action="lookup", outcome="miss")
    out = r.mark_exhausted()
    assert out.state == RuntimeState.EXHAUSTED and out.provider_exhaustion_confirmed


def test_batch_reuses_exact_replay_semantics(tmp_path: Path):
    pdf = tmp_path / "x.pdf"; pdf.write_bytes(pdf_bytes())
    case = {
        "pmid": "12345678",
        "identity": {"pmid": "12345678", "doi": "10.1234/x", "title": "Fixture", "evidence": {"source": "fixture"}},
        "attempts": [{"route": "pmc", "action": "lookup", "outcome": "success", "url": "https://example.org/pmc"}],
        "artifacts": [{
            "route": "pmc", "path": str(pdf), "source_url": "https://example.org/article.pdf", "format": "pdf",
            "discovery_provenance": {"method": "fixture"}, "acquisition_context": {"lawful": True, "lawful_access_basis": "fixture"},
            "identity_evidence": {"pmid": "12345678"}, "version": "publishedVersion", "license": "CC BY 4.0",
        }],
    }
    individual = replay_case(case, tmp_path / "individual")
    batch = AcquireOneBatchRuntime.run([case], tmp_path / "batch")
    sig = batch.load_manifest()["items"][0]["signature"]
    assert sig == semantic_result_signature(individual)


def test_blocked_writes_terminal_manifest(tmp_path):
    runtime = AcquireOneRuntime.create("12345678", tmp_path / "blocked-manifest")
    runtime.add_resolved_ids(pmid="12345678", title="Blocked", evidence={"source":"test"})
    runtime.mark_blocked(route="pmc", message="transport blocked", cause_category="transport")
    manifest = Path(runtime._meta["terminal_manifest"])
    assert manifest.exists()
    data = json.loads(manifest.read_text())
    assert data["state"] == "blocked"
    assert data["identifier"]["value"] == "12345678"
    assert data["artifacts"] == []
    assert data["run_receipt"] == str(runtime.receipt_path)
    assert data["event_journal"] == str(runtime.events_path)
