from __future__ import annotations

import json
import shutil
import statistics
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from .acquire_one import AcquireOneRuntime, acquire_one, semantic_result_signature
from .models import ArtifactFormat, RuntimeState, SourceVersion


def replay_case(case: Mapping[str, Any], root: Path) -> AcquireOneRuntime:
    """Replay host-collected evidence through the exact acquire_one() product path."""
    runtime = acquire_one(str(case["pmid"]), root, route_flags=case.get("route_flags"))
    identity = case.get("identity") or {}
    runtime.add_resolved_ids(
        pmid=str(identity.get("pmid") or case["pmid"]),
        doi=identity.get("doi"),
        pmcid=identity.get("pmcid"),
        versioned_pmcid=identity.get("versioned_pmcid"),
        title=identity.get("title"),
        evidence=identity.get("evidence") or {},
    )
    for item in case.get("attempts") or []:
        runtime.record_route_attempt(
            item["route"],
            action=item.get("action", "discovery_or_transport"),
            outcome=item["outcome"],
            url=item.get("url"),
            http_status=item.get("http_status"),
            message=item.get("message"),
            elapsed_ms=item.get("elapsed_ms"),
            metadata=item.get("metadata") or {},
        )
    for item in case.get("artifacts") or []:
        runtime.import_route_artifact(
            item["route"],
            Path(item["path"]),
            source_url=item["source_url"],
            artifact_format=ArtifactFormat(item["format"]),
            discovery_provenance=item.get("discovery_provenance") or {},
            acquisition_context=item.get("acquisition_context") or {},
            version=SourceVersion(item.get("version", SourceVersion.UNKNOWN.value)),
            license=item.get("license"),
            identity_evidence=item.get("identity_evidence") or {"pmid": str(case["pmid"])},
        )
    terminal = case.get("terminal") or {}
    state = terminal.get("state")
    if state == RuntimeState.BLOCKED.value:
        runtime.mark_blocked(
            route=terminal["route"],
            message=terminal["message"],
            cause_category=terminal["cause_category"],
            url=terminal.get("url"),
            evidence=terminal.get("evidence") or {},
        )
    elif state == RuntimeState.EXHAUSTED.value:
        runtime.mark_exhausted(message=terminal.get("message") or "All enabled routes exhausted")
    elif state == RuntimeState.FAILED.value:
        runtime.mark_failed(message=terminal.get("message") or "Evidence replay failed")
    else:
        runtime.step()
    return runtime


class AcquireOneBatchRuntime:
    """Thin mapping layer over replay_case()/acquire_one(); no item semantics live here."""

    def __init__(self, batch_dir: Path):
        self.batch_dir = batch_dir.resolve()
        self.manifest_path = self.batch_dir / "batch_manifest.json"

    @classmethod
    def run(cls, cases: Iterable[Mapping[str, Any]], root: Path) -> "AcquireOneBatchRuntime":
        batch_id = uuid.uuid4().hex[:12]
        batch_dir = root.resolve() / f"batch-acquire-one-{batch_id}"
        items_root = batch_dir / "items"
        items_root.mkdir(parents=True, exist_ok=False)
        rows = []
        for case in cases:
            runtime = replay_case(case, items_root)
            rows.append(
                {
                    "pmid": str(case["pmid"]),
                    "session_id": runtime.session.session_id,
                    "session_path": str(runtime.session_path),
                    "state": runtime.session.state.value,
                    "signature": semantic_result_signature(runtime),
                    "run_receipt": str(runtime.receipt_path),
                    "event_journal": str(runtime.events_path),
                    "manifest": str(runtime.session.result_manifest) if runtime.session.result_manifest else None,
                }
            )
        obj = cls(batch_dir)
        obj.manifest_path.write_text(
            json.dumps(
                {
                    "schema_version": "1",
                    "batch_id": batch_id,
                    "mapping_semantics": "replay_case -> acquire_one; batch contains no acquisition policy",
                    "items": rows,
                    "created_at": datetime.now(timezone.utc).isoformat(),
                },
                indent=2,
                ensure_ascii=False,
            )
            + "\n",
            encoding="utf-8",
        )
        return obj

    def load_manifest(self) -> dict[str, Any]:
        return json.loads(self.manifest_path.read_text(encoding="utf-8"))


def build_regression_report(individual: list[AcquireOneRuntime], batch: AcquireOneBatchRuntime | None = None) -> dict[str, Any]:
    n = len(individual)
    successes = [r for r in individual if r.session.state == RuntimeState.SUCCESS]
    blocked = [r for r in individual if r.session.state == RuntimeState.BLOCKED]
    exhausted = [r for r in individual if r.session.state == RuntimeState.EXHAUSTED]
    failed = [r for r in individual if r.session.state == RuntimeState.FAILED]
    mismatches = []
    false_successes = []
    actions = []
    elapsed = []
    route_stats = {route: {"attempted_items": 0, "successful_items": 0} for route in ("pmc", "publisher_oa", "unpaywall", "repository")}
    success_payloads = {"jats_and_pdf": 0, "pdf_only": 0, "jats_only": 0}
    manifest_complete = 0
    item_manifest_complete = 0
    rows = []
    for r in individual:
        result = r._load_result() if r.session.state == RuntimeState.SUCCESS and r.session.result_manifest else None
        attempts = r._attempt_models()
        actions.append(len(attempts))
        measured = [a.elapsed_ms for a in attempts if a.elapsed_ms is not None]
        if measured:
            elapsed.append(sum(measured))
        resolved = (result.resolved_ids if result else r.session.seed.ids)
        if resolved.pmid and resolved.pmid != r.session.identifier.value:
            mismatches.append(r.session.identifier.value)
        if r.session.state == RuntimeState.SUCCESS and (not result or not result.artifacts):
            false_successes.append(r.session.identifier.value)
        attempted_routes = {a.provider for a in attempts}
        for route in route_stats:
            if route in attempted_routes:
                route_stats[route]["attempted_items"] += 1
            if result and any(a.provider == route for a in result.artifacts):
                route_stats[route]["successful_items"] += 1
        terminal_manifest_value = (r._meta.get("terminal_manifest") if not result else None)
        terminal_manifest = Path(terminal_manifest_value) if terminal_manifest_value else None
        if result:
            has_jats = any(a.format == ArtifactFormat.JATS_XML for a in result.artifacts)
            has_pdf = any(a.format == ArtifactFormat.PDF for a in result.artifacts)
            if has_jats and has_pdf:
                success_payloads["jats_and_pdf"] += 1
            elif has_pdf:
                success_payloads["pdf_only"] += 1
            elif has_jats:
                success_payloads["jats_only"] += 1
            if (
                result.manifest_path
                and result.manifest_path.exists()
                and r.receipt_path.exists()
                and r.events_path.exists()
                and all(a.sha256 and a.source_url and a.version for a in result.artifacts)
            ):
                manifest_complete += 1
                item_manifest_complete += 1
        elif (
            terminal_manifest
            and terminal_manifest.exists()
            and r.receipt_path.exists()
            and r.events_path.exists()
            and r.session.terminal_outcome is not None
            and bool(r._meta.get("identity_evidence"))
            and bool(attempts)
        ):
            item_manifest_complete += 1
        rows.append(
            {
                "pmid": r.session.identifier.value,
                "state": r.session.state.value,
                "resolved_ids": resolved.model_dump(mode="json"),
                "attempts": [a.model_dump(mode="json") for a in attempts],
                "artifact_count": len(result.artifacts) if result else 0,
                "artifact_sha256": [a.sha256 for a in result.artifacts] if result else [],
                "manifest": str(result.manifest_path) if result else (str(terminal_manifest) if terminal_manifest else None),
                "run_receipt": str(r.receipt_path),
                "event_journal": str(r.events_path),
                "terminal": r.session.terminal_outcome.model_dump(mode="json") if r.session.terminal_outcome else None,
                "handoff": result.handoff.model_dump(mode="json") if result and result.handoff else None,
            }
        )
    for route, stats in route_stats.items():
        stats["success_rate_among_attempted"] = (
            stats["successful_items"] / stats["attempted_items"] if stats["attempted_items"] else None
        )
    blocked_categories: dict[str, int] = {}
    for r in blocked:
        cat = ((r._meta.get("blocked") or {}).get("cause_category") or "unknown")
        blocked_categories[cat] = blocked_categories.get(cat, 0) + 1
    report = {
        "schema_version": "1",
        "item_count": n,
        "successful_full_text_acquisition_rate": len(successes) / n if n else 0,
        "success_count": len(successes),
        "blocked_count": len(blocked),
        "exhausted_count": len(exhausted),
        "failed_count": len(failed),
        "identity_mismatch_rate": len(mismatches) / n if n else 0,
        "identity_mismatches": mismatches,
        "false_success_rate": len(false_successes) / n if n else 0,
        "false_success_pmids": false_successes,
        "blocked_rate": len(blocked) / n if n else 0,
        "blocked_cause_categories": blocked_categories,
        "route_specific": route_stats,
        "median_tool_discovery_actions_per_pmid": statistics.median(actions) if actions else None,
        "median_elapsed_execution_ms_measured": statistics.median(elapsed) if elapsed else None,
        "elapsed_measurement_coverage": len(elapsed) / n if n else 0,
        "success_payload_mix": success_payloads,
        "proportion_successes_with_jats_and_pdf": (success_payloads["jats_and_pdf"] / len(successes)) if successes else 0,
        "proportion_successes_pdf_only": (success_payloads["pdf_only"] / len(successes)) if successes else 0,
        "manifest_provenance_completeness": item_manifest_complete / n if n else 0,
        "manifest_provenance_completeness_among_successes": manifest_complete / len(successes) if successes else 0,
        "item_manifest_complete_count": item_manifest_complete,
        "items": rows,
    }
    if batch is not None:
        batch_manifest = batch.load_manifest()
        individual_map = {r.session.identifier.value: semantic_result_signature(r) for r in individual}
        comparisons = []
        equivalent = True
        for item in batch_manifest["items"]:
            same = individual_map[item["pmid"]] == item["signature"]
            comparisons.append({"pmid": item["pmid"], "equivalent": same})
            equivalent = equivalent and same
        report["batch_equivalence"] = {
            "all_equivalent": equivalent,
            "equivalent_count": sum(1 for x in comparisons if x["equivalent"]),
            "item_count": len(comparisons),
            "comparisons": comparisons,
            "batch_manifest": str(batch.manifest_path),
        }
    return report
