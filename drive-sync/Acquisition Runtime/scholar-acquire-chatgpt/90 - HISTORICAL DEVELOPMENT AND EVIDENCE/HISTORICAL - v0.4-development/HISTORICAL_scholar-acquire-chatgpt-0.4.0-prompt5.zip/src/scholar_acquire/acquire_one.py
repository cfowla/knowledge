from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from .errors import ContentValidationError, RuntimeProtocolError
from .integration import build_atom_sea_handoff
from .models import (
    AcquisitionPolicy,
    AcquisitionResult,
    ArticleIdentifier,
    Artifact,
    ArtifactFormat,
    Attempt,
    IdentifierKind,
    ResolvedIds,
    RuntimeFailureCode,
    RuntimeState,
    RuntimeStep,
    RuntimeTerminalOutcome,
    SourceVersion,
)
from .runtime import ChatGptAcquisitionRuntime
from .utils import assert_allowed_url, extract_jats_article, link_or_copy, validate_pdf

ROUTE_ORDER: tuple[str, ...] = ("pmc", "publisher_oa", "unpaywall", "repository")
_ROUTE_ALIASES = {
    "pmc": "pmc",
    "pubmed_central": "pmc",
    "publisher": "publisher_oa",
    "publisher_oa": "publisher_oa",
    "unpaywall": "unpaywall",
    "repository": "repository",
    "institutional_repository": "repository",
}


class AcquireOneRuntime(ChatGptAcquisitionRuntime):
    """Evidence-driven v0.4 single-article acquisition product.

    The host performs scholarly lookup and lawful transport. Python remains the
    acquisition brain: it binds all evidence to the requested PMID, records the
    route strategy and actual route attempts, validates imported full text,
    hashes payloads, assigns terminal state, writes manifests/receipts/journals,
    and constructs ATOM/SEA handoffs.

    Network access is deliberately absent here. A route is successful only when
    a real materialized artifact is admitted and validated.
    """

    contract_version = "0.4.0-p5"

    @classmethod
    def create(
        cls,
        identifier: str | ArticleIdentifier,
        root: Path,
        *,
        output_dir: Path | None = None,
        cache_dir: Path | None = None,
        settings=None,
        route_flags: Mapping[str, bool] | None = None,
    ) -> "AcquireOneRuntime":
        ident = identifier if isinstance(identifier, ArticleIdentifier) else ArticleIdentifier.parse(identifier)
        if ident.kind != IdentifierKind.PMID:
            raise RuntimeProtocolError("acquire_one() requires a PMID")
        normalized_flags = {name: True for name in ROUTE_ORDER}
        for raw, enabled in (route_flags or {}).items():
            name = cls._normalize_route(raw)
            normalized_flags[name] = bool(enabled)
        policy = AcquisitionPolicy(want_structured=False, want_pdf=False, max_retries=0)
        runtime = super().create(
            ident,
            root,
            output_dir=output_dir,
            cache_dir=cache_dir,
            policy=policy,
            settings=settings,
            providers=[],
        )
        runtime.session.seed.ids.pmid = ident.value
        runtime.session.seed.metadata["acquire_one"] = {
            "contract_version": cls.contract_version,
            "requested_identifier": ident.model_dump(mode="json"),
            "route_order": list(ROUTE_ORDER),
            "route_flags": normalized_flags,
            "attempts": [],
            "identity": {"pmid": ident.value},
            "identity_evidence": [],
            "transport": "host_tool_mediated",
            "network_in_python": False,
            "batching": False,
            "automatic_provider_exhaustion": False,
            "accepted_payload_formats": [ArtifactFormat.JATS_XML.value, ArtifactFormat.PDF.value],
        }
        runtime._event(
            "acquire_one_initialized",
            data={"requested_pmid": ident.value, "route_flags": normalized_flags, "route_order": list(ROUTE_ORDER)},
        )
        runtime._save()
        return runtime

    @staticmethod
    def _normalize_route(route: str) -> str:
        key = str(route).strip().lower()
        try:
            return _ROUTE_ALIASES[key]
        except KeyError as exc:
            raise RuntimeProtocolError(f"Unknown acquire_one route: {route}") from exc

    @property
    def _meta(self) -> dict[str, Any]:
        meta = self.session.seed.metadata.get("acquire_one")
        if not isinstance(meta, dict):
            raise RuntimeProtocolError("acquire_one session metadata is missing")
        return meta

    def enabled_routes(self) -> list[str]:
        flags = self._meta.get("route_flags") or {}
        return [r for r in ROUTE_ORDER if bool(flags.get(r))]

    def add_resolved_ids(
        self,
        *,
        pmid: str | None = None,
        doi: str | None = None,
        pmcid: str | None = None,
        versioned_pmcid: str | None = None,
        title: str | None = None,
        evidence: Mapping[str, Any] | None = None,
    ) -> ResolvedIds:
        requested = self.session.identifier.value
        if pmid is not None and str(pmid) != requested:
            raise RuntimeProtocolError(f"Resolved PMID {pmid} conflicts with requested PMID {requested}")
        ids = super().add_resolved_ids(
            pmid=requested,
            doi=doi,
            pmcid=pmcid,
            versioned_pmcid=versioned_pmcid,
        )
        ident = self._meta.setdefault("identity", {})
        ident.update({k: v for k, v in {"pmid": requested, "doi": doi, "pmcid": pmcid, "versioned_pmcid": versioned_pmcid, "title": title}.items() if v})
        if evidence:
            self._meta.setdefault("identity_evidence", []).append(dict(evidence))
        self._event(
            "identity_resolved",
            data={"requested_pmid": requested, "resolved_ids": ids.model_dump(mode="json"), "title": title, "evidence": dict(evidence or {})},
        )
        self._save()
        return ids

    def record_route_attempt(
        self,
        route: str,
        *,
        action: str,
        outcome: str,
        url: str | None = None,
        http_status: int | None = None,
        message: str | None = None,
        elapsed_ms: int | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> Attempt:
        name = self._normalize_route(route)
        if name not in self.enabled_routes():
            raise RuntimeProtocolError(f"Route {name} is disabled for this acquire_one() run")
        if outcome not in {"success", "miss", "error", "skipped", "cached"}:
            raise RuntimeProtocolError(f"Invalid route outcome: {outcome}")
        if url:
            assert_allowed_url(url)
        attempts = self._attempt_models()
        if attempts:
            prior_index = max(ROUTE_ORDER.index(a.provider) for a in attempts)
            if ROUTE_ORDER.index(name) < prior_index:
                raise RuntimeProtocolError(
                    f"Route order regression: {name} cannot follow {attempts[-1].provider}; configured order is {ROUTE_ORDER}"
                )
        attempt = Attempt(
            provider=name,
            action=action,
            url=url,
            outcome=outcome,
            http_status=http_status,
            message=message,
            elapsed_ms=elapsed_ms,
            metadata=dict(metadata or {}),
        )
        self._meta.setdefault("attempts", []).append(attempt.model_dump(mode="json"))
        self._event(
            "route_attempt",
            provider=name,
            data={
                "action": action,
                "outcome": outcome,
                "url": url,
                "http_status": http_status,
                "message": message,
                "elapsed_ms": elapsed_ms,
                "metadata": dict(metadata or {}),
            },
        )
        self._save()
        return attempt

    def _attempt_models(self) -> list[Attempt]:
        return [Attempt.model_validate(x) for x in self._meta.get("attempts", [])]

    def import_route_artifact(
        self,
        route: str,
        path: Path,
        *,
        source_url: str,
        artifact_format: ArtifactFormat | str | None = None,
        discovery_provenance: Mapping[str, Any],
        acquisition_context: Mapping[str, Any],
        version: SourceVersion | str = SourceVersion.UNKNOWN,
        license: str | None = None,
        identity_evidence: Mapping[str, Any] | None = None,
    ) -> Artifact:
        name = self._normalize_route(route)
        if name not in self.enabled_routes():
            raise RuntimeProtocolError(f"Route {name} is disabled for this acquire_one() run")
        if not source_url or not source_url.strip():
            raise RuntimeProtocolError("Artifact import requires source_url")
        assert_allowed_url(source_url)
        if not discovery_provenance:
            raise RuntimeProtocolError("Artifact import requires discovery_provenance")
        if not acquisition_context:
            raise RuntimeProtocolError("Artifact import requires acquisition_context")
        lawful_basis = acquisition_context.get("lawful_access_basis")
        if not isinstance(lawful_basis, str) or not lawful_basis.strip():
            raise RuntimeProtocolError("acquisition_context requires lawful_access_basis")
        if acquisition_context.get("lawful") is not True:
            raise RuntimeProtocolError("acquisition_context requires lawful=true")
        evidence_pmid = (identity_evidence or {}).get("pmid")
        if evidence_pmid is not None and str(evidence_pmid) != self.session.identifier.value:
            raise RuntimeProtocolError(
                f"Artifact identity PMID {evidence_pmid} conflicts with requested PMID {self.session.identifier.value}"
            )
        resolved_pmid = self.session.seed.ids.pmid
        if resolved_pmid and resolved_pmid != self.session.identifier.value:
            raise RuntimeProtocolError("Resolved identity conflicts with requested PMID")

        fmt = ArtifactFormat(artifact_format) if artifact_format is not None else None
        if fmt is not None and fmt not in {ArtifactFormat.JATS_XML, ArtifactFormat.PDF}:
            raise RuntimeProtocolError("acquire_one accepts only JATS XML or PDF full-text payloads")
        artifact = super().import_artifact(
            path,
            source_url=source_url,
            provider=name,
            artifact_format=fmt,
            version=version,
            license=license,
            structured=(True if fmt == ArtifactFormat.JATS_XML else None),
            metadata={
                "acquire_one": {
                    "contract_version": self.contract_version,
                    "route": name,
                    "requested_pmid": self.session.identifier.value,
                    "discovery_provenance": dict(discovery_provenance),
                    "acquisition_context": dict(acquisition_context),
                    "identity_evidence": dict(identity_evidence or {}),
                }
            },
        )
        if artifact.format not in {ArtifactFormat.JATS_XML, ArtifactFormat.PDF}:
            raise RuntimeProtocolError("Imported payload did not validate as JATS XML or PDF")
        self._event(
            "route_artifact_validated",
            provider=name,
            data={
                "format": artifact.format.value,
                "sha256": artifact.sha256,
                "size_bytes": artifact.size_bytes,
                "source_url": source_url,
                "version": artifact.version.value,
                "license": artifact.license,
            },
        )
        self._save()
        return artifact

    def _write_terminal_manifest(self) -> Path:
        """Write an evidence manifest for BLOCKED/EXHAUSTED/FAILED items.

        Successful acquisitions use AcquisitionResult manifests.  Non-success is
        still a first-class item result and must preserve identity, route
        evidence, terminal semantics, and run provenance without pretending a
        payload exists.
        """
        if self.session.state not in {RuntimeState.BLOCKED, RuntimeState.EXHAUSTED, RuntimeState.FAILED}:
            raise RuntimeProtocolError("terminal manifest requires a non-success terminal state")
        workdir = self.session.output_dir / self.session.identifier.value
        workdir.mkdir(parents=True, exist_ok=True)
        path = workdir / "terminal_manifest.json"
        obj = {
            "schema_version": "1",
            "contract_version": self.contract_version,
            "identifier": self.session.identifier.model_dump(mode="json"),
            "resolved_ids": self.session.seed.ids.model_dump(mode="json"),
            "identity": dict(self._meta.get("identity") or {}),
            "identity_evidence": list(self._meta.get("identity_evidence") or []),
            "state": self.session.state.value,
            "provider_policy": self.enabled_routes(),
            "provider_attempts": [a.model_dump(mode="json") for a in self._attempt_models()],
            "artifacts": [],
            "terminal_outcome": self.session.terminal_outcome.model_dump(mode="json") if self.session.terminal_outcome else None,
            "blocked": dict(self._meta.get("blocked") or {}),
            "run_receipt": str(self.receipt_path),
            "event_journal": str(self.events_path),
            "session_path": str(self.session_path),
            "written_at": datetime.now(timezone.utc).isoformat(),
        }
        path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        self._meta["terminal_manifest"] = str(path)
        self._event("terminal_manifest_written", data={"manifest_path": str(path), "state": self.session.state.value})
        return path

    def mark_blocked(
        self,
        *,
        route: str,
        message: str,
        cause_category: str,
        url: str | None = None,
        evidence: Mapping[str, Any] | None = None,
        reason_code: RuntimeFailureCode = RuntimeFailureCode.EXTERNAL_FETCH_BLOCKED,
    ) -> RuntimeTerminalOutcome:
        name = self._normalize_route(route)
        if url:
            assert_allowed_url(url)
        # A BLOCKED route is an error attempt, not evidence of provider exhaustion.
        self.record_route_attempt(
            name,
            action="transport_or_access",
            outcome="error",
            url=url,
            message=message,
            metadata={"cause_category": cause_category, **dict(evidence or {})},
        )
        attempts = self._attempt_models()
        outcome = RuntimeTerminalOutcome(
            state=RuntimeState.BLOCKED,
            reason_code=reason_code,
            message=message,
            provider_policy=self.enabled_routes(),
            provider_attempts=attempts,
            provider_exhaustion_confirmed=False,
            artifact_sha256=[a.sha256 for a in self.session.seed.artifacts],
        )
        self._set_terminal(outcome)
        self._meta["blocked"] = {"route": name, "cause_category": cause_category, "evidence": dict(evidence or {})}
        self._event(
            "terminal_blocked",
            provider=name,
            data={"reason_code": reason_code.value, "cause_category": cause_category, "message": message},
        )
        self._write_terminal_manifest()
        self._save()
        return outcome

    def mark_exhausted(self, *, message: str = "All enabled lawful routes exhausted without a materializable full-text payload") -> RuntimeTerminalOutcome:
        if self.session.seed.artifacts:
            raise RuntimeProtocolError("Cannot mark EXHAUSTED after a payload has been imported")
        attempts = self._attempt_models()
        by_route = {r: [a for a in attempts if a.provider == r] for r in self.enabled_routes()}
        missing = [r for r, rows in by_route.items() if not rows]
        if missing:
            raise RuntimeProtocolError(f"Cannot prove exhaustion; unattempted enabled routes: {', '.join(missing)}")
        errors = [a for a in attempts if a.outcome == "error"]
        if errors:
            raise RuntimeProtocolError("Cannot mark EXHAUSTED while route errors/barriers remain; use BLOCKED or FAILED")
        nonterminal = [r for r, rows in by_route.items() if not any(a.outcome in {"miss", "skipped"} for a in rows)]
        if nonterminal:
            raise RuntimeProtocolError(f"Cannot prove exhaustion; routes lack evidence-backed miss/skip: {', '.join(nonterminal)}")
        outcome = RuntimeTerminalOutcome(
            state=RuntimeState.EXHAUSTED,
            message=message,
            provider_policy=self.enabled_routes(),
            provider_attempts=attempts,
            provider_exhaustion_confirmed=True,
            artifact_sha256=[],
        )
        self._set_terminal(outcome)
        self._event("terminal_exhausted", data={"provider_exhaustion_confirmed": True, "message": message})
        self._write_terminal_manifest()
        self._save()
        return outcome

    def mark_failed(
        self,
        *,
        message: str,
        reason_code: RuntimeFailureCode = RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR,
    ) -> RuntimeTerminalOutcome:
        outcome = RuntimeTerminalOutcome(
            state=RuntimeState.FAILED,
            reason_code=reason_code,
            message=message,
            provider_policy=self.enabled_routes(),
            provider_attempts=self._attempt_models(),
            provider_exhaustion_confirmed=False,
            artifact_sha256=[a.sha256 for a in self.session.seed.artifacts],
        )
        self._set_terminal(outcome)
        self._event("terminal_failed", data={"reason_code": reason_code.value, "message": message})
        self._write_terminal_manifest()
        self._save()
        return outcome

    def step(self) -> RuntimeStep:
        if self.session.state == RuntimeState.SUCCESS and self.session.result_manifest:
            return RuntimeStep(
                state=RuntimeState.SUCCESS,
                session_path=self.session_path,
                result=self._load_result(),
                terminal_outcome=self.session.terminal_outcome,
                message="acquire_one() already successful",
            )
        if self.session.state in {RuntimeState.BLOCKED, RuntimeState.EXHAUSTED, RuntimeState.FAILED}:
            return RuntimeStep(
                state=self.session.state,
                session_path=self.session_path,
                terminal_outcome=self.session.terminal_outcome,
                message=self.session.terminal_outcome.message if self.session.terminal_outcome else self.session.state.value,
            )
        if self.session.pending_request is not None:
            return self._fail_step(RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR, "acquire_one() does not emit raw-HTTP requests from Python")
        if not self.session.seed.artifacts:
            self.session.state = RuntimeState.READY
            self._event("awaiting_host_evidence", data={"enabled_routes": self.enabled_routes(), "attempt_count": len(self._attempt_models())})
            self._save()
            return RuntimeStep(
                state=RuntimeState.READY,
                session_path=self.session_path,
                message="Awaiting host-discovered route evidence and a materialized lawful full-text payload, or an evidence-backed terminal non-success",
            )
        try:
            result = self._finalize_success()
        except Exception as exc:
            code = RuntimeFailureCode.INVALID_RESPONSE if isinstance(exc, ContentValidationError) else RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR
            return self._fail_step(code, f"{type(exc).__name__}: {exc}")
        attempts = self._attempt_models()
        routes_with_payloads = sorted({a.provider for a in result.artifacts}, key=ROUTE_ORDER.index)
        outcome = RuntimeTerminalOutcome(
            state=RuntimeState.SUCCESS,
            message="Acquisition succeeded with validated, hashed lawful full-text payload(s)",
            provider_policy=self.enabled_routes(),
            provider_attempts=attempts,
            provider_exhaustion_confirmed=False,
            artifact_sha256=[a.sha256 for a in result.artifacts],
        )
        self.session.state = RuntimeState.SUCCESS
        self.session.result_manifest = result.manifest_path
        self.session.terminal_outcome = outcome
        self.session.error = None
        self._event(
            "terminal_success",
            data={"routes_with_payloads": routes_with_payloads, "artifact_sha256": outcome.artifact_sha256, "false_success_guard": "payload_validation_required"},
        )
        self._save()
        return RuntimeStep(state=RuntimeState.SUCCESS, session_path=self.session_path, result=result, terminal_outcome=outcome, message=outcome.message)

    def _validate_artifact(self, artifact: Artifact) -> None:
        body = artifact.local_path.read_bytes()
        if artifact.format == ArtifactFormat.PDF:
            validate_pdf(body)
        elif artifact.format == ArtifactFormat.JATS_XML:
            normalized = extract_jats_article(body)
            # The cache object for JATS is the normalized <article>; verify hash against normalized bytes.
            body = normalized
        else:
            raise RuntimeProtocolError(f"Non-full-text payload in acquire_one success set: {artifact.format.value}")
        digest = hashlib.sha256(body).hexdigest()
        if digest != artifact.sha256:
            raise ContentValidationError(f"Artifact SHA-256 mismatch for {artifact.local_path}")
        meta = artifact.metadata.get("acquire_one")
        if not isinstance(meta, dict):
            raise RuntimeProtocolError("Artifact acquire_one provenance metadata missing")
        if meta.get("requested_pmid") != self.session.identifier.value:
            raise RuntimeProtocolError("Artifact is not bound to the requested PMID")
        if meta.get("route") != artifact.provider or artifact.provider not in self.enabled_routes():
            raise RuntimeProtocolError("Artifact route provenance mismatch")
        if not meta.get("discovery_provenance"):
            raise RuntimeProtocolError("Artifact discovery provenance missing")
        context = meta.get("acquisition_context") or {}
        if context.get("lawful") is not True or not context.get("lawful_access_basis"):
            raise RuntimeProtocolError("Artifact lawful-access provenance missing")

    def _finalize_success(self) -> AcquisitionResult:
        requested = self.session.identifier.value
        resolved = self.session.seed.ids.model_copy(deep=True)
        if resolved.pmid and resolved.pmid != requested:
            raise RuntimeProtocolError(f"Resolved PMID {resolved.pmid} conflicts with requested PMID {requested}")
        resolved.pmid = requested
        artifacts = [a.model_copy(deep=True) for a in self.session.seed.artifacts]
        if not artifacts:
            raise RuntimeProtocolError("SUCCESS requires at least one materialized full-text artifact")
        for artifact in artifacts:
            self._validate_artifact(artifact)
        # A route cannot be reported as successful solely by attempt metadata. It must own a payload.
        attempts = self._attempt_models()
        for artifact in artifacts:
            if not any(a.provider == artifact.provider and a.outcome in {"success", "cached"} for a in attempts):
                raise RuntimeProtocolError(f"Artifact from {artifact.provider} lacks a recorded successful route attempt")

        workdir = self.session.output_dir / requested
        workdir.mkdir(parents=True, exist_ok=True)
        materialized: list[Artifact] = []
        # Exactly one preferred JATS and one preferred PDF are exposed to downstream interfaces.
        preferred_jats = next((a for a in artifacts if a.format == ArtifactFormat.JATS_XML), None)
        preferred_pdf = next((a for a in artifacts if a.format == ArtifactFormat.PDF), None)
        for artifact in artifacts:
            if artifact is preferred_jats:
                dest = workdir / "article.xml"
            elif artifact is preferred_pdf:
                dest = workdir / "article.pdf"
            else:
                suffix = ".xml" if artifact.format == ArtifactFormat.JATS_XML else ".pdf"
                dest = workdir / f"article.{artifact.provider}{suffix}"
            if artifact.local_path.resolve() != dest.resolve():
                link_or_copy(artifact.local_path, dest)
            copy = artifact.model_copy(deep=True)
            copy.local_path = dest
            materialized.append(copy)

        result = AcquisitionResult(
            identifier=self.session.identifier,
            resolved_ids=resolved,
            artifacts=materialized,
            attempts=attempts,
            metadata={
                "acquire_one": {
                    **{k: v for k, v in self._meta.items() if k != "attempts"},
                    "terminal_state": RuntimeState.SUCCESS.value,
                    "run_receipt": str(self.receipt_path),
                    "event_journal": str(self.events_path),
                    "manifest_provenance_complete": True,
                    "preferred_payload_order": [ArtifactFormat.JATS_XML.value, ArtifactFormat.PDF.value],
                    "finalized_at": datetime.now(timezone.utc).isoformat(),
                }
            },
        )
        manifest_path = workdir / "manifest.json"
        result.manifest_path = manifest_path
        result.handoff = build_atom_sea_handoff(result, manifest_path)
        manifest_path.write_text(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        self._event(
            "manifest_written",
            data={
                "manifest_path": str(manifest_path),
                "preferred_structured_path": str(result.handoff.preferred_structured_path) if result.handoff.preferred_structured_path else None,
                "preferred_pdf_path": str(result.handoff.preferred_pdf_path) if result.handoff.preferred_pdf_path else None,
                "structured_sha256": result.handoff.structured_sha256,
                "pdf_sha256": result.handoff.pdf_sha256,
            },
        )
        return result

    def _fail_step(self, reason_code: RuntimeFailureCode, message: str) -> RuntimeStep:
        outcome = self.mark_failed(message=message, reason_code=reason_code)
        return RuntimeStep(state=RuntimeState.FAILED, session_path=self.session_path, terminal_outcome=outcome, message=message)


# Product entry point: this is deliberately one article, one runtime, one semantics.
def acquire_one(
    pmid: str,
    root: Path,
    *,
    route_flags: Mapping[str, bool] | None = None,
) -> AcquireOneRuntime:
    return AcquireOneRuntime.create(pmid, root, route_flags=route_flags)


def semantic_result_signature(runtime: AcquireOneRuntime) -> dict[str, Any]:
    """Stable item-level signature used to prove individual/batch equivalence."""
    state = runtime.session.state
    result = runtime._load_result() if state == RuntimeState.SUCCESS and runtime.session.result_manifest else None
    attempts = runtime._attempt_models()
    return {
        "state": state.value,
        "requested": runtime.session.identifier.model_dump(mode="json"),
        "resolved_ids": (result.resolved_ids if result else runtime.session.seed.ids).model_dump(mode="json"),
        "attempts": [
            {
                "provider": a.provider,
                "action": a.action,
                "url": a.url,
                "outcome": a.outcome,
                "http_status": a.http_status,
                "message": a.message,
                "elapsed_ms": a.elapsed_ms,
                "metadata": a.metadata,
            }
            for a in attempts
        ],
        "artifacts": sorted(
            [
                {
                    "format": a.format.value,
                    "provider": a.provider,
                    "source_url": a.source_url,
                    "sha256": a.sha256,
                    "size_bytes": a.size_bytes,
                    "version": a.version.value,
                    "license": a.license,
                }
                for a in (result.artifacts if result else runtime.session.seed.artifacts)
            ],
            key=lambda x: (x["format"], x["provider"], x["sha256"]),
        ),
        "handoff": (
            {
                "structured_sha256": result.handoff.structured_sha256 if result.handoff else None,
                "pdf_sha256": result.handoff.pdf_sha256 if result.handoff else None,
            }
            if result
            else None
        ),
        "terminal": {
            "provider_exhaustion_confirmed": runtime.session.terminal_outcome.provider_exhaustion_confirmed if runtime.session.terminal_outcome else False,
            "reason_code": runtime.session.terminal_outcome.reason_code.value if runtime.session.terminal_outcome and runtime.session.terminal_outcome.reason_code else None,
        },
    }
