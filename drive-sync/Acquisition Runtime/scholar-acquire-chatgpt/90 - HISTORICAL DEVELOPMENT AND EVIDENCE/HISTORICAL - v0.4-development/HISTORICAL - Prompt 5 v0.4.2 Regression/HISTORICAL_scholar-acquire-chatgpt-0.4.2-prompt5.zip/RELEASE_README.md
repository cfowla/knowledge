# scholar-acquire-chatgpt v0.4.2 Prompt-5 release

This bundle contains the v0.4.2 acquisition brain, ten-PMID regression inputs/report, Prompt-5 documentation, minimal remote transport worker, GitHub Actions wrapper, and evidence tests. The large acquired PDFs and run directories are intentionally excluded from this source bundle; their paths, hashes, manifests, and handoff receipts are recorded in the regression report and remain in the execution workspace.
