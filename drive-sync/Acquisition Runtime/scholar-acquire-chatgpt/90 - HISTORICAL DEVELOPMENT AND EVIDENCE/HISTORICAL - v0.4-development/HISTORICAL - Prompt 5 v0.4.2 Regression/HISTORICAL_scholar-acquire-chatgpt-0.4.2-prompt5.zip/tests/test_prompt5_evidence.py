import hashlib, json
from pathlib import Path
from scholar_acquire.integrity import verify_build_manifest

ROOT=Path('/mnt/data/acq')
REPORT=ROOT/'PROMPT5_REGRESSION_REPORT.json'

def report(): return json.loads(REPORT.read_text())

def test_runtime_build_integrity():
    assert verify_build_manifest()['integrity_verified'] is True

def test_all_ten_have_required_evidence():
    r=report(); assert len(r['items'])==10
    for item in r['items']:
        assert Path(item['run_receipt']).is_file()
        assert Path(item['event_journal']).is_file()
        assert Path(item['manifest']).is_file()
        assert Path(item['terminal_outcome']).is_file()

def test_success_payload_hashes_and_handoffs():
    r=report(); successes=[x for x in r['items'] if x['state']=='success']; assert len(successes)==7
    for item in successes:
        proof=json.loads(Path(item['handoff_receipt']).read_text()); assert proof['accepted'] is True
        for art in item['artifacts']:
            p=Path(art['local_path']); assert hashlib.sha256(p.read_bytes()).hexdigest()==art['sha256']

def test_no_false_success_and_no_identity_mismatch():
    m=report()['metrics']; assert m['false_success_rate']==0.0; assert m['identity_mismatch_rate']==0.0

def test_batch_is_semantically_equivalent():
    r=report(); assert all(r['batch_equivalence'].values()); assert r['metrics']['batch_semantic_equivalence_rate']==1.0
