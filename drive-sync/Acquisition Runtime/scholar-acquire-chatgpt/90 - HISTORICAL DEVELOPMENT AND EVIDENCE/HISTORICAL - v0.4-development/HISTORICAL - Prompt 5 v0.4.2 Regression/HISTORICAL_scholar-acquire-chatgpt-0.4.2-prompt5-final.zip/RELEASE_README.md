# scholar-acquire-chatgpt v0.4.2 Prompt-5 release

This bundle contains the v0.4.2 acquisition brain, the immutable ten-PMID regression specification and report, Prompt-5 documentation, the minimal remote transport worker, GitHub Actions wrapper, and portable release tests.

The acquired PDFs and per-run evidence are kept in the separate `prompt5-regression-evidence-and-payloads.zip` bundle so the source release stays small. The source tests validate the package build and embedded report without assuming a fixed `/mnt/data` path. To independently verify the evidence ZIP, including all seven successful PDF SHA-256 values, run:

```bash
python verify_prompt5_evidence.py /path/to/prompt5-regression-evidence-and-payloads.zip
```

The evidence verifier checks all ten item-level receipts/journals/manifests/terminal outcomes, all seven successful payload hashes and ATOM/SEA handoff receipts, and the recorded 10/10 batch-equivalence gate.
