import hashlib
import json
import socketserver
import threading
from http.server import BaseHTTPRequestHandler
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from remote_worker.transport_worker import execute

BODY=b'<?xml version="1.0"?><article><front/></article>'
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(206)
        self.send_header('Content-Type','application/xml')
        self.send_header('X-Test','transport-only')
        self.end_headers(); self.wfile.write(BODY)
    def log_message(self,*args): pass

def test_worker_returns_exact_transport_facts():
    with socketserver.TCPServer(('127.0.0.1',0),Handler) as srv:
        t=threading.Thread(target=srv.serve_forever,daemon=True); t.start()
        port=srv.server_address[1]
        out=execute({'request_id':'req-1','url':f'http://127.0.0.1:{port}/x','method':'GET'})
        srv.shutdown()
    assert out['transport_state']=='response'
    assert out['status_code']==206
    assert out['headers']['Content-Type']=='application/xml'
    assert out['body_sha256']==hashlib.sha256(BODY).hexdigest()
    import base64
    assert base64.b64decode(out['body_base64'])==BODY
