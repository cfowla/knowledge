#!/usr/bin/env python3
"""Minimal network transport executor for scholar-acquire-chatgpt.

This worker has deliberately no scholarly/provider logic. It accepts one
pre-authorized HTTP(S) request and returns transport facts plus exact response
bytes (base64). The Python acquisition runtime remains the decision-maker.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

MAX_BYTES = 128 * 1024 * 1024
ALLOWED_METHODS = {"GET", "HEAD"}


def execute(request_doc: dict) -> dict:
    url = str(request_doc.get("url") or "")
    method = str(request_doc.get("method") or "GET").upper()
    if method not in ALLOWED_METHODS:
        raise ValueError(f"method not allowed: {method}")
    parts = urlsplit(url)
    if parts.scheme not in {"http", "https"} or not parts.hostname:
        raise ValueError("url must be absolute http(s)")
    headers = {str(k): str(v) for k, v in (request_doc.get("headers") or {}).items()}
    timeout = int(request_doc.get("timeout_seconds") or 60)
    req = Request(url=url, headers=headers, method=method)
    started = datetime.now(timezone.utc)
    try:
        try:
            response = urlopen(req, timeout=timeout)
        except HTTPError as exc:
            response = exc
        with response:
            body = response.read(MAX_BYTES + 1)
            if len(body) > MAX_BYTES:
                raise ValueError(f"response exceeds {MAX_BYTES} byte limit")
            status = int(getattr(response, "status", None) or response.getcode())
            response_headers = {k: v for k, v in response.headers.items()}
            final_url = response.geturl()
    except URLError as exc:
        return {
            "schema_version": "1",
            "request_id": request_doc.get("request_id"),
            "transport_state": "error",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "requested_url": url,
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
        }
    finished = datetime.now(timezone.utc)
    return {
        "schema_version": "1",
        "request_id": request_doc.get("request_id"),
        "transport_state": "response",
        "requested_url": url,
        "final_url": final_url,
        "method": method,
        "status_code": status,
        "headers": response_headers,
        "body_base64": base64.b64encode(body).decode("ascii"),
        "body_size_bytes": len(body),
        "body_sha256": hashlib.sha256(body).hexdigest(),
        "started_at": started.isoformat(),
        "retrieved_at": finished.isoformat(),
        "elapsed_ms": round((finished - started).total_seconds() * 1000),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("request_json", type=Path)
    parser.add_argument("response_json", type=Path)
    args = parser.parse_args()
    request_doc = json.loads(args.request_json.read_text(encoding="utf-8"))
    try:
        result = execute(request_doc)
    except Exception as exc:
        result = {
            "schema_version": "1",
            "request_id": request_doc.get("request_id"),
            "transport_state": "error",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "requested_url": request_doc.get("url"),
            "retrieved_at": datetime.now(timezone.utc).isoformat(),
        }
    args.response_json.parent.mkdir(parents=True, exist_ok=True)
    args.response_json.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return 0 if result.get("transport_state") == "response" else 2


if __name__ == "__main__":
    raise SystemExit(main())
