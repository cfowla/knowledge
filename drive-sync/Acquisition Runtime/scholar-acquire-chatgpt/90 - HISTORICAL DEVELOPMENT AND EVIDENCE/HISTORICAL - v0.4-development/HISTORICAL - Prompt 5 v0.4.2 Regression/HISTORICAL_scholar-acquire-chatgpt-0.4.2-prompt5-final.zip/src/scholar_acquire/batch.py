from __future__ import annotations

import hashlib
import json
import platform
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from .integrity import verify_build_manifest
from .models import AcquisitionResult, RuntimeState
from .vertical_slice import AcquisitionExecution, AcquisitionSpec, acquire_one


def semantic_fingerprint(execution: AcquisitionExecution) -> str:
    result = execution.result
    payload = {
        "pmid": execution.pmid,
        "state": execution.state.value,
        "resolved_ids": result.resolved_ids.model_dump(mode="json") if result else None,
        "artifacts": sorted([
            {
                "format": a.format.value,
                "provider": a.provider,
                "source_url": a.source_url,
                "sha256": a.sha256,
                "size_bytes": a.size_bytes,
                "version": a.version.value,
                "license": a.license,
            }
            for a in (result.artifacts if result else [])
        ], key=lambda x: (x["format"], x["provider"], x["sha256"])),
        "attempts": [
            {
                "provider": a.provider,
                "action": a.action,
                "url": a.url,
                "outcome": a.outcome,
                "http_status": a.http_status,
                "message": a.message,
            }
            for a in (result.attempts if result else (execution.terminal_outcome.provider_attempts if execution.terminal_outcome else []))
        ],
        "terminal": {
            "state": execution.terminal_outcome.state.value,
            "reason_code": execution.terminal_outcome.reason_code.value if execution.terminal_outcome.reason_code else None,
            "provider_exhaustion_confirmed": execution.terminal_outcome.provider_exhaustion_confirmed,
        } if execution.terminal_outcome else None,
        "handoff": {
            "structured_sha256": result.handoff.structured_sha256,
            "pdf_sha256": result.handoff.pdf_sha256,
        } if result and result.handoff else None,
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


class ChatGptBatchRuntime:
    """Thin v0.4 batch mapping over acquire_one().

    Batch mode adds no acquisition semantics. Every item is executed by the
    exact same acquire_one function used by individual runs.
    """

    def __init__(self, batch_dir: Path):
        self.batch_dir = batch_dir.resolve()
        self.manifest_path = self.batch_dir / "batch_manifest.json"

    @classmethod
    def run(cls, specs: Iterable[AcquisitionSpec], root: Path) -> "ChatGptBatchRuntime":
        specs = list(specs)
        identity = verify_build_manifest()
        batch_id = uuid.uuid4().hex[:12]
        batch_dir = root.resolve() / f"batch-{batch_id}"
        items_root = batch_dir / "items"
        items_root.mkdir(parents=True, exist_ok=False)
        receipt = {
            "schema_version": "2",
            "run_id": f"acq-batch-{batch_id}",
            "batch_id": batch_id,
            "version": identity["version"],
            "runtime_class": cls.__name__,
            "package_tree_sha256": identity["actual_package_tree_sha256"],
            "integrity_verified": True,
            "python_version": sys.version.split()[0],
            "platform": platform.platform(),
            "network_in_python": False,
            "batch_semantics": "map acquire_one(spec) without modification",
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        (batch_dir / "BATCH_RUN_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
        event_path = batch_dir / "batch_events.jsonl"
        executions: list[AcquisitionExecution] = []
        for idx, spec in enumerate(specs):
            t0 = time.perf_counter()
            ex = acquire_one(spec, items_root)
            executions.append(ex)
            evt = {
                "event": "item_complete", "batch_id": batch_id, "index": idx, "pmid": spec.pmid,
                "state": ex.state.value, "semantic_fingerprint": semantic_fingerprint(ex),
                "elapsed_ms": round((time.perf_counter() - t0) * 1000), "at": datetime.now(timezone.utc).isoformat(),
            }
            with event_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(evt) + "\n")
        manifest = {
            "schema_version": "2",
            "batch_id": batch_id,
            "run_id": receipt["run_id"],
            "batch_semantics": "map acquire_one(spec) without modification",
            "items": [
                {
                    "pmid": ex.pmid,
                    "state": ex.state.value,
                    "semantic_fingerprint": semantic_fingerprint(ex),
                    "session_path": str(ex.session_path),
                    "run_receipt": str(ex.run_receipt),
                    "event_journal": str(ex.event_journal),
                    "manifest_path": str(ex.manifest_path) if ex.manifest_path else None,
                }
                for ex in executions
            ],
            "counts": {s.value: sum(ex.state == s for ex in executions) for s in RuntimeState if any(ex.state == s for ex in executions)},
            "updated_at": datetime.now(timezone.utc).isoformat(),
        }
        (batch_dir / "batch_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        return cls(batch_dir)

    def read_manifest(self) -> dict:
        return json.loads(self.manifest_path.read_text(encoding="utf-8"))
