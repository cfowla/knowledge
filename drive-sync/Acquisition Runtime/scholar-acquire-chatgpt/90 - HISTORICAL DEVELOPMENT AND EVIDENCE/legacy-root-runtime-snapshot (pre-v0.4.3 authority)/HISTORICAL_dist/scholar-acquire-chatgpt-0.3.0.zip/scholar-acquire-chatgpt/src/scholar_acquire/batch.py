from __future__ import annotations

import json
import platform
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

from .integrity import verify_build_manifest
from .models import AcquisitionPolicy, ArticleIdentifier, RuntimeState
from .runtime import ChatGptAcquisitionRuntime


class BatchItemEvidence(BaseModel):
    identifier: ArticleIdentifier
    session_id: str
    session_path: Path
    state: RuntimeState
    run_receipt: Path | None = None
    event_journal: Path
    terminal_outcome: Path | None = None
    manifest_path: Path | None = None
    artifact_sha256: list[str] = Field(default_factory=list)
    provider_exhaustion_confirmed: bool = False
    failure_reason: str | None = None


class BatchManifest(BaseModel):
    schema_version: str = "1"
    batch_id: str
    created_at: datetime
    updated_at: datetime
    identifiers: list[ArticleIdentifier]
    items: list[BatchItemEvidence]
    counts: dict[str, int]
    evidence_complete: bool
    run_receipt: Path
    batch_events: Path


class ChatGptBatchRuntime:
    """Evidence-first wrapper for a set of tool-mediated acquisition sessions.

    It does not retrieve content itself. Each child ChatGptAcquisitionRuntime remains
    the controller for its identifier. This wrapper creates the immutable batch
    receipt before any child is stepped and derives the batch manifest only from
    child runtime artifacts.
    """

    receipt_filename = "RUN_RECEIPT.json"
    manifest_filename = "batch_manifest.json"
    events_filename = "runtime_events.jsonl"
    state_filename = "batch_state.json"

    def __init__(self, batch_dir: Path):
        self.batch_dir = batch_dir.resolve()
        self.receipt_path = self.batch_dir / self.receipt_filename
        if not self.receipt_path.exists():
            raise FileNotFoundError(f"Batch receipt not found: {self.receipt_path}")
        self.receipt = json.loads(self.receipt_path.read_text(encoding="utf-8"))
        state_path = self.batch_dir / self.state_filename
        self.state = json.loads(state_path.read_text(encoding="utf-8")) if state_path.exists() else {"session_paths": []}

    @classmethod
    def create(
        cls,
        identifiers: list[str | ArticleIdentifier],
        root: Path,
        *,
        policy: AcquisitionPolicy | None = None,
        providers: list | None = None,
    ) -> "ChatGptBatchRuntime":
        build = verify_build_manifest()
        parsed = [x if isinstance(x, ArticleIdentifier) else ArticleIdentifier.parse(x) for x in identifiers]
        batch_id = uuid.uuid4().hex[:12]
        batch_dir = root.resolve() / f"batch-{batch_id}"
        sessions_root = batch_dir / "sessions"
        sessions_root.mkdir(parents=True, exist_ok=False)
        receipt = {
            "schema_version": "1",
            "run_id": f"batch-{batch_id}",
            "batch_id": batch_id,
            "package": "scholar-acquire-chatgpt",
            "version": build.get("version", "unknown"),
            "runtime_class": "ChatGptBatchRuntime",
            "package_tree_sha256": build["actual_package_tree_sha256"],
            "expected_package_tree_sha256": build["package_tree_sha256"],
            "integrity_verified": True,
            "build_manifest_path": build["manifest_path"],
            "python_version": sys.version.split()[0],
            "platform": platform.platform(),
            "execution_mode": "tool-mediated",
            "network_in_python": False,
            "identifiers": [x.model_dump(mode="json") for x in parsed],
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        (batch_dir / cls.receipt_filename).write_text(
            json.dumps(receipt, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        batch = cls(batch_dir)
        batch._event("batch_initialized", {"identifier_count": len(parsed)})
        session_paths: list[str] = []
        for ident in parsed:
            runtime = ChatGptAcquisitionRuntime.create(
                ident,
                sessions_root,
                policy=policy,
                providers=providers,
            )
            session_paths.append(str(runtime.session_path))
            batch._event(
                "child_runtime_created",
                {"session_id": runtime.session.session_id, "identifier": ident.model_dump(mode="json")},
            )
        state = {"schema_version": "1", "batch_id": batch_id, "session_paths": session_paths}
        (batch_dir / cls.state_filename).write_text(
            json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
        batch.state = state
        batch.refresh_manifest()
        return batch

    @property
    def session_paths(self) -> list[Path]:
        return [Path(x) for x in self.state.get("session_paths", [])]

    def load_runtime(self, index: int, *, providers: list | None = None) -> ChatGptAcquisitionRuntime:
        return ChatGptAcquisitionRuntime.load(self.session_paths[index], providers=providers)

    def refresh_manifest(self) -> BatchManifest:
        items: list[BatchItemEvidence] = []
        counts = {s.value: 0 for s in RuntimeState}
        evidence_complete = True
        for session_path in self.session_paths:
            runtime = ChatGptAcquisitionRuntime.load(session_path)
            session = runtime.session
            counts[session.state.value] = counts.get(session.state.value, 0) + 1
            terminal_path = session.session_dir / runtime.terminal_filename
            receipt_path = session.receipt_path
            events_path = session.session_dir / runtime.events_filename
            if receipt_path is None or not Path(receipt_path).exists() or not events_path.exists():
                evidence_complete = False
            items.append(
                BatchItemEvidence(
                    identifier=session.identifier,
                    session_id=session.session_id,
                    session_path=runtime.session_path,
                    state=session.state,
                    run_receipt=receipt_path,
                    event_journal=events_path,
                    terminal_outcome=terminal_path if terminal_path.exists() else None,
                    manifest_path=session.result_manifest,
                    artifact_sha256=(session.terminal_outcome.artifact_sha256 if session.terminal_outcome else []),
                    provider_exhaustion_confirmed=(
                        session.terminal_outcome.provider_exhaustion_confirmed if session.terminal_outcome else False
                    ),
                    failure_reason=(
                        session.terminal_outcome.reason_code.value
                        if session.terminal_outcome and session.terminal_outcome.reason_code
                        else None
                    ),
                )
            )
        now = datetime.now(timezone.utc)
        manifest = BatchManifest(
            batch_id=self.receipt["batch_id"],
            created_at=datetime.fromisoformat(self.receipt["started_at"]),
            updated_at=now,
            identifiers=[ArticleIdentifier.model_validate(x) for x in self.receipt["identifiers"]],
            items=items,
            counts=counts,
            evidence_complete=evidence_complete,
            run_receipt=self.receipt_path,
            batch_events=self.batch_dir / self.events_filename,
        )
        (self.batch_dir / self.manifest_filename).write_text(
            json.dumps(manifest.model_dump(mode="json"), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        self._event("batch_manifest_refreshed", {"counts": counts, "evidence_complete": evidence_complete})
        return manifest

    def _event(self, event: str, data: dict[str, Any]) -> None:
        path = self.batch_dir / self.events_filename
        payload = {
            "event": event,
            "batch_id": self.receipt["batch_id"],
            "data": data,
            "at": datetime.now(timezone.utc).isoformat(),
        }
        with path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(payload, ensure_ascii=False) + "\n")
