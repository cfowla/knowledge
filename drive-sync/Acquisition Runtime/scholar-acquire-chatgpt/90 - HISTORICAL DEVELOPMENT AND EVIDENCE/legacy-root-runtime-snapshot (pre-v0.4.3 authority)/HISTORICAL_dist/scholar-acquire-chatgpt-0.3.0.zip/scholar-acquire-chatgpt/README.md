# scholar-acquire-chatgpt

A fork of `scholar-acquire` optimized for ChatGPT and other tool-mediated execution environments.

The original acquisition policy is preserved:

1. Europe PMC
2. PubMed Central (PMC)
3. Unpaywall discovery
4. Publisher open access
5. Institutional repository / accepted manuscript

Sci-Hub and paywall/authentication bypasses are explicitly excluded.

## Why this fork exists

A normal Python program assumes it can open network sockets. ChatGPT's Python runtime often cannot, while ChatGPT may have separate retrieval tools that *can* access public web resources. This fork separates those responsibilities:

- **ChatGPT/tool layer:** performs external retrieval.
- **Python runtime:** resolves provider logic, validates content, hashes bytes, caches responses, records provenance, ranks artifacts, writes manifests, and prepares ATOM/SEA handoff paths.

Python itself does not need outbound network access in ChatGPT mode.

## Core runtime protocol

`ChatGptAcquisitionRuntime.step()` runs the normal provider pipeline until a URL is needed that is not already cached.

Instead of making an HTTP request, it returns an `ExternalFetchRequest` and persists the request in the session directory.

The host retrieves the resource, ingests the raw response bytes, then calls `step()` again. The provider pipeline restarts deterministically, consumes the cached response, and proceeds to the next required resource.

This makes sessions resumable across separate ChatGPT Python executions.

```text
PMID / DOI / PMCID
       |
       v
ChatGptAcquisitionRuntime.step()
       |
       +---- cache hit -------------------------+
       |                                        |
       +---- cache miss -> ExternalFetchRequest |
                              |                 |
                              v                 |
                    ChatGPT retrieval tool      |
                              |                 |
                              v                 |
                       ingest bytes/file        |
                              |                 |
                              +-----------------+
       |
       v
validation -> SHA-256 -> provenance -> ranking
       |
       v
manifest.json + ATOM/SEA handoff
```

## Python API

```python
from pathlib import Path
from scholar_acquire import ChatGptAcquisitionRuntime
from scholar_acquire.models import RuntimeState

runtime = ChatGptAcquisitionRuntime.create(
    "10.1056/NEJMoa2314051",
    Path("/mnt/data/scholar-runtime"),
)

step = runtime.step()

if step.state == RuntimeState.NEEDS_FETCH:
    req = step.pending_request
    # The ChatGPT/tool layer retrieves req.url.
    # Then ingest the raw body:
    runtime.ingest_file(
        Path("/mnt/data/retrieved-response.bin"),
        request_id=req.request_id,
        status_code=200,
        content_type="application/json",
    )
    step = runtime.step()
```

Continue the retrieve/ingest/step cycle until `state == "complete"`.

## Directly importing a retrieved or uploaded article

If ChatGPT already has the primary PDF or JATS XML, it does not need to rediscover or redownload it.

```python
runtime.import_artifact(
    Path("/mnt/data/article.pdf"),
    source_url="https://publisher.example/article.pdf",
    provider="chatgpt_import",
    version="publishedVersion",
)

step = runtime.step()
```

PDFs are validated before admission. JATS XML is parsed and normalized to its `<article>` element before hashing and storage.

## Seeding tool-discovered OA locations

ChatGPT can inject a location it discovered independently:

```python
runtime.add_location(
    url="https://repository.example/item/123",
    host_type="repository",
    pdf_url="https://repository.example/item/123/file.pdf",
    version="acceptedVersion",
    source_name="Example University Repository",
)
```

Resolved identifiers can also be injected:

```python
runtime.add_resolved_ids(
    pmid="12345678",
    doi="10.1234/example",
    pmcid="PMC1234567",
)
```

This avoids repeating discovery work when a ChatGPT tool already produced authoritative metadata.

## CLI

The original networked CLI remains available for ordinary computers:

```bash
scholar-acquire fetch 12345678 --out ./literature
```

The ChatGPT runtime exposes a resumable CLI protocol:

```bash
scholar-acquire-chatgpt chatgpt begin 12345678 --root /mnt/data/runtime
scholar-acquire-chatgpt chatgpt status /mnt/data/runtime/session-XXXXXXXXXXXX
scholar-acquire-chatgpt chatgpt step /mnt/data/runtime/session-XXXXXXXXXXXX
```

When a fetch is required, the session contains:

- `pending_fetch.json` — exact machine-readable request for the host tool.
- `runtime_status.json` — safe/redacted status suitable for inspection.
- `session.json` — complete resumable session state. Treat this as internal because a pending API request may contain contact information or an API key in its query string.

After external retrieval:

```bash
scholar-acquire-chatgpt chatgpt ingest \
  /mnt/data/runtime/session-XXXXXXXXXXXX \
  /mnt/data/retrieved.bin \
  --content-type application/json
```

By default `ingest` immediately advances to the next acquisition step.

If the article has already been retrieved:

```bash
scholar-acquire-chatgpt chatgpt import-artifact \
  /mnt/data/runtime/session-XXXXXXXXXXXX \
  /mnt/data/article.pdf \
  --source-url https://example.org/article.pdf \
  --version publishedVersion
```

## Provenance and storage

The fork retains the original content-addressed storage and provenance model:

- SHA-256 for every stored response/artifact.
- SQLite response index.
- Content-addressed object store.
- Provider/action attempt records.
- Source URL, version, license, media type, retrieval time, and provider metadata.
- External tool retrieval history embedded under `metadata.chatgpt_runtime.fetch_history` in the final manifest.
- Secret-redacted URLs in the safe runtime status and fetch history.

Tool-ingested bytes use the exact request URL as the cache key, so rerunning the provider pipeline consumes them exactly as a normal HTTP response would have been consumed.

## ATOM / SEA boundary

The final result retains the same integration contract as the original package:

```python
result.handoff.preferred_structured_path
result.handoff.preferred_pdf_path
result.handoff.structured_sha256
result.handoff.pdf_sha256
result.handoff.manifest_path
```

ATOM and SEA therefore do not need provider-specific acquisition logic.

## Source-version policy

Repository candidates are ranked approximately as:

1. published version
2. accepted manuscript
3. unknown repository version
4. submitted/preprint version

Submitted versions are disabled by default. Named preprint servers with an unknown version are also excluded unless submitted copies are explicitly allowed.

## Current API contracts

See [`API_CONTRACTS.md`](API_CONTRACTS.md). The fork inherits the API verification performed for the original implementation, including the 2026 PMC distribution transition away from the legacy OA Web Service/FTP route.

## Tests

Run:

```bash
PYTHONPATH=src pytest -q
```

The suite covers the original provider/cache behavior plus tool-mediated suspension/resumption, session persistence, imported artifact short-circuiting, and safe status redaction.

## 0.3.0 evidence-enforced ChatGPT runtime

Version 0.3.0 makes program use observable and fail-closed. `ChatGptAcquisitionRuntime` verifies `RUNTIME_BUILD.json` before it starts or resumes, creates an immutable `RUN_RECEIPT.json`, appends `runtime_events.jsonl`, requires an emitted capability token for every external response ingest, and distinguishes `success`, `exhausted`, `blocked`, and `failed`.

A host-level inability to retrieve an emitted URL is `blocked`, not provider exhaustion. `mark_fetch_blocked()` retains the pending request so the session can resume later.

`ChatGptBatchRuntime` creates an immutable batch receipt before child acquisition sessions and derives `batch_manifest.json` from child runtime evidence. See `EXECUTION_CONTRACT.md` and `ACCEPTANCE_TEST.md`.
