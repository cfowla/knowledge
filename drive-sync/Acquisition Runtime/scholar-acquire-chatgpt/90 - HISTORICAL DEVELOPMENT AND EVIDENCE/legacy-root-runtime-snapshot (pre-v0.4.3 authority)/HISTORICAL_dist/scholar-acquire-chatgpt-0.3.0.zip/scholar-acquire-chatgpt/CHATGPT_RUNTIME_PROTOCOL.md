# ChatGPT Runtime Operator Protocol

`scholar-acquire-chatgpt` is the controller. ChatGPT is an external I/O adapter for network retrieval and durable storage.

## Mandatory startup

1. Materialize the canonical package bytes.
2. Instantiate `ChatGptAcquisitionRuntime` or `ChatGptBatchRuntime`. Construction verifies `RUNTIME_BUILD.json`; verification failure is fail-closed.
3. Confirm that `RUN_RECEIPT.json` exists before performing any article lookup for the run.
4. Do not replace a failed runtime startup with web research or manual acquisition.

## Execution loop

Run `step()` until it returns one of:

- `needs_fetch`: retrieve exactly the emitted request and ingest the raw response.
- `success`: validated artifacts satisfy policy.
- `exhausted`: the configured lawful provider policy completed and exhaustion is proven.
- `blocked`: the host could not satisfy an emitted fetch; retain the session for later resumption.
- `failed`: runtime/provider/protocol execution failed and exhaustion is not proven.

For `needs_fetch`, preserve `request_id` and `ingest_token`. Ingest must use both. The runtime rejects responses that cannot be correlated to its emitted request.

For a real HTTP 404/403/410/etc., ingest the actual status and body. That is a provider response, not a host-level blockage. The provider decides whether to continue.

If the retrieval layer cannot materialize the requested response at all, call `mark_fetch_blocked()` with a typed reason. Do not call it "no OA copy found."

## Fast path

If a PDF, JATS XML, HTML full text, or text artifact is already present, use `import_artifact()`. Imported artifacts are validated, hashed, journaled, cached, and then evaluated against the same acquisition policy.

Authoritative IDs or lawful OA locations discovered outside the provider chain may be seeded with `add_resolved_ids()` or `add_location()`, but they do not become successful acquisitions until the runtime validates an artifact.

## Evidence and persistence

Persist the complete session directory. The minimum evidence set is defined in `EXECUTION_CONTRACT.md` and includes the immutable receipt, append-only event journal, resumable session, terminal outcome, provider manifest when present, hashes, raw cached responses, and acquired payloads.

The user-facing summary must be derived from these artifacts. The assistant may explain the result but may not independently classify the acquisition.

## Source policy

Default order: Europe PMC -> PMC -> Unpaywall -> publisher OA -> institutional repository / accepted manuscript. Prefer structured JATS plus PDF when available. Never use Sci-Hub or bypass access controls.
