# Scholarly Acquisition Execution Contract

This contract governs tool-mediated scholarly acquisition with `scholar-acquire-chatgpt` 0.3.x.

## Fail-closed requirements

1. Every PMID, PMCID, or DOI acquisition MUST be controlled by `ChatGptAcquisitionRuntime` or a child session created by `ChatGptBatchRuntime`.
2. Before a session is created or resumed, the runtime MUST verify the materialized package tree against `src/scholar_acquire/RUNTIME_BUILD.json`.
3. If the build manifest is missing or the package hash differs, execution MUST stop. Web search, manual browsing, model reasoning, or direct file retrieval MUST NOT substitute for runtime execution.
4. The runtime MUST create `RUN_RECEIPT.json` before the first external fetch request. A run without this receipt is invalid.
5. External retrieval is permitted only in response to an `ExternalFetchRequest` emitted by the runtime, except for an explicitly supplied artifact imported through `import_artifact()`.
6. Every fetched response used by the pipeline MUST be ingested with the exact emitted `request_id` and `ingest_token`.
7. The runtime MUST reject an ingest with a missing or mismatched request ID or capability token.
8. If the host cannot satisfy an emitted fetch request, the host MUST call `mark_fetch_blocked()` and preserve the session. It MUST NOT classify that condition as provider exhaustion.
9. `SUCCESS` is valid only when the runtime validates artifacts that satisfy the configured acquisition policy.
10. `EXHAUSTED` is valid only when the configured lawful provider policy completes without provider errors and the runtime sets `provider_exhaustion_confirmed=true`.
11. `BLOCKED` means execution can resume after the external dependency is resolved. It is not evidence that lawful full text does not exist.
12. `FAILED` means the runtime itself encountered a protocol/provider/runtime error that prevents a valid exhaustion claim.
13. The assistant may explain runtime results but MUST NOT manufacture, upgrade, downgrade, or replace runtime terminal states.
14. Sci-Hub, credential bypass, CAPTCHA bypass, paywall circumvention, and access-control evasion are prohibited.

## Required evidence

Each session MUST preserve:

- `RUN_RECEIPT.json`
- `session.json`
- `runtime_status.json`
- `runtime_events.jsonl`
- `pending_fetch.json` while a request is outstanding
- `terminal_outcome.json` after a terminal or blocked disposition
- provider-generated `manifest.json` when the orchestrator completes
- cached raw response objects addressed by SHA-256
- validated structured/PDF payloads when acquired

Every `runtime_events.jsonl` journal MUST make the request/response bridge observable with at least:

- `runtime_integrity_verified`
- `runtime_initialized`
- `step_started`
- `external_fetch_requested` when applicable
- `external_response_ingested` when applicable
- `provider_result` after provider execution
- `artifact_validated` for each accepted artifact
- one of `terminal_success`, `terminal_exhausted`, `terminal_failed`, or `external_fetch_blocked`

## Provider policy

The default lawful provider sequence is:

1. Europe PMC
2. PMC
3. Unpaywall
4. Publisher OA
5. Institutional repository / accepted manuscript

Structured JATS is a first-class success artifact. PDF failure alone is not an acquisition failure when the configured policy is satisfied by validated structured full text.
