# Acquisition Runtime Acceptance Test

Before a production batch, run an evidence-level acceptance test. Recommended regression PMIDs from the first failed operator test are `20566676`, `23963895`, `26911584`, and `37496050`.

A test passes only when all of the following are true:

1. `RUNTIME_BUILD.json` exists and package integrity verification passes.
2. The package reports the expected version and materialized module path in `RUN_RECEIPT.json`.
3. `runtime_events.jsonl` exists before any external response is ingested.
4. Every external fetch comes from an emitted `ExternalFetchRequest`.
5. Every ingested response uses the exact `request_id` and `ingest_token` from that request.
6. At least one visible `step -> needs_fetch -> ingest -> step` round trip completes in the test suite.
7. A deliberately wrong capability token is rejected.
8. A deliberately blocked fetch produces `BLOCKED`, retains `pending_fetch.json`, and can later resume by ingesting the correct response.
9. A no-artifact provider chain with no provider errors produces `EXHAUSTED` with `provider_exhaustion_confirmed=true`.
10. A provider exception produces `FAILED`, not `EXHAUSTED`.
11. A validated imported PDF or JATS artifact can satisfy policy without any provider fetch.
12. `runtime_status.json` never exposes the capability token or sensitive query-string values.
13. A batch run creates an immutable batch `RUN_RECEIPT.json`, per-session receipts/journals, and a derived `batch_manifest.json`.
14. Test output is saved as `test_output.txt` with the source/wheel hashes for the tested build.

If requirements 1-8 fail, the acquisition runtime is not operational even if a PDF can be found manually.
