from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .errors import RuntimeIntegrityError, RuntimeUnavailableError

BUILD_MANIFEST_NAME = "RUNTIME_BUILD.json"


def package_root() -> Path:
    return Path(__file__).resolve().parent


def compute_package_tree_sha256(root: Path | None = None) -> str:
    root = (root or package_root()).resolve()
    h = hashlib.sha256()
    files = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if path.name == BUILD_MANIFEST_NAME or "__pycache__" in rel.parts or path.suffix == ".pyc":
            continue
        files.append((rel.as_posix(), path))
    for rel, path in sorted(files):
        h.update(rel.encode("utf-8"))
        h.update(b"\0")
        h.update(path.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def write_build_manifest(*, version: str, root: Path | None = None, extra: dict[str, Any] | None = None) -> Path:
    root = (root or package_root()).resolve()
    payload = {
        "schema_version": "1",
        "package": "scholar-acquire-chatgpt",
        "version": version,
        "package_tree_sha256": compute_package_tree_sha256(root),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        **(extra or {}),
    }
    path = root / BUILD_MANIFEST_NAME
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return path


def verify_build_manifest(root: Path | None = None) -> dict[str, Any]:
    root = (root or package_root()).resolve()
    path = root / BUILD_MANIFEST_NAME
    if not path.exists():
        raise RuntimeUnavailableError(
            f"{BUILD_MANIFEST_NAME} is missing; tool-mediated acquisition is fail-closed"
        )
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeUnavailableError(f"Cannot read {BUILD_MANIFEST_NAME}: {exc}") from exc
    expected = payload.get("package_tree_sha256")
    if not expected:
        raise RuntimeUnavailableError(f"{BUILD_MANIFEST_NAME} lacks package_tree_sha256")
    actual = compute_package_tree_sha256(root)
    if actual != expected:
        raise RuntimeIntegrityError(
            f"Runtime integrity mismatch: expected {expected}, actual {actual}"
        )
    return {**payload, "actual_package_tree_sha256": actual, "manifest_path": str(path)}
