from __future__ import annotations

import hashlib
import json
import re
import time
import unicodedata
from enum import Enum
from pathlib import Path
from typing import Any, Mapping, Protocol

from pydantic import BaseModel, Field

from .errors import RuntimeProtocolError
from .capabilities import AcquisitionRoute, CapabilityStatus, RouteCapabilityRegistry
from .identity import ArticleIdentity
from .models import (
    ArticleIdentifier,
    ArtifactFormat,
    IdentifierKind,
    ResolvedIds,
    RuntimeFailureCode,
    RuntimeState,
    SourceVersion,
)
from .transport_contract import (
    TransportRegistry,
    TransportRequest,
    TransportResponse,
    TransportResponseState,
)
from .utils import assert_allowed_url
from .vertical_slice import (
    AcquisitionExecution,
    ChatGptVerticalSliceRuntime,
)


class AcquisitionConfig(BaseModel):
    want_structured: bool = True
    want_pdf: bool = True
    allow_submitted: bool = False
    route_capabilities: RouteCapabilityRegistry = Field(default_factory=RouteCapabilityRegistry)


class HostRequestKind(str, Enum):
    RESOLVE_IDENTITY = "resolve_identity"
    OBSERVE_ROUTE = "observe_route"


class HostRequest(BaseModel):
    request_id: str
    kind: HostRequestKind
    identifier: ArticleIdentifier
    route: AcquisitionRoute | None = None
    resolved_ids: ResolvedIds = Field(default_factory=ResolvedIds)
    article_identity: ArticleIdentity | None = None

    @classmethod
    def build(
        cls,
        *,
        kind: HostRequestKind,
        identifier: ArticleIdentifier,
        route: AcquisitionRoute | None = None,
        resolved_ids: ResolvedIds | None = None,
        article_identity: ArticleIdentity | None = None,
    ) -> "HostRequest":
        material = "|".join(
            [kind.value, identifier.kind.value, identifier.value, route.value if route else ""]
        ).encode("utf-8")
        return cls(
            request_id=hashlib.sha256(material).hexdigest()[:24],
            kind=kind,
            identifier=identifier,
            route=route,
            resolved_ids=resolved_ids or ResolvedIds(),
            article_identity=article_identity,
        )


class IdentityObservation(BaseModel):
    request_id: str
    pmid: str
    title: str
    evidence_source: str
    evidence_method: str
    pmcid: str | None = None
    doi: str | None = None
    journal: str | None = None
    year: int | None = None
    evidence_sha256: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ArtifactObservation(BaseModel):
    path: Path
    format: ArtifactFormat
    source_url: str
    discovery_provenance: dict[str, Any]
    lawful_access_basis: str
    open_access: bool
    version: SourceVersion = SourceVersion.UNKNOWN
    license: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class TransportLocationObservation(BaseModel):
    url: str
    format: ArtifactFormat
    expected_media_type: str | None = None
    discovery_provenance: dict[str, Any]
    lawful_access_basis: str
    open_access: bool
    version: SourceVersion = SourceVersion.UNKNOWN
    license: str | None = None
    headers: dict[str, str] = Field(default_factory=dict)
    timeout_seconds: int = 60
    max_bytes: int | None = 128 * 1024 * 1024
    metadata: dict[str, Any] = Field(default_factory=dict)


class RouteObservationKind(str, Enum):
    MATERIALIZED_ARTIFACT = "materialized_artifact"
    LOCATION_DISCOVERED = "location_discovered"
    DEFINITIVE_NO_RESULT = "definitive_no_result"
    TRANSPORT_ERROR = "transport_error"
    TIMEOUT = "timeout"
    CAPTCHA = "captcha"
    RESPONSE_NOT_MATERIALIZABLE = "response_not_materializable"
    UNKNOWN = "unknown"
    SEARCH_ABSENCE = "search_absence"
    SKIPPED = "skipped"


class RouteObservation(BaseModel):
    request_id: str
    route: AcquisitionRoute
    kind: RouteObservationKind
    action: str
    artifacts: list[ArtifactObservation] = Field(default_factory=list)
    locations: list[TransportLocationObservation] = Field(default_factory=list)
    evidence_source: str | None = None
    http_status: int | None = None
    message: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class UnpaywallLocation(BaseModel):
    """Raw OA-location metadata returned by an Unpaywall lookup.

    This is intentionally not a TransportLocationObservation. The host reports
    Unpaywall facts; Python applies version/format policy and chooses the URL.
    """

    url: str | None = None
    url_for_pdf: str | None = None
    url_for_landing_page: str | None = None
    host_type: str | None = None
    version: str | None = None
    license: str | None = None
    repository_institution: str | None = None
    evidence: str | None = None
    is_best: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class UnpaywallLookupObservation(BaseModel):
    """Uninterpreted Unpaywall DOI-object facts returned to the controller."""

    request_id: str
    doi: str
    evidence_source: str
    http_status: int | None = 200
    title: str | None = None
    is_oa: bool | None = None
    oa_status: str | None = None
    locations: list[UnpaywallLocation] = Field(default_factory=list)
    message: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class HostAdapter(Protocol):
    def observe(
        self, request: HostRequest
    ) -> IdentityObservation | RouteObservation | UnpaywallLookupObservation:
        ...


_BLOCKING_KINDS = {
    RouteObservationKind.TRANSPORT_ERROR,
    RouteObservationKind.TIMEOUT,
    RouteObservationKind.CAPTCHA,
    RouteObservationKind.RESPONSE_NOT_MATERIALIZABLE,
    RouteObservationKind.UNKNOWN,
    RouteObservationKind.SEARCH_ABSENCE,
    RouteObservationKind.SKIPPED,
}


def normalize_title(value: str) -> str:
    value = unicodedata.normalize("NFKD", value)
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()
    return re.sub(r"\s+", " ", value)


def _record_host_event(runtime: ChatGptVerticalSliceRuntime, request: HostRequest, observation: BaseModel) -> None:
    payload = observation.model_dump(mode="json")
    runtime._event(
        "host_observation_received",
        provider=request.route.value if request.route else None,
        data={"request": request.model_dump(mode="json"), "observation": payload},
    )
    runtime._save()


def _resolve_identity(
    runtime: ChatGptVerticalSliceRuntime,
    identifier: ArticleIdentifier,
    host: HostAdapter,
) -> ArticleIdentity:
    request = HostRequest.build(kind=HostRequestKind.RESOLVE_IDENTITY, identifier=identifier)
    runtime._event("host_observation_requested", data=request.model_dump(mode="json"))
    runtime._save()
    observation = host.observe(request)
    if not isinstance(observation, IdentityObservation):
        raise RuntimeProtocolError("Host returned a non-identity observation for identity resolution")
    _record_host_event(runtime, request, observation)
    if observation.request_id != request.request_id:
        raise RuntimeProtocolError("Identity observation request_id mismatch")
    if not observation.evidence_source.strip() or not observation.evidence_method.strip():
        raise RuntimeProtocolError("Resolved identity requires an evidence source and method")
    if identifier.kind != IdentifierKind.PMID:
        raise RuntimeProtocolError("v0.4.3 Prompt 1 production controller currently requires PMID input")
    if observation.pmid != identifier.value:
        raise RuntimeProtocolError(
            f"Resolved PMID {observation.pmid} conflicts with requested PMID {identifier.value}"
        )
    if not observation.title.strip():
        raise RuntimeProtocolError("Resolved identity requires a title")

    identity = ArticleIdentity(
        pmid=identifier.value,
        pmcid=observation.pmcid,
        doi=observation.doi,
        title=observation.title.strip(),
        journal=observation.journal,
        year=observation.year,
    )
    v04 = runtime.session.seed.metadata["v0_4"]
    v04["article_identity"] = identity.model_dump(mode="json")
    v04["normalized_title"] = normalize_title(identity.title)
    v04["identity_evidence"] = observation.model_dump(mode="json")
    runtime.add_resolved_ids(
        pmid=identity.pmid,
        doi=identity.doi,
        pmcid=identity.pmcid,
    )
    runtime._event(
        "identity_resolved_by_python",
        data={
            "resolved_ids": runtime.session.seed.ids.model_dump(mode="json"),
            "normalized_title": v04["normalized_title"],
            "journal": identity.journal,
            "year": identity.year,
            "evidence_source": observation.evidence_source,
        },
    )
    runtime._save()
    return identity


def _observe_route(
    runtime: ChatGptVerticalSliceRuntime,
    identifier: ArticleIdentifier,
    identity: ArticleIdentity,
    route: AcquisitionRoute,
    host: HostAdapter,
) -> RouteObservation:
    request = HostRequest.build(
        kind=HostRequestKind.OBSERVE_ROUTE,
        identifier=identifier,
        route=route,
        resolved_ids=runtime.session.seed.ids,
        article_identity=identity,
    )
    runtime._event(
        "host_observation_requested",
        provider=route.value,
        data=request.model_dump(mode="json"),
    )
    runtime._save()
    observation = host.observe(request)
    if route == AcquisitionRoute.UNPAYWALL and isinstance(
        observation, UnpaywallLookupObservation
    ):
        _record_host_event(runtime, request, observation)
        return _evaluate_unpaywall_lookup(request, identity, observation, runtime)
    if not isinstance(observation, RouteObservation):
        raise RuntimeProtocolError(f"Host returned a non-route observation for {route.value}")
    _record_host_event(runtime, request, observation)
    if observation.request_id != request.request_id:
        raise RuntimeProtocolError(f"Route observation request_id mismatch for {route.value}")
    if observation.route != route:
        raise RuntimeProtocolError(
            f"Route observation mismatch. requested={route.value} observed={observation.route.value}"
        )
    return observation


def _normalize_doi(value: str | None) -> str | None:
    if not value:
        return None
    value = value.strip().lower()
    value = re.sub(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", "", value)
    return value.rstrip(".,;)")


def _source_version(value: str | None) -> SourceVersion:
    normalized = (value or "unknown").strip().lower()
    mapping = {
        "publishedversion": SourceVersion.PUBLISHED,
        "published": SourceVersion.PUBLISHED,
        "acceptedversion": SourceVersion.ACCEPTED,
        "accepted": SourceVersion.ACCEPTED,
        "submittedversion": SourceVersion.SUBMITTED,
        "submitted": SourceVersion.SUBMITTED,
    }
    return mapping.get(normalized, SourceVersion.UNKNOWN)


def _evaluate_unpaywall_lookup(
    request: HostRequest,
    identity: ArticleIdentity,
    observation: UnpaywallLookupObservation,
    runtime: ChatGptVerticalSliceRuntime,
) -> RouteObservation:
    """Apply Unpaywall OA-location policy inside Python, not in the host."""

    if observation.request_id != request.request_id:
        raise RuntimeProtocolError("Unpaywall observation request_id mismatch")
    expected_doi = _normalize_doi(identity.doi)
    observed_doi = _normalize_doi(observation.doi)
    if not expected_doi:
        return RouteObservation(
            request_id=request.request_id,
            route=AcquisitionRoute.UNPAYWALL,
            kind=RouteObservationKind.DEFINITIVE_NO_RESULT,
            action="unpaywall_lookup",
            evidence_source=observation.evidence_source,
            message="Resolved article identity has no DOI; Unpaywall route is inapplicable",
            metadata={"reason": "doi_unavailable", "definitive_provider_evidence": True},
        )
    if observed_doi != expected_doi:
        raise RuntimeProtocolError(
            f"Unpaywall DOI mismatch: expected {expected_doi}, observed {observed_doi}"
        )
    if not observation.evidence_source.strip():
        raise RuntimeProtocolError("Unpaywall lookup requires evidence_source")
    if observation.http_status != 200:
        return RouteObservation(
            request_id=request.request_id,
            route=AcquisitionRoute.UNPAYWALL,
            kind=RouteObservationKind.TRANSPORT_ERROR,
            action="unpaywall_lookup",
            evidence_source=observation.evidence_source,
            http_status=observation.http_status,
            message=observation.message or "Unpaywall lookup did not return HTTP 200",
            metadata={"lookup_metadata": observation.metadata},
        )
    if observation.title:
        expected_title = normalize_title(identity.title)
        observed_title = normalize_title(observation.title)
        if expected_title != observed_title and expected_title not in observed_title and observed_title not in expected_title:
            raise RuntimeProtocolError("Unpaywall title conflicts with resolved article identity")

    if observation.is_oa is False and not observation.locations:
        return RouteObservation(
            request_id=request.request_id,
            route=AcquisitionRoute.UNPAYWALL,
            kind=RouteObservationKind.DEFINITIVE_NO_RESULT,
            action="unpaywall_lookup",
            evidence_source=observation.evidence_source,
            http_status=observation.http_status,
            message=observation.message or "Unpaywall reports no OA location",
            metadata={
                "doi": expected_doi,
                "oa_status": observation.oa_status,
                "is_oa": False,
                "location_count": 0,
                "definitive_provider_evidence": True,
                "lookup_metadata": observation.metadata,
            },
        )

    config_doc = runtime.session.seed.metadata.get("v0_4", {}).get("acquisition_config", {})
    allow_submitted = bool(config_doc.get("allow_submitted", False))
    version_rank = {
        SourceVersion.PUBLISHED: 0,
        SourceVersion.ACCEPTED: 1,
        SourceVersion.SUBMITTED: 2,
        SourceVersion.UNKNOWN: 3,
    }
    ranked: list[tuple[tuple[int, int, int], TransportLocationObservation]] = []
    rejected: list[dict[str, Any]] = []
    for loc in observation.locations:
        version = _source_version(loc.version)
        if version == SourceVersion.SUBMITTED and not allow_submitted:
            rejected.append({"reason": "submitted_version_disallowed", "location": loc.model_dump(mode="json")})
            continue
        if loc.host_type not in {"publisher", "repository"}:
            rejected.append({"reason": "unknown_host_type", "location": loc.model_dump(mode="json")})
            continue
        url = loc.url_for_pdf
        if not url:
            rejected.append({"reason": "no_direct_pdf", "location": loc.model_dump(mode="json")})
            continue
        assert_allowed_url(url)
        selected = TransportLocationObservation(
            url=url,
            format=ArtifactFormat.PDF,
            expected_media_type="application/pdf",
            discovery_provenance={
                "method": "Unpaywall DOI API OA-location selection by Python",
                "unpaywall_api": observation.evidence_source,
                "doi": expected_doi,
                "oa_status": observation.oa_status,
                "host_type": loc.host_type,
                "version": version.value,
                "license": loc.license,
                "repository_institution": loc.repository_institution,
                "evidence": loc.evidence,
                "is_best": loc.is_best,
                "url_for_landing_page": loc.url_for_landing_page,
            },
            lawful_access_basis=(
                "Unpaywall-reported open-access location"
                + (f"; license={loc.license}" if loc.license else "")
            ),
            open_access=True,
            version=version,
            license=loc.license,
            metadata={
                "unpaywall_location": loc.model_dump(mode="json"),
                "unpaywall_lookup_metadata": observation.metadata,
            },
        )
        ranked.append(
            (
                (
                    version_rank[version],
                    0 if loc.is_best else 1,
                    0 if loc.host_type == "publisher" else 1,
                ),
                selected,
            )
        )

    ranked.sort(key=lambda pair: pair[0])
    if not ranked:
        # The provider answered authoritatively, but no full-text location is
        # admissible under this acquisition policy. That is definitive for the
        # current Unpaywall route/configuration, not a transport failure.
        return RouteObservation(
            request_id=request.request_id,
            route=AcquisitionRoute.UNPAYWALL,
            kind=RouteObservationKind.DEFINITIVE_NO_RESULT,
            action="unpaywall_lookup",
            evidence_source=observation.evidence_source,
            http_status=observation.http_status,
            message="Unpaywall returned no policy-admissible direct full-text location",
            metadata={
                "doi": expected_doi,
                "oa_status": observation.oa_status,
                "is_oa": observation.is_oa,
                "location_count": len(observation.locations),
                "rejected_locations": rejected,
                "definitive_provider_evidence": True,
            },
        )

    chosen = ranked[0][1]
    runtime._event(
        "unpaywall_location_selected_by_python",
        provider=AcquisitionRoute.UNPAYWALL.value,
        data={
            "doi": expected_doi,
            "selected_url": chosen.url,
            "selected_version": chosen.version.value,
            "candidate_count": len(ranked),
            "rejected_locations": rejected,
        },
    )
    runtime._save()
    return RouteObservation(
        request_id=request.request_id,
        route=AcquisitionRoute.UNPAYWALL,
        kind=RouteObservationKind.LOCATION_DISCOVERED,
        action="unpaywall_lookup_and_select",
        locations=[chosen],
        evidence_source=observation.evidence_source,
        http_status=observation.http_status,
        message=observation.message,
        metadata={
            "doi": expected_doi,
            "oa_status": observation.oa_status,
            "is_oa": observation.is_oa,
            "candidate_count": len(ranked),
            "selected_by": "python",
        },
    )


def _admit_route_observation(
    runtime: ChatGptVerticalSliceRuntime,
    observation: RouteObservation,
) -> bool:
    route = observation.route
    if observation.kind == RouteObservationKind.MATERIALIZED_ARTIFACT:
        if not observation.artifacts:
            raise RuntimeProtocolError("materialized_artifact observation contains no artifacts")
        admitted = 0
        for artifact in observation.artifacts:
            runtime.import_route_artifact(
                artifact.path,
                route=route,
                artifact_format=artifact.format,
                source_url=artifact.source_url,
                discovery_provenance={
                    **artifact.discovery_provenance,
                    "host_observation_request_id": observation.request_id,
                    "host_evidence_source": observation.evidence_source,
                },
                lawful_access_basis=artifact.lawful_access_basis,
                open_access=artifact.open_access,
                version=artifact.version,
                license=artifact.license,
                metadata=artifact.metadata,
            )
            admitted += 1
        runtime.record_route_attempt(
            route,
            action=observation.action,
            outcome="success",
            url=observation.artifacts[0].source_url,
            http_status=observation.http_status,
            message=observation.message,
            metadata={
                "observation_kind": observation.kind.value,
                "admitted_artifacts": admitted,
                "definitive_negative": False,
            },
        )
        return True

    if observation.kind == RouteObservationKind.DEFINITIVE_NO_RESULT:
        if not observation.evidence_source:
            raise RuntimeProtocolError(
                f"Definitive negative evidence for {route.value} requires evidence_source"
            )
        runtime.record_route_attempt(
            route,
            action=observation.action,
            outcome="miss",
            http_status=observation.http_status,
            message=observation.message,
            metadata={
                **observation.metadata,
                "observation_kind": observation.kind.value,
                "definitive_negative": True,
                "evidence_source": observation.evidence_source,
            },
        )
        return False

    outcome = "skipped" if observation.kind == RouteObservationKind.SKIPPED else "error"
    runtime.record_route_attempt(
        route,
        action=observation.action,
        outcome=outcome,
        http_status=observation.http_status,
        message=observation.message,
        metadata={
            **observation.metadata,
            "observation_kind": observation.kind.value,
            "definitive_negative": False,
            "evidence_source": observation.evidence_source,
        },
    )
    return False


def can_assign_exhausted(runtime: ChatGptVerticalSliceRuntime) -> tuple[bool, list[str]]:
    enabled = runtime.route_capabilities.enabled()
    if not enabled:
        return False, ["no enabled routes"]
    attempts = runtime._attempts()
    reasons: list[str] = []
    for route in enabled:
        route_attempts = [a for a in attempts if a.provider == route]
        if not route_attempts:
            reasons.append(f"{route}: unexecuted")
            continue
        if not any(
            a.outcome == "miss" and a.metadata.get("definitive_negative") is True
            for a in route_attempts
        ):
            kinds = [str(a.metadata.get("observation_kind") or a.outcome) for a in route_attempts]
            reasons.append(f"{route}: no definitive negative evidence ({','.join(kinds)})")
    return not reasons, reasons


def _write_non_success_manifest(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    elapsed_ms: int,
) -> Path:
    manifest_path = runtime.session.session_dir / "acquisition_manifest.json"
    terminal = (
        runtime.session.terminal_outcome.model_dump(mode="json")
        if runtime.session.terminal_outcome
        else None
    )
    document = {
        "schema_version": "3",
        "contract_version": runtime.contract_version,
        "product": "acquire_one",
        "identifier": runtime.session.identifier.model_dump(mode="json"),
        "resolved_ids": runtime.session.seed.ids.model_dump(mode="json"),
        "article_identity": runtime.session.seed.metadata.get("v0_4", {}).get("article_identity"),
        "normalized_title": runtime.session.seed.metadata.get("v0_4", {}).get("normalized_title"),
        "identity_evidence": runtime.session.seed.metadata.get("v0_4", {}).get("identity_evidence"),
        "state": runtime.session.state.value,
        "route_capabilities": runtime.session.seed.metadata.get("v0_4", {}).get("route_capabilities"),
        "provider_attempts": [x.model_dump(mode="json") for x in runtime._attempts()],
        "artifacts": [x.model_dump(mode="json") for x in runtime.session.seed.artifacts],
        "terminal_outcome": terminal,
        "run_receipt": str(runtime.receipt_path),
        "event_journal": str(runtime.events_path),
        "terminal_outcome_path": str(runtime.session.session_dir / runtime.terminal_filename),
        "runtime_elapsed_ms": elapsed_ms,
        "transport": runtime.session.seed.metadata.get("v0_4", {}).get("transport"),
    }
    manifest_path.write_text(
        json.dumps(document, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    runtime._event(
        "acquisition_manifest_written",
        data={"manifest_path": str(manifest_path), "state": runtime.session.state.value},
    )
    runtime._save()
    return manifest_path


def _transport_root(runtime: ChatGptVerticalSliceRuntime) -> Path:
    root = runtime.session.session_dir / "transport"
    (root / "requests").mkdir(parents=True, exist_ok=True)
    (root / "responses").mkdir(parents=True, exist_ok=True)
    (root / "payloads").mkdir(parents=True, exist_ok=True)
    return root


def _transport_meta(runtime: ChatGptVerticalSliceRuntime) -> dict[str, Any]:
    v04 = runtime.session.seed.metadata["v0_4"]
    current = v04.get("transport")
    if not isinstance(current, dict):
        current = {
            "contract_version": "2",
            "preference": ["native", "remote"],
            "requests": [],
            "responses": [],
            "dispatches": [],
            "pending": None,
        }
        if current_label := v04.get("transport"):
            current["legacy_transport_label"] = str(current_label)
        v04["transport"] = current
    else:
        current.setdefault("contract_version", "2")
        current.setdefault("preference", ["native", "remote"])
        current.setdefault("requests", [])
        current.setdefault("responses", [])
        current.setdefault("dispatches", [])
        current.setdefault("pending", None)
    return current


def _write_transport_request(runtime: ChatGptVerticalSliceRuntime, request: TransportRequest) -> Path:
    path = _transport_root(runtime) / "requests" / f"{request.request_id}.json"
    path.write_text(json.dumps(request.model_dump(mode="json"), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    meta = _transport_meta(runtime)
    if str(path) not in meta["requests"]:
        meta["requests"].append(str(path))
    runtime._event(
        "transport_request_emitted",
        request_id=request.request_id,
        provider=request.source_route.value,
        data={
            "correlation_id": request.correlation_id,
            "url": request.url,
            "method": request.method,
            "expected_media_type": request.expected_media_type,
            "source_route": request.source_route.value,
            "request_path": str(path),
        },
    )
    runtime._save()
    return path


def _write_transport_response(runtime: ChatGptVerticalSliceRuntime, response: TransportResponse) -> Path:
    path = _transport_root(runtime) / "responses" / f"{response.request_id}.{response.transport_name}.json"
    path.write_text(json.dumps(response.model_dump(mode="json"), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    meta = _transport_meta(runtime)
    if str(path) not in meta["responses"]:
        meta["responses"].append(str(path))
    runtime._event(
        "transport_response_received",
        request_id=response.request_id,
        data={
            "transport_name": response.transport_name,
            "transport_kind": response.transport_kind.value,
            "transport_state": response.transport_state.value,
            "status_code": response.status_code,
            "byte_count": response.byte_count,
            "transport_checksum": response.transport_checksum,
            "response_path": str(path),
        },
    )
    runtime._save()
    return path


def _transport_request_for_location(
    route: AcquisitionRoute,
    location: TransportLocationObservation,
    observation: RouteObservation,
) -> TransportRequest:
    if location.open_access is not True:
        raise RuntimeProtocolError("Python will not authorize transport for a location without open_access=true")
    if not location.lawful_access_basis.strip():
        raise RuntimeProtocolError("Python will not authorize transport without a lawful_access_basis")
    assert_allowed_url(location.url)
    return TransportRequest.build(
        url=location.url,
        source_route=route,
        headers=location.headers,
        timeout_seconds=location.timeout_seconds,
        expected_media_type=location.expected_media_type,
        max_bytes=location.max_bytes,
        provenance_context={
            "host_observation_request_id": observation.request_id,
            "host_evidence_source": observation.evidence_source,
            "discovery_provenance": location.discovery_provenance,
            "lawful_access_basis": location.lawful_access_basis,
            "open_access": True,
            "version": location.version.value,
            "license": location.license,
            "artifact_format": location.format.value,
            "location_metadata": location.metadata,
        },
    )


def _materialize_transport_payload(
    runtime: ChatGptVerticalSliceRuntime,
    request: TransportRequest,
    response: TransportResponse,
    location: TransportLocationObservation,
) -> tuple[Path, str]:
    _write_transport_response(runtime, response)
    body = response.validate_correlation(request)
    if response.status_code is None or not (200 <= response.status_code < 300):
        raise RuntimeProtocolError(f"transport returned non-success HTTP status {response.status_code}")
    header_map = {str(k).lower(): str(v) for k, v in response.headers.items()}
    content_type = header_map.get("content-type")
    if request.expected_media_type and content_type:
        actual = content_type.split(";", 1)[0].strip().lower()
        expected = request.expected_media_type.split(";", 1)[0].strip().lower()
        aliases = {"text/xml", "application/xml"}
        generic_binary = {"application/octet-stream", "binary/octet-stream"}
        if actual in generic_binary:
            # PMC's current AWS article objects are commonly served as a
            # generic binary stream. Treat that header as non-informative and
            # rely on Python's JATS/PDF validation before artifact admission.
            runtime._event(
                "transport_generic_media_type_deferred_to_content_validation",
                request_id=request.request_id,
                provider=request.source_route.value,
                data={"expected_media_type": expected, "actual_media_type": actual},
            )
            runtime._save()
        elif actual != expected and not ({actual, expected} <= aliases):
            raise RuntimeProtocolError(
                f"transport media type mismatch: expected {expected}, got {actual}"
            )
    python_sha256 = hashlib.sha256(body).hexdigest()
    suffix = ".pdf" if location.format == ArtifactFormat.PDF else ".xml"
    payload = _transport_root(runtime) / "payloads" / f"{request.request_id}{suffix}"
    payload.write_bytes(body)
    runtime._event(
        "transport_payload_verified_by_python",
        request_id=request.request_id,
        provider=request.source_route.value,
        data={
            "transport_checksum": response.transport_checksum,
            "python_sha256": python_sha256,
            "byte_count": len(body),
            "payload_path": str(payload),
            "checksums_match": python_sha256 == response.transport_checksum,
        },
    )
    runtime._save()
    return payload, python_sha256


def _admit_transport_response(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    request: TransportRequest,
    response: TransportResponse,
    location: TransportLocationObservation,
    action: str,
) -> bool:
    try:
        payload, python_sha256 = _materialize_transport_payload(runtime, request, response, location)
        artifact = runtime.import_route_artifact(
            payload,
            route=request.source_route,
            artifact_format=location.format,
            source_url=response.final_url or request.url,
            discovery_provenance={
                **location.discovery_provenance,
                "transport_request_id": request.request_id,
                "transport_correlation_id": request.correlation_id,
                "transport_name": response.transport_name,
                "transport_kind": response.transport_kind.value,
                "transport_checksum": response.transport_checksum,
                "python_transport_payload_sha256": python_sha256,
            },
            lawful_access_basis=location.lawful_access_basis,
            open_access=location.open_access,
            version=location.version,
            license=location.license,
            metadata={
                **location.metadata,
                "transport": {
                    "request_id": request.request_id,
                    "correlation_id": request.correlation_id,
                    "transport_name": response.transport_name,
                    "transport_kind": response.transport_kind.value,
                    "status_code": response.status_code,
                    "byte_count": response.byte_count,
                    "transport_checksum": response.transport_checksum,
                    "python_payload_sha256": python_sha256,
                },
            },
        )
        runtime.record_route_attempt(
            request.source_route,
            action=action,
            outcome="success",
            url=response.final_url or request.url,
            http_status=response.status_code,
            elapsed_ms=response.elapsed_ms,
            metadata={
                "observation_kind": RouteObservationKind.LOCATION_DISCOVERED.value,
                "definitive_negative": False,
                "transport_request_id": request.request_id,
                "transport_correlation_id": request.correlation_id,
                "transport_name": response.transport_name,
                "transport_kind": response.transport_kind.value,
                "transport_checksum": response.transport_checksum,
                "python_payload_sha256": python_sha256,
                "artifact_sha256": artifact.sha256,
            },
        )
        return True
    except RuntimeProtocolError as exc:
        runtime.record_route_attempt(
            request.source_route,
            action=action,
            outcome="error",
            url=request.url,
            http_status=response.status_code,
            elapsed_ms=response.elapsed_ms,
            message=str(exc),
            metadata={
                "observation_kind": RouteObservationKind.TRANSPORT_ERROR.value,
                "definitive_negative": False,
                "transport_request_id": request.request_id,
                "transport_name": response.transport_name,
                "transport_state": response.transport_state.value,
            },
        )
        return False


def _set_pending_transport(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    route_index: int,
    location_index: int,
    request: TransportRequest,
    location: TransportLocationObservation,
    observation: RouteObservation,
    dispatch_attempts: list[dict[str, Any]],
    deferred_transport: str,
) -> None:
    meta = _transport_meta(runtime)
    meta["pending"] = {
        "route_index": route_index,
        "location_index": location_index,
        "request": request.model_dump(mode="json"),
        "location": location.model_dump(mode="json"),
        "observation": observation.model_dump(mode="json"),
        "dispatch_attempts": dispatch_attempts,
        "deferred_transport": deferred_transport,
    }
    runtime.session.state = RuntimeState.NEEDS_FETCH
    runtime._event(
        "transport_suspended",
        request_id=request.request_id,
        provider=request.source_route.value,
        data={
            "correlation_id": request.correlation_id,
            "deferred_transport": deferred_transport,
            "dispatch_attempts": dispatch_attempts,
        },
    )
    runtime._save()


def _pending_transport(runtime: ChatGptVerticalSliceRuntime) -> dict[str, Any] | None:
    return _transport_meta(runtime).get("pending")


def _clear_pending_transport(runtime: ChatGptVerticalSliceRuntime) -> None:
    _transport_meta(runtime)["pending"] = None
    runtime.session.state = RuntimeState.READY
    runtime._save()


def _transport_evidence_paths(runtime: ChatGptVerticalSliceRuntime) -> list[Path]:
    meta = _transport_meta(runtime)
    return [Path(x) for x in [*meta.get("requests", []), *meta.get("responses", [])]]


def _execution(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    started: float,
    step=None,
    elapsed_ms: int | None = None,
) -> AcquisitionExecution:
    elapsed = elapsed_ms if elapsed_ms is not None else max(0, round((time.perf_counter() - started) * 1000))
    if step is None:
        step = runtime.step() if runtime.session.state != RuntimeState.NEEDS_FETCH else None
    state = runtime.session.state if step is None else step.state
    result = None if step is None else step.result
    terminal = runtime.session.terminal_outcome if step is None else step.terminal_outcome
    manifest_path = result.manifest_path if result else None
    if state not in {RuntimeState.NEEDS_FETCH, RuntimeState.READY} and manifest_path is None:
        manifest_path = _write_non_success_manifest(runtime, elapsed_ms=elapsed)
    pending = _pending_transport(runtime)
    return AcquisitionExecution(
        pmid=runtime.session.identifier.value,
        state=state,
        elapsed_ms=elapsed,
        session_path=runtime.session_path,
        run_receipt=runtime.receipt_path,
        event_journal=runtime.events_path,
        manifest_path=manifest_path,
        result=result,
        terminal_outcome=terminal,
        pending_transport_request=(pending or {}).get("request"),
        transport_evidence=_transport_evidence_paths(runtime),
        metrics={"runtime_elapsed_ms": elapsed},
    )


def _payload_requirements(runtime: ChatGptVerticalSliceRuntime, config: AcquisitionConfig) -> tuple[bool, list[str]]:
    formats = {artifact.format for artifact in runtime.session.seed.artifacts}
    missing: list[str] = []
    if config.want_structured and ArtifactFormat.JATS_XML not in formats:
        missing.append(ArtifactFormat.JATS_XML.value)
    if config.want_pdf and ArtifactFormat.PDF not in formats:
        missing.append(ArtifactFormat.PDF.value)
    return not missing, missing


def _continue_location_sequence(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    config: AcquisitionConfig,
    transports: TransportRegistry,
    started: float,
    route_index: int,
    observation: RouteObservation,
    start_location_index: int = 0,
) -> AcquisitionExecution | None:
    """Execute all authorized locations for one route observation.

    Prompt 3 requires a PMC run requesting both structured text and PDF to
    retain both. Therefore a first valid payload is not automatically a
    terminal success when the acquisition configuration still requires a
    second format.
    """

    route = observation.route
    if not observation.locations:
        raise RuntimeProtocolError("location_discovered observation contains no locations")
    for location_index in range(start_location_index, len(observation.locations)):
        location = observation.locations[location_index]
        request = _transport_request_for_location(route, location, observation)
        _write_transport_request(runtime, request)
        dispatch = transports.dispatch(request)
        _transport_meta(runtime)["dispatches"].append(dispatch.model_dump(mode="json"))
        runtime._event(
            "transport_dispatch_completed",
            request_id=request.request_id,
            provider=route.value,
            data={
                "location_index": location_index,
                "location_count": len(observation.locations),
                "attempts": dispatch.attempts,
                "deferred_transport": dispatch.deferred_transport,
                "has_response": dispatch.response is not None,
            },
        )
        runtime._save()
        if dispatch.response is not None:
            if _admit_transport_response(
                runtime,
                request=request,
                response=dispatch.response,
                location=location,
                action=observation.action,
            ):
                satisfied, missing = _payload_requirements(runtime, config)
                runtime._event(
                    "payload_coverage_evaluated",
                    provider=route.value,
                    data={"satisfied": satisfied, "missing_formats": missing},
                )
                runtime._save()
                if satisfied:
                    step = runtime.step()
                    if step.state == RuntimeState.SUCCESS:
                        return _execution(runtime, started=started, step=step)
            continue
        if dispatch.deferred_transport:
            _set_pending_transport(
                runtime,
                route_index=route_index,
                location_index=location_index,
                request=request,
                location=location,
                observation=observation,
                dispatch_attempts=dispatch.attempts,
                deferred_transport=dispatch.deferred_transport,
            )
            return _execution(runtime, started=started)
        runtime.record_route_attempt(
            route,
            action=observation.action,
            outcome="error",
            url=location.url,
            message="No configured transport produced materialized bytes",
            metadata={
                "observation_kind": RouteObservationKind.RESPONSE_NOT_MATERIALIZABLE.value,
                "definitive_negative": False,
                "transport_attempts": dispatch.attempts,
            },
        )

    satisfied, _ = _payload_requirements(runtime, config)
    if satisfied:
        step = runtime.step()
        if step.state == RuntimeState.SUCCESS:
            return _execution(runtime, started=started, step=step)
    return None


def _continue_controller(
    runtime: ChatGptVerticalSliceRuntime,
    *,
    config: AcquisitionConfig,
    host: HostAdapter,
    transports: TransportRegistry,
    started: float,
    start_route_index: int,
) -> AcquisitionExecution:
    ident = runtime.session.identifier
    identity_doc = runtime.session.seed.metadata.get("v0_4", {}).get("article_identity")
    if not identity_doc:
        raise RuntimeProtocolError("controller resume requires resolved article identity")
    identity = ArticleIdentity.model_validate(identity_doc)
    routes = config.route_capabilities.enabled_routes()
    for route_index in range(start_route_index, len(routes)):
        route = routes[route_index]
        observation = _observe_route(runtime, ident, identity, route, host)
        runtime.session.seed.metadata["v0_4"]["controller_next_route_index"] = route_index + 1
        if observation.kind == RouteObservationKind.LOCATION_DISCOVERED:
            execution = _continue_location_sequence(
                runtime,
                config=config,
                transports=transports,
                started=started,
                route_index=route_index,
                observation=observation,
            )
            if execution is not None:
                return execution
            continue

        if _admit_route_observation(runtime, observation):
            satisfied, _ = _payload_requirements(runtime, config)
            if satisfied:
                step = runtime.step()
                if step.state == RuntimeState.SUCCESS:
                    return _execution(runtime, started=started, step=step)

    if runtime.session.state == RuntimeState.READY:
        satisfied, missing = _payload_requirements(runtime, config)
        if satisfied:
            return _execution(runtime, started=started, step=runtime.step())
        exhaustive, reasons = can_assign_exhausted(runtime)
        if exhaustive and not runtime.session.seed.artifacts:
            runtime.mark_exhausted("Every enabled route returned definitive negative evidence")
        else:
            coverage = (
                "requested payload coverage missing: " + ", ".join(missing) + "; "
                if missing
                else ""
            )
            runtime.mark_blocked(
                "Acquisition coverage is incomplete or uncertain: "
                + coverage
                + "; ".join(reasons),
                reason_code=RuntimeFailureCode.EXTERNAL_FETCH_BLOCKED,
            )
    step = runtime.step()
    return _execution(runtime, started=started, step=step)


def acquire_one(
    identifier: str | ArticleIdentifier,
    config: AcquisitionConfig,
    root: Path,
    host: HostAdapter,
    transports: TransportRegistry | None = None,
) -> AcquisitionExecution:
    """Production v0.4.3 acquisition entry point with replaceable transport.

    Python owns identity, route policy, transport authorization, response
    interpretation, scholarly validation, hashing, and terminal state. A remote
    transport may intentionally defer execution; the returned NEEDS_FETCH run is
    resumed with :func:`resume_acquire_one` and a correlated TransportResponse.
    """

    started = time.perf_counter()
    ident = identifier if isinstance(identifier, ArticleIdentifier) else ArticleIdentifier.parse(identifier)
    if ident.kind != IdentifierKind.PMID:
        raise RuntimeProtocolError("v0.4.3 production controller currently requires PMID input")
    registry = transports or TransportRegistry()
    runtime = ChatGptVerticalSliceRuntime.create(
        ident,
        root,
        route_capabilities=config.route_capabilities,
    )
    runtime.session.policy.want_structured = config.want_structured
    runtime.session.policy.want_pdf = config.want_pdf
    runtime.session.seed.metadata["v0_4"]["product"] = "acquire_one"
    runtime.session.seed.metadata["v0_4"]["route_capabilities"] = config.route_capabilities.model_dump(mode="json")
    runtime.session.seed.metadata["v0_4"]["acquisition_config"] = config.model_dump(mode="json")
    runtime.session.seed.metadata["v0_4"]["transport_registry"] = registry.describe()
    _transport_meta(runtime)
    runtime._event(
        "production_acquire_one_started",
        data={
            "identifier": ident.model_dump(mode="json"),
            "route_capabilities": config.route_capabilities.model_dump(mode="json"),
            "transport_registry": registry.describe(),
        },
    )
    runtime._save()

    try:
        _resolve_identity(runtime, ident, host)
        runtime.session.seed.metadata["v0_4"]["controller_next_route_index"] = 0
        runtime._save()
        return _continue_controller(
            runtime,
            config=config,
            host=host,
            transports=registry,
            started=started,
            start_route_index=0,
        )
    except RuntimeProtocolError as exc:
        text = str(exc)
        code = RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR
        if text.startswith("IDENTITY_MISMATCH"):
            code = RuntimeFailureCode.IDENTITY_MISMATCH
        elif text.startswith("IDENTITY_UNVERIFIED"):
            code = RuntimeFailureCode.IDENTITY_UNVERIFIED
        runtime.mark_failed(text, reason_code=code)
        return _execution(runtime, started=started, step=runtime.step())
    except Exception as exc:
        runtime.mark_blocked(
            f"Host/transport execution failed: {type(exc).__name__}: {exc}",
            reason_code=RuntimeFailureCode.TOOL_FAILURE,
        )
        return _execution(runtime, started=started, step=runtime.step())


def resume_acquire_one(
    session_path: Path,
    host: HostAdapter,
    transports: TransportRegistry | None = None,
    response: TransportResponse | Mapping[str, Any] | None = None,
) -> AcquisitionExecution:
    """Resume the production controller from a serialized transport suspension."""

    started = time.perf_counter()
    runtime = ChatGptVerticalSliceRuntime.load(session_path)
    pending = _pending_transport(runtime)
    if not pending:
        raise RuntimeProtocolError("acquire_one session has no pending transport request")
    request = TransportRequest.model_validate(pending["request"])
    location = TransportLocationObservation.model_validate(pending["location"])
    observation = RouteObservation.model_validate(pending["observation"])
    config = AcquisitionConfig.model_validate(runtime.session.seed.metadata["v0_4"]["acquisition_config"])
    registry = transports or TransportRegistry()

    if response is None:
        dispatch = registry.dispatch(request)
        _transport_meta(runtime)["dispatches"].append(dispatch.model_dump(mode="json"))
        if dispatch.response is None:
            if dispatch.deferred_transport:
                runtime._event(
                    "transport_remains_suspended",
                    request_id=request.request_id,
                    provider=request.source_route.value,
                    data={"deferred_transport": dispatch.deferred_transport, "attempts": dispatch.attempts},
                )
                runtime._save()
                return _execution(runtime, started=started)
            runtime.record_route_attempt(
                request.source_route,
                action=observation.action,
                outcome="error",
                url=request.url,
                message="All configured transports failed to materialize the pending request",
                metadata={
                    "observation_kind": RouteObservationKind.TRANSPORT_ERROR.value,
                    "definitive_negative": False,
                    "transport_attempts": dispatch.attempts,
                },
            )
            _clear_pending_transport(runtime)
        else:
            response = dispatch.response

    if response is not None:
        response_obj = response if isinstance(response, TransportResponse) else TransportResponse.model_validate(response)
        admitted = _admit_transport_response(
            runtime,
            request=request,
            response=response_obj,
            location=location,
            action=observation.action,
        )
        _clear_pending_transport(runtime)
        runtime._event(
            "transport_resumed",
            request_id=request.request_id,
            provider=request.source_route.value,
            data={"admitted": admitted, "transport_name": response_obj.transport_name},
        )
        runtime._save()
        if admitted:
            satisfied, _ = _payload_requirements(runtime, config)
            if satisfied:
                step = runtime.step()
                if step.state == RuntimeState.SUCCESS:
                    return _execution(runtime, started=started, step=step)

    # A deferred response can be only one member of a multi-location route
    # observation (notably PMC JATS + PDF). Continue the unexecuted locations
    # before advancing to the next provider route.
    location_index = int(pending.get("location_index", 0))
    next_location = location_index + 1
    if next_location < len(observation.locations):
        execution = _continue_location_sequence(
            runtime,
            config=config,
            transports=registry,
            started=started,
            route_index=int(pending["route_index"]),
            observation=observation,
            start_location_index=next_location,
        )
        if execution is not None:
            return execution

    next_index = int(pending["route_index"]) + 1
    return _continue_controller(
        runtime,
        config=config,
        host=host,
        transports=registry,
        started=started,
        start_route_index=next_index,
    )
