from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Literal, Mapping

from pydantic import BaseModel, Field

from .errors import ContentValidationError, RuntimeProtocolError
from .capabilities import AcquisitionRoute, CapabilityStatus, ROUTE_ORDER, RouteCapabilityRegistry
from .integration import build_atom_sea_handoff
from .identity import ArticleIdentity, verify_identity
from .models import (
    AcquisitionPolicy,
    AcquisitionResult,
    ArticleIdentifier,
    Artifact,
    ArtifactFormat,
    Attempt,
    IdentifierKind,
    ResolvedIds,
    RuntimeFailureCode,
    RuntimeState,
    RuntimeStep,
    RuntimeTerminalOutcome,
    SourceVersion,
)
from .runtime import ChatGptAcquisitionRuntime
from .utils import assert_allowed_url, extract_jats_article, link_or_copy, validate_pdf


class RouteFlags(BaseModel):
    """Replay-only compatibility input from v0.4.2."""

    pmc: bool = True
    publisher_oa: bool = True
    unpaywall: bool = True
    repository: bool = True

    def enabled(self) -> list[str]:
        return [r.value for r in ROUTE_ORDER if bool(getattr(self, r.value))]

    def to_capabilities(self) -> RouteCapabilityRegistry:
        return RouteCapabilityRegistry(**{
            route.value: CapabilityStatus.EXPERIMENTAL if bool(getattr(self, route.value)) else CapabilityStatus.DISABLED
            for route in ROUTE_ORDER
        })


class RouteAttemptInput(BaseModel):
    route: AcquisitionRoute
    action: str
    outcome: Literal["success", "miss", "error", "skipped", "cached"]
    url: str | None = None
    http_status: int | None = None
    message: str | None = None
    elapsed_ms: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class MaterializedArtifactInput(BaseModel):
    path: Path
    route: AcquisitionRoute
    format: ArtifactFormat
    source_url: str
    discovery_provenance: dict[str, Any]
    lawful_access_basis: str
    open_access: bool = True
    version: SourceVersion = SourceVersion.UNKNOWN
    license: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AcquisitionReplaySpec(BaseModel):
    pmid: str
    identity: ArticleIdentity | None = None
    resolved_ids: ResolvedIds = Field(default_factory=ResolvedIds)
    route_flags: RouteFlags = Field(default_factory=RouteFlags)
    attempts: list[RouteAttemptInput] = Field(default_factory=list)
    artifacts: list[MaterializedArtifactInput] = Field(default_factory=list)
    terminal_state: Literal["blocked", "exhausted", "failed"] | None = None
    terminal_message: str | None = None
    terminal_reason_code: RuntimeFailureCode = RuntimeFailureCode.UNKNOWN
    metrics: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class AcquisitionExecution(BaseModel):
    pmid: str
    state: RuntimeState
    elapsed_ms: int
    session_path: Path
    run_receipt: Path
    event_journal: Path
    manifest_path: Path | None = None
    result: AcquisitionResult | None = None
    terminal_outcome: RuntimeTerminalOutcome | None = None
    pending_transport_request: dict[str, Any] | None = None
    transport_evidence: list[Path] = Field(default_factory=list)
    metrics: dict[str, Any] = Field(default_factory=dict)


class ChatGptVerticalSliceRuntime(ChatGptAcquisitionRuntime):
    """v0.4 acquire_one runtime.

    ChatGPT/tooling performs discovery and byte transport. Python remains the
    acquisition brain: identity binding, route policy, OA/lawful-access checks,
    validation, hashing, terminal semantics, manifests, provenance, and
    ATOM/SEA handoff.
    """

    contract_version = "0.4.3"
    provider_name = "chatgpt_native_transport"

    @classmethod
    def create(
        cls,
        identifier: str | ArticleIdentifier,
        root: Path,
        *,
        route_capabilities: RouteCapabilityRegistry | None = None,
        route_flags: RouteFlags | None = None,
        output_dir: Path | None = None,
        cache_dir: Path | None = None,
        settings=None,
    ) -> "ChatGptVerticalSliceRuntime":
        ident = identifier if isinstance(identifier, ArticleIdentifier) else ArticleIdentifier.parse(identifier)
        if ident.kind != IdentifierKind.PMID:
            raise RuntimeProtocolError("v0.4 acquire_one requires a PMID")
        runtime = super().create(
            ident,
            root,
            output_dir=output_dir,
            cache_dir=cache_dir,
            policy=AcquisitionPolicy(want_structured=True, want_pdf=True, max_retries=0),
            settings=settings,
            providers=[],
        )
        runtime.session.seed.ids.pmid = ident.value
        capabilities = route_capabilities or (route_flags.to_capabilities() if route_flags else RouteCapabilityRegistry())
        runtime.session.seed.metadata["v0_4"] = {
            "contract_version": cls.contract_version,
            "product": "acquire_one",
            "requested_pmid": ident.value,
            "network_in_python": False,
            "transport": "chatgpt_native",
            "route_capabilities": capabilities.model_dump(mode="json"),
            "enabled_routes": capabilities.enabled(),
            "attempts": [],
        }
        runtime._event("v0_4_runtime_initialized", data={"requested_pmid": ident.value, "route_capabilities": capabilities.model_dump(mode="json"), "enabled_routes": capabilities.enabled()})
        runtime._save()
        return runtime

    @property
    def route_capabilities(self) -> RouteCapabilityRegistry:
        return RouteCapabilityRegistry.model_validate(self.session.seed.metadata["v0_4"]["route_capabilities"])

    @property
    def route_flags(self) -> RouteFlags:
        """Compatibility view for replay code. Production policy uses route_capabilities."""
        enabled = set(self.route_capabilities.enabled())
        return RouteFlags(**{route.value: route.value in enabled for route in ROUTE_ORDER})

    def add_resolved_ids(self, *, pmid=None, doi=None, pmcid=None, versioned_pmcid=None) -> ResolvedIds:
        requested = self.session.identifier.value
        if pmid is not None and str(pmid) != requested:
            raise RuntimeProtocolError(f"Resolved PMID {pmid} conflicts with requested PMID {requested}")
        return super().add_resolved_ids(pmid=requested, doi=doi, pmcid=pmcid, versioned_pmcid=versioned_pmcid)

    def record_route_attempt(
        self,
        route: AcquisitionRoute | str,
        *,
        action: str,
        outcome: Literal["success", "miss", "error", "skipped", "cached"],
        url: str | None = None,
        http_status: int | None = None,
        message: str | None = None,
        elapsed_ms: int | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> Attempt:
        route = AcquisitionRoute(route)
        if route.value not in self.route_capabilities.enabled():
            raise RuntimeProtocolError(f"Route {route.value} is disabled for this acquire_one run")
        if url:
            assert_allowed_url(url)
        attempt = Attempt(
            provider=route.value,
            action=action,
            url=url,
            outcome=outcome,
            http_status=http_status,
            message=message,
            elapsed_ms=elapsed_ms,
            metadata=dict(metadata or {}),
        )
        self.session.seed.metadata["v0_4"]["attempts"].append(attempt.model_dump(mode="json"))
        self._event("route_attempt", provider=route.value, data=attempt.model_dump(mode="json"))
        self._save()
        return attempt

    def import_route_artifact(
        self,
        path: Path,
        *,
        route: AcquisitionRoute | str,
        artifact_format: ArtifactFormat | str,
        source_url: str,
        discovery_provenance: Mapping[str, Any],
        lawful_access_basis: str,
        open_access: bool,
        version: SourceVersion | str = SourceVersion.UNKNOWN,
        license: str | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> Artifact:
        route = AcquisitionRoute(route)
        fmt = ArtifactFormat(artifact_format)
        if route.value not in self.route_capabilities.enabled():
            raise RuntimeProtocolError(f"Route {route.value} is disabled for this acquire_one run")
        if fmt not in {ArtifactFormat.JATS_XML, ArtifactFormat.PDF}:
            raise RuntimeProtocolError("v0.4 full-text acceptance supports JATS XML and PDF payloads")
        if not source_url:
            raise RuntimeProtocolError("source_url is required")
        assert_allowed_url(source_url)
        if not discovery_provenance:
            raise RuntimeProtocolError("discovery_provenance is required")
        if open_access is not True:
            raise RuntimeProtocolError("artifact admission requires open_access=true")
        if not lawful_access_basis or not lawful_access_basis.strip():
            raise RuntimeProtocolError("lawful_access_basis is required")

        identity = self.session.seed.metadata.get("v0_4", {}).get("article_identity")
        if not identity:
            raise RuntimeProtocolError("trusted article identity must be set before artifact admission")
        expected_identity = ArticleIdentity.model_validate(identity)
        identity_decision = verify_identity(path, fmt, expected_identity)
        identity_path = self.session.session_dir / f"identity_verification_{fmt.value}.json"
        identity_path.write_text(json.dumps(identity_decision.model_dump(mode="json"), indent=2) + "\n", encoding="utf-8")
        self._event("artifact_identity_verified", provider=route.value, data={"format": fmt.value, **identity_decision.model_dump(mode="json"), "report": str(identity_path)})
        if identity_decision.decision == "mismatch":
            raise RuntimeProtocolError("IDENTITY_MISMATCH: " + "; ".join(identity_decision.conflicts))
        if identity_decision.decision != "match":
            raise RuntimeProtocolError("IDENTITY_UNVERIFIED: artifact lacks sufficient exact identity evidence")

        binding = {
            "contract_version": self.contract_version,
            "requested_pmid": self.session.identifier.value,
            "route": route.value,
            "source_url": source_url,
            "discovery_provenance": dict(discovery_provenance),
            "lawful_access_basis": lawful_access_basis,
            "open_access": True,
            "identity_decision": identity_decision.model_dump(mode="json"),
            "identity_report": str(identity_path),
            **dict(metadata or {}),
        }
        artifact = super().import_artifact(
            path,
            source_url=source_url,
            provider=route.value,
            artifact_format=fmt,
            version=version,
            license=license,
            structured=(fmt == ArtifactFormat.JATS_XML),
            metadata={"v0_4": binding},
        )
        self._event(
            "payload_admitted",
            provider=route.value,
            data={"format": fmt.value, "sha256": artifact.sha256, "size_bytes": artifact.size_bytes, "source_url": source_url},
        )
        self._save()
        return artifact

    def mark_blocked(self, message: str, *, reason_code: RuntimeFailureCode = RuntimeFailureCode.EXTERNAL_FETCH_BLOCKED) -> RuntimeTerminalOutcome:
        return self._terminal(RuntimeState.BLOCKED, message, reason_code, exhausted=False)

    def mark_failed(self, message: str, *, reason_code: RuntimeFailureCode = RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR) -> RuntimeTerminalOutcome:
        return self._terminal(RuntimeState.FAILED, message, reason_code, exhausted=False)

    def mark_exhausted(self, message: str = "All enabled lawful acquisition routes exhausted") -> RuntimeTerminalOutcome:
        if self.session.seed.artifacts:
            raise RuntimeProtocolError("Cannot mark EXHAUSTED after a full-text artifact was admitted")
        enabled = self.route_capabilities.enabled()
        if not enabled:
            raise RuntimeProtocolError("Cannot confirm EXHAUSTED with no enabled routes")
        problems: list[str] = []
        for route in enabled:
            route_attempts = [a for a in self._attempts() if a.provider == route]
            if not route_attempts:
                problems.append(f"{route}: unexecuted")
                continue
            definitive = any(
                a.outcome == "miss" and a.metadata.get("definitive_negative") is True
                for a in route_attempts
            )
            if not definitive:
                observed = ",".join(str(a.metadata.get("observation_kind") or a.outcome) for a in route_attempts)
                problems.append(f"{route}: no definitive negative evidence ({observed})")
        if problems:
            raise RuntimeProtocolError("Cannot confirm EXHAUSTED; " + "; ".join(problems))
        return self._terminal(RuntimeState.EXHAUSTED, message, RuntimeFailureCode.PROVIDER_EXHAUSTED, exhausted=True)

    def step(self) -> RuntimeStep:
        if self.session.state == RuntimeState.SUCCESS and self.session.result_manifest:
            result = self._load_result()
            return RuntimeStep(state=RuntimeState.SUCCESS, session_path=self.session_path, result=result, terminal_outcome=self.session.terminal_outcome)
        if self.session.state in {RuntimeState.BLOCKED, RuntimeState.EXHAUSTED, RuntimeState.FAILED}:
            return RuntimeStep(state=self.session.state, session_path=self.session_path, terminal_outcome=self.session.terminal_outcome, message=self.session.terminal_outcome.message if self.session.terminal_outcome else None)
        if not self.session.seed.artifacts:
            self._event("awaiting_host_evidence_or_payload", data={"enabled_routes": self.route_capabilities.enabled()})
            self._save()
            return RuntimeStep(state=RuntimeState.READY, session_path=self.session_path, message="Awaiting route evidence and/or tool-materialized lawful full text")

        try:
            artifacts = self._validated_artifacts()
            result = self._finalize_success(artifacts)
        except Exception as exc:
            code = RuntimeFailureCode.INVALID_RESPONSE if isinstance(exc, ContentValidationError) else RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR
            outcome = self.mark_failed(f"{type(exc).__name__}: {exc}", reason_code=code)
            return RuntimeStep(state=RuntimeState.FAILED, session_path=self.session_path, terminal_outcome=outcome, message=outcome.message)

        outcome = self._terminal(
            RuntimeState.SUCCESS,
            "Validated lawful full text acquired",
            None,
            exhausted=False,
            artifact_sha256=[a.sha256 for a in result.artifacts],
        )
        self.session.result_manifest = result.manifest_path
        self._save()
        return RuntimeStep(state=RuntimeState.SUCCESS, session_path=self.session_path, result=result, terminal_outcome=outcome, message=outcome.message)

    def _attempts(self) -> list[Attempt]:
        return [Attempt.model_validate(x) for x in self.session.seed.metadata.get("v0_4", {}).get("attempts", [])]

    def _validated_artifacts(self) -> list[Artifact]:
        requested = self.session.identifier.value
        if self.session.seed.ids.pmid and self.session.seed.ids.pmid != requested:
            raise RuntimeProtocolError("resolved PMID does not match requested PMID")
        out: list[Artifact] = []
        for artifact in self.session.seed.artifacts:
            binding = artifact.metadata.get("v0_4")
            if not isinstance(binding, dict) or binding.get("requested_pmid") != requested:
                raise RuntimeProtocolError("artifact lacks exact requested-PMID binding")
            if binding.get("open_access") is not True or not binding.get("lawful_access_basis"):
                raise RuntimeProtocolError("artifact lacks lawful OA provenance")
            if binding.get("route") != artifact.provider:
                raise RuntimeProtocolError("artifact route/provenance mismatch")
            body = artifact.local_path.read_bytes()
            if artifact.format == ArtifactFormat.PDF:
                validate_pdf(body)
            elif artifact.format == ArtifactFormat.JATS_XML:
                normalized = extract_jats_article(body)
                if normalized != body:
                    raise ContentValidationError("stored JATS payload differs from normalized article bytes")
            else:
                raise RuntimeProtocolError("unsupported artifact format in v0.4 result")
            digest = hashlib.sha256(body).hexdigest()
            if digest != artifact.sha256:
                raise ContentValidationError(f"SHA-256 mismatch for {artifact.format.value}")
            out.append(artifact)
        return out

    def _finalize_success(self, artifacts: list[Artifact]) -> AcquisitionResult:
        requested = self.session.identifier.value
        resolved = self.session.seed.ids.model_copy(deep=True)
        resolved.pmid = requested
        workdir = self.session.output_dir / requested
        workdir.mkdir(parents=True, exist_ok=True)

        # Prefer one JATS and one PDF, but preserve every distinct admitted payload.
        ordered = sorted(artifacts, key=lambda a: (0 if a.format == ArtifactFormat.JATS_XML else 1, a.provider, a.sha256))
        materialized: list[Artifact] = []
        seen_fmt: dict[ArtifactFormat, int] = {}
        for artifact in ordered:
            seen_fmt[artifact.format] = seen_fmt.get(artifact.format, 0) + 1
            n = seen_fmt[artifact.format]
            if artifact.format == ArtifactFormat.JATS_XML:
                name = "article.xml" if n == 1 else f"article.{n}.xml"
            else:
                name = "article.pdf" if n == 1 else f"article.{n}.pdf"
            dest = workdir / name
            if artifact.local_path.resolve() != dest.resolve():
                link_or_copy(artifact.local_path, dest)
            copy = artifact.model_copy(deep=True)
            copy.local_path = dest
            materialized.append(copy)

        attempts = self._attempts()
        result = AcquisitionResult(
            identifier=self.session.identifier,
            resolved_ids=resolved,
            artifacts=materialized,
            attempts=attempts,
            metadata={
                "v0_4": {
                    **self.session.seed.metadata["v0_4"],
                    "run_receipt": str(self.receipt_path),
                    "event_journal": str(self.events_path),
                    "preferred_payload": "article.xml" if any(a.format == ArtifactFormat.JATS_XML for a in materialized) else "article.pdf",
                    "secondary_payload": "article.pdf" if any(a.format == ArtifactFormat.JATS_XML for a in materialized) and any(a.format == ArtifactFormat.PDF for a in materialized) else None,
                }
            },
        )
        manifest = workdir / "manifest.json"
        result.manifest_path = manifest
        result.handoff = build_atom_sea_handoff(result, manifest)
        manifest.write_text(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        self._event("manifest_written", data={"manifest_path": str(manifest), "artifact_sha256": [a.sha256 for a in materialized], "handoff": result.handoff.model_dump(mode="json")})
        return result

    def _terminal(
        self,
        state: RuntimeState,
        message: str,
        reason_code: RuntimeFailureCode | None,
        *,
        exhausted: bool,
        artifact_sha256: list[str] | None = None,
    ) -> RuntimeTerminalOutcome:
        outcome = RuntimeTerminalOutcome(
            state=state,
            reason_code=reason_code,
            message=message,
            provider_policy=self.route_capabilities.enabled(),
            provider_attempts=self._attempts(),
            provider_exhaustion_confirmed=exhausted,
            artifact_sha256=artifact_sha256 or [a.sha256 for a in self.session.seed.artifacts],
        )
        self.session.state = state
        self.session.terminal_outcome = outcome
        self.session.error = message if state == RuntimeState.FAILED else None
        self._event(f"terminal_{state.value}", data=outcome.model_dump(mode="json"))
        (self.session.session_dir / self.terminal_filename).write_text(json.dumps(outcome.model_dump(mode="json"), indent=2) + "\n", encoding="utf-8")
        self._save()
        return outcome

    def _provider_policy(self) -> list[str]:
        return self.route_capabilities.enabled()


def replay_acquisition(spec: AcquisitionReplaySpec | Mapping[str, Any], root: Path) -> AcquisitionExecution:
    """Replay prepared evidence. This is not the production acquisition API."""
    spec = spec if isinstance(spec, AcquisitionReplaySpec) else AcquisitionReplaySpec.model_validate(spec)
    started = time.perf_counter()
    runtime = ChatGptVerticalSliceRuntime.create(spec.pmid, root, route_flags=spec.route_flags)
    ids = spec.resolved_ids
    if spec.identity is None:
        raise RuntimeProtocolError("AcquisitionReplaySpec.identity is required for fail-closed artifact admission")
    if spec.identity.pmid != spec.pmid:
        raise RuntimeProtocolError("AcquisitionReplaySpec identity PMID conflicts with requested PMID")
    runtime.session.seed.metadata["v0_4"]["article_identity"] = spec.identity.model_dump(mode="json")
    runtime.add_resolved_ids(pmid=spec.pmid, doi=ids.doi, pmcid=ids.pmcid, versioned_pmcid=ids.versioned_pmcid)
    runtime.session.seed.metadata["v0_4"]["regression_metadata"] = {**spec.metadata, **spec.metrics}
    runtime._save()

    try:
        for a in spec.attempts:
            runtime.record_route_attempt(
                a.route, action=a.action, outcome=a.outcome, url=a.url, http_status=a.http_status,
                message=a.message, elapsed_ms=a.elapsed_ms, metadata=a.metadata,
            )
        for a in spec.artifacts:
            runtime.import_route_artifact(
                a.path, route=a.route, artifact_format=a.format, source_url=a.source_url,
                discovery_provenance=a.discovery_provenance,
                lawful_access_basis=a.lawful_access_basis, open_access=a.open_access,
                version=a.version, license=a.license, metadata=a.metadata,
            )
    except RuntimeProtocolError as exc:
        text = str(exc)
        if text.startswith("IDENTITY_MISMATCH"):
            runtime.mark_failed(text, reason_code=RuntimeFailureCode.IDENTITY_MISMATCH)
        elif text.startswith("IDENTITY_UNVERIFIED"):
            runtime.mark_failed(text, reason_code=RuntimeFailureCode.IDENTITY_UNVERIFIED)
        else:
            runtime.mark_failed(text, reason_code=RuntimeFailureCode.RUNTIME_PROTOCOL_ERROR)

    if runtime.session.state == RuntimeState.READY:
        if spec.terminal_state == "blocked":
            runtime.mark_blocked(spec.terminal_message or "Host transport blocked", reason_code=spec.terminal_reason_code)
        elif spec.terminal_state == "exhausted":
            runtime.mark_exhausted(spec.terminal_message or "All enabled lawful acquisition routes exhausted")
        elif spec.terminal_state == "failed":
            runtime.mark_failed(spec.terminal_message or "Acquisition failed", reason_code=spec.terminal_reason_code)

    step = runtime.step()
    elapsed_ms = max(0, round((time.perf_counter() - started) * 1000))
    manifest_path = step.result.manifest_path if step.result else None
    if manifest_path is None:
        manifest_path = runtime.session.session_dir / "acquisition_manifest.json"
        terminal = step.terminal_outcome.model_dump(mode="json") if step.terminal_outcome else None
        run_manifest = {
            "schema_version": "2",
            "contract_version": runtime.contract_version,
            "identifier": runtime.session.identifier.model_dump(mode="json"),
            "resolved_ids": runtime.session.seed.ids.model_dump(mode="json"),
            "article_identity": runtime.session.seed.metadata.get("v0_4", {}).get("article_identity"),
            "state": step.state.value,
            "route_flags": runtime.route_flags.model_dump(),
            "provider_attempts": [x.model_dump(mode="json") for x in runtime._attempts()],
            "artifacts": [x.model_dump(mode="json") for x in runtime.session.seed.artifacts],
            "terminal_outcome": terminal,
            "run_receipt": str(runtime.receipt_path),
            "event_journal": str(runtime.events_path),
            "terminal_outcome_path": str(runtime.session.session_dir / runtime.terminal_filename),
            "metrics": {**spec.metrics, "runtime_elapsed_ms": elapsed_ms},
        }
        manifest_path.write_text(json.dumps(run_manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        runtime._event("acquisition_manifest_written", data={"manifest_path": str(manifest_path), "state": step.state.value})
        runtime._save()
    return AcquisitionExecution(
        pmid=spec.pmid,
        state=step.state,
        elapsed_ms=elapsed_ms,
        session_path=runtime.session_path,
        run_receipt=runtime.receipt_path,
        event_journal=runtime.events_path,
        manifest_path=manifest_path,
        result=step.result,
        terminal_outcome=step.terminal_outcome,
        metrics={**spec.metrics, "runtime_elapsed_ms": elapsed_ms},
    )
