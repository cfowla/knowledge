from __future__ import annotations

from datetime import date
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class AcquisitionRoute(str, Enum):
    PMC = "pmc"
    PUBLISHER_OA = "publisher_oa"
    UNPAYWALL = "unpaywall"
    REPOSITORY = "repository"


ROUTE_ORDER = [
    AcquisitionRoute.PMC,
    AcquisitionRoute.PUBLISHER_OA,
    AcquisitionRoute.UNPAYWALL,
    AcquisitionRoute.REPOSITORY,
]


class CapabilityStatus(str, Enum):
    SUPPORTED = "supported"
    EXPERIMENTAL = "experimental"
    DISABLED = "disabled"


class RouteCapabilityRegistry(BaseModel):
    """Explicit acquisition capability state for each route."""

    pmc: CapabilityStatus = CapabilityStatus.EXPERIMENTAL
    publisher_oa: CapabilityStatus = CapabilityStatus.EXPERIMENTAL
    unpaywall: CapabilityStatus = CapabilityStatus.EXPERIMENTAL
    repository: CapabilityStatus = CapabilityStatus.EXPERIMENTAL

    def status(self, route: AcquisitionRoute) -> CapabilityStatus:
        return CapabilityStatus(getattr(self, route.value))

    def enabled_routes(self) -> list[AcquisitionRoute]:
        return [route for route in ROUTE_ORDER if self.status(route) != CapabilityStatus.DISABLED]

    def enabled(self) -> list[str]:
        return [route.value for route in self.enabled_routes()]


class RouteProofRecord(BaseModel):
    """Machine-readable evidence required before a route is called supported."""

    route: AcquisitionRoute
    status: CapabilityStatus = CapabilityStatus.SUPPORTED
    proof_pmid: str
    resolved_ids: dict[str, str | None] = Field(default_factory=dict)
    run_id: str
    manifest_path: str
    artifact_sha256: list[str]
    runtime_version: str
    proof_date: date
    negative_case_pmid: str | None = None
    negative_case_state: str | None = None
    negative_case_manifest_path: str | None = None
    evidence: dict[str, Any] = Field(default_factory=dict)


class CapabilityProofRegistry(BaseModel):
    """Persisted support claims. A route is promoted only with a real proof record."""

    schema_version: str = "1"
    runtime_version: str = "0.4.3"
    routes: dict[str, CapabilityStatus] = Field(
        default_factory=lambda: {route.value: CapabilityStatus.EXPERIMENTAL for route in ROUTE_ORDER}
    )
    proofs: dict[str, RouteProofRecord] = Field(default_factory=dict)

    def promote(self, proof: RouteProofRecord) -> None:
        if proof.status != CapabilityStatus.SUPPORTED:
            raise ValueError("route proof promotion requires status=supported")
        if not proof.artifact_sha256:
            raise ValueError("route proof promotion requires at least one artifact SHA-256")
        if not proof.manifest_path:
            raise ValueError("route proof promotion requires manifest_path")
        self.routes[proof.route.value] = CapabilityStatus.SUPPORTED
        self.proofs[proof.route.value] = proof

    def write(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.model_dump_json(indent=2) + "\n", encoding="utf-8")
        return path
